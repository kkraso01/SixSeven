# Debate Transcript

Topic: Guns Reduce Crime
Motion: Guns Reduce Crime

Debate ID: Guns-Reduce-Crime-102808


## Round 1

### Moderator
Claim: At the moment, our debaters are coming down toward the stage so I just wanna ask you for a round of applause for all of them. And may I introduce the founder and CEO of Intelligence Squared US, Robert Rosenkranz.

### Moderator
Claim: Well, we’re nothing if not timely, uh, there was an eight-column headline in today’s New York Times. Quote, “Two gunmen kill man, 19, and wound four people in a Brooklyn hair salon.” We all remember the headlines around the Virginia massacre. It’s not headline news, but some 17,000 suicides are committed with guns every year in America. So gun control has a very powerful emotional appeal. And in New York you can sort of have the idea that only gun nuts are opposed to control. So what is the debate about tonight? Where is the case for guns reducing crime? It really lies in two ideas, it’s the idea that guns can prevent crimes, if people have guns at home or in their cars they can prevent crimes by firing a warning shot, by simply announcing I’ve got a gun, and those are very undramatic incidents, they’re not reported in the newspapers. But, they’re real and they happen every day. Crimes can be deterred by the prevalence of guns. In the United States it’s very unusual for robbers to come into homes that are occupied. In Britain it’s much more common. And the reason is that guns in the home can act as a real deterrent. In another context of course there’s a Constitutional right to bear arms. And that’s not just a sort of historic anomaly. It really reflects a basic, natural law, idea of self- defense. And people who have taken the trouble to train themselves and to use guns properly in their self-defense, this is a very, very important right for them and something that they hold onto with a great deal of emotional force as well. But, tonight we’re trying to transcend emotion, we’re really trying to see whether gun control keeps guns away from criminals, or whether it allows the criminals to have a monopoly of gun power. Whether the preventive effects and the deterrent effects of guns in the hands of a law-abiding populace actually make us safer.

Or, are the costs involved in these gun accidents and rampages and suicides that we all see in the headlines, is that the dominant factor in our thinking about gun policy. So with that kind of framing of the debate I’m really happy to hand the evening over to John Donvan, our moderator from ABC News, and the terrific panel that we’ve assembled tonight. Thank you for being here.

### Moderator
Claim: Thank you, and I would just like to invite one more round of applause for Robert Rosenkranz who makes all of this possible for us. Ladies and gentlemen, welcome to Intelligence Squared US, Oxford-style debating brought to America’s shores. I’m John Donvan of “ABC News Nightline.” On this stage tonight as your host and more importantly your moderator for another in our series of smart and sparkling debates on topics that matter. The motion before us in this program here at the Caspary Auditorium of the Rockefeller University in New York—the motion before us, “Guns reduce crime.” Which may sound counterintuitive, but that actually depends on how this debate goes, and it may actually sound intuitive, again depending on how the debate goes. We are joined also on this stage by two teams of debaters, of three members each, each of them superbly qualified to be taking part in this discussion. You are also a part of the evening, in that this is a contest, it is a contest of persuasion. These debaters are here to influence your views, to try to change your minds if you disagree with their position. It is a contest of logic and wit and charm and humor but mostly it is a contest of the power of ideas. In order to gauge and include your participation, we are going to poll you twice during the evening, once in a moment, and once at the end of the debate, in order to see where you stand on this motion that guns reduce crime. So at this point, we would like each of you to turn to the number pads at your seats, and indicate your agreement, disagreement, or lack of decision, over this proposition, the proposition before us that guns reduce crime. While you’re doing that I wanna point out the shape of the evening. Each of the debaters will have opening statements. Those statements will last seven minutes and it will be timed by us in this way— at the one-minute mark, when they have spoken six minutes and have seven minutes—one minute to go, they will hear a tone, a warning tone that sounds like this. That means they can talk and talk and talk. It— Did you all hear that? Clearly? At the seven-minute mark when time is up, the same tone will sound except it will be more persistent, more like this. And it will continue to do that until the speaker— stops—talking. After the opening round, our second round will be a head-to-head debate in which the debaters will debate among themselves, and also will take questions from me and questions from you, the audience. I encourage you to be critical in the way you listen, and critical in the way you ask questions, because once again, you are the judges of this evening, you will decide the winners of this debate. And then at the end of the debate once again we will poll you to see where we stand on the numbers. There will be a two-minute summary statement by each debater to wrap up the event and at that point we will announce the winners based on your judgment. So with that said, let the debate begin. Only rarely does a man of ideas witness in his own lifetime, the opportunity to actually see one of his ideas change history. For a scholar who wrote a controversial book in the 1990s, arguing that, where there is more gun ownership there is actually less crime, that history-making experience took place. Legislatures across the country took hold of the ideas in that book, and passed laws allowing for the carrying of concealed weapons, that indeed was history-making. The author of that idea and of the book that contained those ideas, is our first debater tonight, speaking for the motion, “Guns reduce crime,” John Lott.

### Conspiracy Advocate (CA)
Claim: Well, thank you very much, I appreciate Mr. Rosenkranz putting this on and it’s an honor to be invited here and the introduction was overly generous. But guns cause bad things to happen and makes—and guns make it easier for bad things to happen. But guns also make it easier for people to protect themselves and prevent bad things from happening. Guns make it easier for you to harm somebody, but guns also make it easier for you to deter criminals from attacking to begin with, and turn out to be the most effective way for somebody to go and defend themselves when they’re having to face a criminal by themselves. It’d be great if police were there all the time, my research finds that police are probably the single most important factor for reducing crime. But I think one thing the police understand themselves is they virtually always arrive on the crime scenes after the crime’s occurred. And the question you have to ask is what do you advise someone having to do, when they’re having to confront a criminal by themselves? Even if they’re able to call 911, you know, fast response times are measured in eight or nine or 10 minutes. And that can be a lifetime for many people. I think, as Mr. Rosenkranz was mentioning to begin with, a lot of people have a pretty good idea of the bad things that happen with guns. He mentioned the number of suicides. But you also have, if you look at surveys done by the Justice Department you’ll find maybe about 400-450,000 crimes are committed each year with guns. By contrast, you have similar types of surveys that indicate that people use guns defensively about 2 million times a year. So about four to five times more frequently people use guns to stop crimes than guns are used in the commission of crime. And yet, I assume for exactly the reasons why Mr. Rosenkranz mentioned earlier, people are if anything like to guess the opposite. I mean if you have—if you’re the editor of a newspaper and you have two crimes that you’re talking about, one, there’s a dead body on the ground, sympathetic person like a victim, and another case where a woman’s brandished a gun, the would-be criminals run away, no shots are fired, no dead body on the ground, it’s pretty obvious which story’s gonna be considered much more newsworthy. Now, we all want to try to take guns away from criminals. I mean one thing that’s been tried many times is to go and have gun bans. The problem is that when you go and pass something like that, the question you have to ask yourself many times is who’s most likely to obey the rule. If it turns out that it’s the most law-abiding citizens who obey the rule and turn in their guns, relative to the criminals, you can actually see increases in violent crime. And Washington D.C. is one important example of that. In 1976, September of ’76, D.C. passed a ban banning handguns, it didn’t go into effect until February, uh, ’77. Uh, but only once after ’76 was D.C.’s murder rate as low as it was in ’76. Only twice in two years after that was D.C.’s robbery rate as low as it was in ’76. And D.C.’s crime rate not only went up relative to what it was in the past, D.C.’s crime rate went up relative to neighboring states, it went up compared to the United States as a whole, it went up relative to other large cities. Here’s a graph that shows you for the top 50 cities of the United States, in 1976, D.C. was about 18 percentage points higher than the other 49 cities in the top 50. You can see after that, it keeps on going up, and if I were to have it in ’88, it even soars dramatically past that, but you can see, it’s about 90 percent higher when you get to 1987, the rate was falling before the ban, relative to other cities and rising dramatically afterward. It’s not just D.C. though. In Chicago, Chicago’s murder and robbery rates were falling prior to the 1982 ban, and they rose afterwards, they rose relative to other cities. One other way I can just mention for D.C. here, D.C. was 15th of the top…50 cities prior to the ban. In half the years after the ban, it was either number one or number two, and it was number four another four years, so two-thirds of the time after the ban, it was one of the top four cities. It was nowhere even close to that prior to the ban going into effect. It’s just not in the United States. Worldwide, time after time—and it’d be interesting to have people try to show an example where this isn’t true—when you pass bans you see increases in violent crime rates. The UK, here’s an illustration from The Economist a few years ago. They’d banned handguns in January ’97. Robbery rates, armed robbery rates were falling up until the time the ban went into effect, and they rose afterwards, if you’d continue this graph they’d continue to go up. You’ve had a 340 percent increase since the ban went into effect and the rate at which people are harmed by guns. You look at Ireland, Jamaica— I mean one thing is, people go and say well the reason why the Chicago and D.C. bans didn’t work is because it’s so easy to go and get access to guns in other places. Well here you have ideal situations, you have island nations, where it’s relatively easy and go and enforce the borders and protect them. And yet they’ve seen huge increases in the numbers of illegal guns, because essentially all of them are illegal after these bans go into effect. And yet just as we see here in the UK if you look at Ireland or Jamaica or other places, you see time after time increases in robbery and murder rates and violent crimes. Now one thing people often do is they look across countries and they say well, look, England has a relatively low gun ownership rate, it has a relatively high murder rate even if their violent crime rate is twice what we are in the United States. And they may point to Japan or Germany or other countries, and they say the United States has more guns, more violent crime. But the thing they have to take into account is these other countries had much, much lower violent crime rates prior to bans going into effect. In 1900 for example in England, in London, a city of millions of people, with no gun regulations, you had two gun murders, and five armed gun robberies that took place. And, what you see time after time when these bans go into effect, either violent crime rates no longer drop, or they begin to start to go up, as you’ve seen in England and other countries. Probably one of the most controversial things we could talk about are gun-free zones that we have in the United States for things like schools or other places. And we hear about these things, they, they dominate the news. But yet one fact doesn’t go out, you cannot find one of these multiple-victim shootings in the United States that occur, that takes place in—where more than three people are killed, that doesn’t take place in a gun-free zone where civilians are banned from owning guns. You want to make places safer. Banning guns you think are the easy solution to that. But again if you pass a ban and it’s the law-abiding good citizens who obey the ban and not the criminals, rather than making it safe for the would-be victims you may unintentionally make it safe for the criminals who are intent on trying to harm others and make less for them to worry about, thank you.

### Moderator
Claim: Thank you, John Lott. One of the safest major cities in the United States is Seattle, thanks in great measure to the work done by its police force, under the leadership of a chief who has led the city to a 40-year low in violence. That said, problems persist there as everywhere else, especially among young offenders, a point brought home to the Chief of Police in Seattle, after, in an anecdote he shared with us, he was doing some after- Christmas day shopping at a mall and when he returned to his car it had been broken into, and the one item stolen from his car was his gun. It’s firsthand experience, and, certainly of everyone on our panel, no one has more actual firsthand experience dealing with guns and crime than the Chief of Police of Seattle, Gil Kerlikowske.

### Scientific Advocate (SA)
Claim: Thank you, John, thank you. Well, it’s a pleasure to be here with you, I was worried that they wouldn’t bring that story out and I wanted to make sure that I did full disclosure and… ‘course I also appreciate the Seattle-like weather during the last couple days. Let me give you a perspective from a police chief’s point of view. First of all you have to understand that the position of police chief is not, whether it’s Ray Kelly, the great police commissioner in New York City, myself or others, we all actually worked our way up through the ranks. A puff of white smoke didn’t emanate from City Hall and suddenly we became anointed with these positions. All of us worked as police officers and detectives and sergeants, et cetera, so we kind of understand some of the nitty-gritty, although the television shows here in New York are so much better. The right to—in Seattle we’d have latte stories or something. But the right to own and possess a gun in this country isn’t a debatable issue and it’s not the topic. Reasonableness though, and common sense do come into play. I’m not a researcher and I am certainly not going to play a researcher for this debate tonight, but I do want to cite a couple things because it provides a framework for you, but it also puts into my perspective 36 years of law enforcement experience. This is work done by Phil Cook. So the rates of assault, robbery and rape will not noticeably be affected by more guns. Increase in the secondary market of guns, will occur. What is it in the secondary market? Loans to and from family members of firearms, off-the-book sales, meaning that there was no background check. Thefts of guns which, it was mentioned, I am personally familiar with. The percent of suicide with guns is highly correlated with the prevalence of gun ownership, and the murder rate in large counties is closely linked to gun prevalence. An increase in the gun murder rate would be expected, but there was no effect on the non-gun murder rate. So you’re going hear from the other side about the deterrence effect, and in fact John already brought a little bit about that up. More people carrying more guns will deter criminals. In other words the criminals will think twice before confronting a potential victim. I wish criminals were that smart. On the other hand I’m glad that they’re not that smart, because that’s why we catch so many of them all the time. Since we have almost, in the neighborhood of 240 million guns in the United States, I would think that these criminals would already get the message that there are a lot of guns out there and that if deterrence was in fact carried through that we would’ve seen it by now, but we haven’t. The other side of this coin is, will more armed citizens have an opposite effect on criminals. In other words, are the criminals going to now arm themselves thinking that more and more and more people are carrying guns. Well, the union that represents the British bobbies, who have been unarmed since Sir Robert Peel founded them, their union went forward and said look, we do not want to be armed as bobbies in the UK. Now this was during a time of significant increases in crime, increases in knife crime which is still going on. But they asked not to be armed. Now there are some specialized units certainly, called armed response cars, et cetera. But for the vast majority of the bobbies in all of the UK they are not armed and they don’t want to be because, one, they think it will only increase assaults on themselves, and that it will be a tit-for-tat or a proliferation of guns in the UK. Which like rabies they have very few of. Who is carrying a gun now in this country in the United States, well of course law enforcement officers, state, federal, local. And, security guards, security guards across all walks of life from banks to armored-car services, literally hundreds and hundreds of thousands of people that are already carrying guns. And then there’s a whole ‘nother group of people, and those are the people that are able to go into their states, and ask for a concealed firearms permit. There is a background check, it depends on the state, on what’s done. But essentially they say look, I sell jewelry or I have a business that’s been robbed, or, you know what, I want to be able to carry a gun like in Florida. And they’ll be able to carry a firearm as a concealed firearm. Here’s the big unknown, here’s where research has not actually answered this question. All of these hundreds of thousands of cops out there and security guards and citizens who have concealed firearms permits, how many are actually carrying a gun? They may have the permits, they may have the authority. When you’re a new police officer, you’re usually armed to the teeth, and within a few days or months or years or whatever, you oftentimes don’t carry a gun. It used to be that you were required in police departments across the country to be armed whenever you were out and about, off-duty or on. Very few departments have those rules anymore. Because the gun is difficult to conceal, it is uncomfortable and it is difficult to secure. So when we think of all the people that are actually out there, how many are actually armed. We don’t know. Now whenever somebody gives you a simple solution to a complex problem, we all know that you can be assured of one thing, it’s wrong. And so after all of the different campus shootings that we have talked about and read about, just recently of course in Arkansas, we hear this hue and cry, well, the students should be armed, or the students and the faculty should be armed. And the outcome as one academic told me, there is one sure outcome of arming the college students and that would be grade inflation. The last thing that I’ll mention—let me close with this. When I was a young officer, working the street in St. Petersburg--retired people, a lot of them from New York in fact-- a young woman, 15 years old, intoxicated, beating and beating and beating on the front door of an elderly couple who had no phone. They became more and more and more afraid, but she had been there beating on the door. He turned to the thing that he felt could protect him the most, even though she was unable of course to get in, and she was just really an intoxicated kid beating on the front door. He fired through the door and struck her. A girl about the age that his granddaughter could or would have been. And I remember going to the hospital and seeing her there, and I remember the family that lived, that husband and wife in St. Petersburg for many, many years. There are lots of cases in which these guns could protect you, there are far more cases in which the gun does not. Thank you.

### Moderator
Claim: Thank you, Gil Kerlikowske, arguing against the motion. Not many lawyers get to argue before the Supreme Court ever in their careers, much less get to bat .1000 when they do so. As a lawyer representing the National Rifle Association, Stephen Halbrook has gone 3-for-3 before the Supreme Court in arguing firearms cases on behalf of the NRA. He is on our stage tonight to argue in this debate for the motion, “Guns reduce crime.” Stephen?

### Conspiracy Advocate (CA)
Claim: Thank you, John. Thank you. It’s a real pleasure to be here, I think one of the remarks that Gil just made, shows the difference between our country and England, historically, not just today. Our country was founded when the British government had a policy of colonialism in which it sought to exploit the Americans, to tax them without representation, and when the Americans protested there was an escalation, and the British sought to disarm the Americans that led to violence, because the Americans thought this is our only chance to protect ourselves. When you look at a debate topic like this, “Guns reduce crime,” for and against, let’s define our terms a little bit, guns possessed by who. Guns possessed by law-abiding citizens reduce crime but not guns possessed by criminals, and, what does crime mean, we look at the term crime I think in a—we should look at it in a very broad way. Crime means the unjust aggression against life, liberty, and property, of another person. So crime can be committed...singly by one person against another or, in small groups by a gang of criminals against another. Or at the highest level it can be committed by governments. When we look at the problem of genocide, the problem of crimes against humanity, these are major crimes involving large populations frequently in which guns are used unjustly and there’s an ability to do that on behalf of authoritarian or police states because the population is disarmed. So, when we look at this issue we should look at not just here and now, what happens in the United States, or what’s happened in the last decade or two, or what happens today, but look at it historically in terms of what sorts of societies have existed historically and which ones have balance and democracy and republicanism and which ones are the kinds of states that you don’t wanna live in, Nazi Germany, Uganda under Idi Amin or Cambodia under the Khmer Rouge, I mean—this is real. We live in a society that’s very nice right now, it’s not guaranteed that it’ll always be that way, either, in terms of your own personal life or in terms of the possibility that a government could turn bad. What I think we’re advocating tonight, those of us on the side of the proposition, is that you should have freedom of choice to protect yourself if you decide to do that. One of the questions that was asked recently in the US Supreme Court, the District of Columbia was trying to defend its handgun ban and they said that it’s okay to ban handguns and that all guns should have trigger locks and be disassembled and never loaded. And one of the Supreme Court justices asked the question, well what if you hear the door crash in and you’re fumbling for your reading glasses and trying to turn on the lamp and your hands are trembling…maybe it would be a good idea to have a gun available if something like that happened so, the question is not whether everybody should have a gun, but the question is should you have the ability to exercise that freedom of choice if you are a responsible citizen, and that’s your decision to do so. Our American Revolution proved the ability of an armed populace basically to defeat a tyranny and that’s why we ended up in our Bill of Rights with the right of the people to keep and bear arms, the declaration that it shall not be infringed, and also a declaration in favor of a militia because that enhanced the security of a free state, security means that a free state is preserved as a viable political entity, it has republican institutions and people themselves are able to dissuade tyranny, they’re able to fight individual criminals. It was always considered to be a responsibility of individuals to, in the ancient hue and cry and the watch and ward, to, if criminals were on the loose, to try to catch them. And now we have degenerated somewhat into a society, where you don’t help anybody, and we have many instances where criminals are attacking people and nobody basically gives a damn. So…basically it comes back to freedom of choice, I’d like to use a couple of maybe legal cases, to illustrate the point. You’ve heard D.C. became the murder capitol of the United States after it enacted a handgun ban. There’s no duty of the police to protect you, it’s not just impossible for them to do so, it’s not a legal duty. Right before the handgun ban in D.C. was enacted, there were three women who were in a boarding house, and they were broken into. And there were two individuals who, over a period of many, many hours, raped and robbed and otherwise assaulted them. They called 911 several times, and the police would come knock on the door and nobody would respond. The police would drive by the house, because these ladies made repeated calls to 911. And so this ordeal, this nightmare finally ended, and they sued the DC government. And the courts ruled that there is no duty of government to protect any individual person. They have a duty to society at large, which is just kind of a useless concept when you're an individual and you're a crime victim. So there’s no duty to protect you. And then the question becomes, well, maybe you would like to protect yourself. Maybe you would like to at least have the legal right to do that. And that’s what the second amendment is partly intended to guarantee. That’s what the Supreme Court just held in DC versus Heller that we do have an individual right to keep and bear arms. And it’s a right. It’s not something you have to do. It’s not a duty. But it’s something that you can do. I represented a group of litigants in a companion case, and they live in the ghetto in DC, they're victims of robberies, house break-ins. This happened repeatedly. And they were good citizens, and they simply wanted access to guns. The same thing could be illustrated in Hurricane Katrina where the police chief announced no law abiding citizen could have guns, and basically they, the police themselves disarmed individual citizens. And we see the result of that. But if you went across the river into Algiers, the community known as Algiers, citizens armed themselves, they provided their own arms, and they kept violence down, they kept looting down. The same thing happened in the LA riots, and the same thing happened in Hurricane Andrew in Florida. There was no police protection, no national guard protection for several days. Armed citizens came forward and basically made sure that there was no looting, and no robberies, and no murders proceeding. So, the bottom line is, we don’t have the same system as England. You didn't hear Gil announce that the Seattle police force should disarm themselves. To the contrary, we should have armed police forces, and we should have that right to be exercised by individual citizens.

Thank you.

### Moderator
Claim: Thank you, Stephen Halbrook. We are halfway through our opening section of opening statements. And for people who may just be joining the radio broadcast, or who came in late, I'm going to say the following. I'm John Donvan of ABC News, and this is Intelligence Squared US, Oxford style debating brought to American shores. We have six panelists on the stage, three for, and three against the motion “Guns Reduce Crime.” We are halfway through our opening statements, and now let’s let the debate continue. We are all wise enough in the ways of the world to know that the statement “statistics never lie” is a lie. The point being that honest scholars can look at the same numbers and disagree profoundly about what they mean. We heard from John Lott, whose specialty is looking at the statistics of gun crime. We are now going to be hearing from John Donohue, who is also a numbers man, but who looks at the numbers and comes up with dramatically different points of view on guns and crime. And through the academic journals, the two John’s have something of a feud going. If you want to look up the journals-- some of which we may touch on tonight. But introducing you, as our next speaker, against the motion “Guns Reduce Crime,” John Donohue.

### Scientific Advocate (SA)
Claim: Thank you very much, it’s a great pleasure to be with you tonight. Well you mention a feud, I am a peaceful man, but let me just say that everything that you’ve heard from John in terms of the statistical claims are subject to serious challenge and refutation. Quickly, on the DC handgun ban issue, keep in mind that it was a DC handgun ban. You could still have a shotgun in your home. So if you needed to be protected in your home… The only thing that they were trying to take away was handguns, because those are the guns most preferred by criminals. But, if you look at the numbers that John had put up, which was interesting, if he had actually showed you the number of murders in DC, they had actually dropped. He showed you the rate. And what was interesting about that was, DC was de-populating tremendously in the seventies, and it was largely the flight of the affluent. So, the group that had the lowest likelihood of engaging in crime. So, crime was going to be, if you used the rates that John showed, it was going to be trending up, because the people remaining in the city had a much, much higher risk of crime. And so, when you make those adjustments, the conclusions are opposite to what John suggested. If you went for a number of years you’d see there was a huge run up in crime in DC, as there was in Chicago, and Philadelphia, and New York for that matter. But it had nothing to do with the topic we’re talking about. That was crack cocaine, which had a tremendous criminogenic influence on crime. The final thing to mention about DC handgun ban, is whatever it says about that particular experience, remember, DC is right across from Virginia, where there are plenty of guns. So, the story that John tries to tell you may tell you something about gun control in that urban environment, but it’s not a story about the value of guns. Everyone concedes that guns in the hands of the right person at the right time can reduce crime. That's why, as we heard, armed police and security guards are a good thing. If you go to a maximum security prison, the prison guards don’t have guns, because there are times when guns are good, and there are times when guns are bad. Prison guards, you might think, would want to have guns, but they know those guns would be taken away in a heartbeat by the criminals who are behind bars, so therefore you don’t see it. If you could expand the population in a cautious way to those who are unquestionably law abiding, and a cautious population, sure, there can be benefits there. But, the idea that, John Lott, and you will hear Gary Kleck argue that guns are being used constantly to thwart, um, criminals by these gun- toting citizens is grotesquely misleading. John gave a number, two million. Gary Kleck has at times said there are two point five million defensive uses of handguns each year. It’s a complete fantasy because gun ownership is so prevalent in this country, criminals know that all they have to do is wait for the family to leave and go to work, or to school, and then they can just walk in and grab the guns. And that happens five hundred thousand to a million times per year. So by virtue of our prevalence of guns, we are giving great aid and comfort to the criminal population, because they can walk in, take those guns. There was a wonderful Sixty Minutes documentary a number of years ago designed to show you how you could protect your house from a burglar. And they had an active burglar showing how quickly he could get in the house. And when he got in, Mike Wallace asked him, well, what’s the first thing you do when you get in the house? And he said, look for the guns. They're gold to criminals, and that’s why they go in and get them. So, whatever benefit we get from scaring off, or even shooting a small number of criminals, it’s offset by the fact that five times as many guns will be handed over to a criminal, in effect, because the criminals will be taking that gun from the previously law-abiding citizen. Now, John and I have debated on the issue of right to carry laws, laws that say citizens who have not yet been convicted of a felony, or not yet been involuntarily committed to a mental hospital should be allowed to carry a gun wherever they want. John thinks this is a great idea, offers statistics to prove it. Let me just mention that in Texas, even if you have been committed to a mental hospital, if you can get a note from your doctor, they’ll give you that concealed handgun permit. North Dakota really set a new low. They actually gave one of these permits to a blind permit holder. This is, to be frank, insanity. Now, I published a number of econometric studies, and virtually every top econometrician who has looked at this has sided with me, and not with John Lott. The National Academy of Sciences convened a panel of talented experts who spent two years looking at John Lott’s work, Gary Kleck’s work. They came before the committee, testified, fifteen to one in that panel of sixteen, they concluded the scientific evidence does not support the more guns, less crime proposition. The lone dissenter was someone who was not an econometrician, who admitted in his dissent that he wished he knew more econometrics, and who had previously testified as an expert witness on behalf of the NRA. The other fifteen members of the committee responded to his dissent saying, quote, the scientific evidence does not support his position. Let me just note what the NRA tries to tell you about all sorts of things. This is a picture of something that you can buy on the NRA web site. It’s a picture showing the Second Amendment. And note the way they drape the gun across the page. It’s obscuring the first half of the Second Amendment which starts off saying “A well regulated militia.” That’s because they would try to have you believe that was not part of the Constitution, the idea of regulation being very central, because it’s the first phrase in the Constitutional Amendment that they're talking about. Now, if the NRA can't be trusted to tell you the truth on something that’s been on black and white paper for two hundred years, how likely is it that they're going to be able to tell you the truth on the complicated issues of evaluating what he impact of these laws are. It’s a complete absurdity to think you're going to get the true story from the NRA and their close allies. Thank you.

### Moderator
Claim: Thank you, John Donohue. When it comes to hot button issues, we like to have easy pigeon holes to put people in. But our next speaker makes it difficult. A professor of criminology at Florida State, he is, let’s see, a Democrat, a member of the ACLU, a member of Amnesty International. He describes himself as an environmental tree-hugger. However, when it comes to this issue, this classic liberal is defying all expectations by arguing what is normally considered the conservative side. Gary Kleck, arguing for the motion that “Guns Reduce Crime.”

### Conspiracy Advocate (CA)
Claim: And yes, I'm going to vote for Barack Obama too. Thank you, John, and thank you all for coming out on this very nasty night. That is indeed an accurate rendition of my background. The moral of that particular story is, I didn't come to this pro side of this debate via my ideology. It’s the most unnatural thing in the world, from that standpoint. I didn't come to that position by virtue of my social background. I grew up in the wilds of suburbia, basically, where guns are scarce. They don’t have guns to commit crimes, they don’t have guns to defend against crimes, they don’t have guns for hunting, they don’t have guns. My way into this position is basically evidence-based. I'm boringly scholarly. I’ve been studying this issue for nearly thirty years, I’ve written three books, dozens of articles. I’ve published more articles on the effects of defensive use of guns than anyone else. Oddly enough, sometimes what you can learn from a debate is by listening to the silences, paying attention to what people would be expected to talk about, but don’t. Strictly speaking, the other side actually hasn’t addressed the issue of the effectiveness of defensive gun use. They’ve kind of danced around it, but they haven't actually addressed it head on, and in fact, the organization Paul Helmke represents, the Brady Campaign, previously Handgun Control Incorporated, used to have a very prominent segment of their web site devoted to the proposition that, no, if you try to use a gun for self-protection, you're going to get yourself killed, or injured, or it’s going to be taken away and used against you. And they’ve more or less stopped talking about it, they're just silent on the issue. That's significant. The reason is, the evidence is unanimous, it’s rare in criminological research for the findings to be unanimous on anything, but they're unanimous on this one. Defensive gun use is effective in the sense that crime victims who use guns during a crime are less likely to be injured or killed, and less likely to lose property than crime victims who adopt any other kind of strategy, including non-resistance. Non-resistance is not the safest course of action. And this is so despite the fact that usually when people try to use guns for self-protection, they're doing it under tougher circumstances. They do it not because they're quick on the trigger, but because they're facing really desperate circumstances, they're likely to be outnumbered, they're likelier to be facing offenders with weapons, including guns, than other victims. They're more likely than other victims to have already been injured. And out of desperation, with all of these handicaps against them, then they use guns in an attempt to defend themselves, and from that point on they are not hurt. Much of the research that previously claimed that, if you tried to use a gun you’d only get hurt, it had a simple error in the research that everybody here can understand. It was an error in terms of what happened first. Researchers would report that there were many incidents in which people were injured, and they used guns defensively. What they didn't know, and it turned out once the error was corrected in the research, those were always cases where somebody was first injured, and then used the gun for self protection. It wasn’t using the gun that got them hurt, it was getting hurt that finally pushed them into using the gun. When they fixed that flaw in the research, they basically found that once people used guns for self protection, they are almost never injured after that point. There’s good reason why the chief’s police officers carry guns. They're effective for self protection, but it doesn't require the unique training and experience of police officers for it to be effective. It’s effective basically for everybody. You may not have noticed, but there’s actually more consensus among the six of us than might be evident at first. I don’t think anybody really disputes the proposition that the effects of guns depends on who has them. I haven't heard anybody on the other side say that guns in the hands of non-criminals are just as bad in the hands of criminals. It makes a huge difference. Basically, guns in the hands of non-criminals, or in the hands of victims, regardless of any prior criminal behavior, reduce violence. They reduce it in the sense that, once the gun is introduced by the victim, the offender stops aggressing. Period. Furthermore, defensive gun use is extremely common, contrary to Professor Donohue’s claims, it’s not sheer fantasy that leads us to believe that there are on the order of two million defensive gun uses a year. It’s simply probability sampling surveys of the same sort that Gallop and Harris and every major survey organization uses.

You just ask people questions. You're not going to hear about these defensive gun uses from your newspaper, nor are the police going to hear about them because frankly, if you had been a crime victim who used a gun for self protection in a typical situation, you’d be insane to report it to the police. And of course if the police don’t hear about it, neither will your local newspapers. At best, maybe you’d be arrested for unlawful possession of a firearm, because most of these uses occur in public places where you're not supposed to have a gun, unless you have a special carry permit. At worst what can happen is you can be arrested for the, the assault itself, a criminal assault. It may well be somewhere down the road, after you’ve gone through a legal nightmare, that you're cleared of these charges, but in the meanwhile you can be bankrupted from the legal expenses, and have your reputation ruined, and nobody reads it on page eighteen that, oh yeah, you know, Joe Smith was cleared of those charges. So you're not going to hear about it from police statistics, yet scientifically conducted, objectively conducted surveys have, in at least twenty consecutive surveys, found that defensive gun use is not just common, it’s more common than criminal use is. And so that’s not a fantasy, as Professor Donohue would have you believe, it’s about as firmly established a fact as we have to go on in this area. Thank you very much.

### Moderator
Claim: Thank you, Gary Kleck. Another defier of easy pigeon-holing is the man who is President of the Brady Center to Prevent Gun Violence, an organization that is the forefront of the gun control movement. He is a Republican, and he is the former Mayor of Indianapolis. He has said that his position on gun control had a lot to do with nearly losing two close friends in a gun accident. This was during the time when they were all teenagers together. Now, all of these years later, we are pleased to introduce as our final speaker, and speaking against the motion that “Guns Reduce Crime,” Paul Helmke.

### Scientific Advocate (SA)
Claim: It’s great to be here tonight. I'm, just for the record, I was Mayor of Fort Wayne, Indiana, not Indianapolis, but another great city in the state of Indiana. I came to this issue as a mayor. Not only had I had the experience, when I was a teenager, of seeing a friend get a bullet in the back because of the all too common incident of, we found a gun, we didn't know it was loaded, which happens every day in this country. But as a mayor, I saw what happens in a community when there are so many guns, and when we make it so easy for dangerous people to get guns. I had police officers, one case I still remember well, I got the call in the middle of the night from the police chief, our labor relations director, a police chief, married to a police officer, they kept a gun at their headboard. They wanted to be safe. They knew how to use the gun. They were police officers. They had a fight, domestic quarrel. She ended up dead. That happens a lot in this country. Actually, the statistics show that if you’ve got a gun in your home, it’s twenty-two times more likely to be used against you or a family member than to protect you. Think about that again. Twenty-two times more likely. And part of the reason is that the world doesn't easily divide into the good guys and bad guys, because there’s always sort of a chance that any of us can get angry, any of us can get drunk, and if the gun is there, what’s going to happen with that gun? When you look at the arguments for the proponents here, basically they talk about these two million defensive uses, and as Professor Donohue said, that’s a questionable number. Yes, it was based on probability sampling. There were sixty-six people who responded to a poll that said they used a gun defensively. Sixty-six, and then you extrapolate that by the adult population of the US, and you get two million gun uses. Just sixty-six. When you do sampling and have such a small affirmative number, and then you multiply it by huge things, you get these outrageous things. Based on that, more people have been in flying saucers in this country. It shows what happens with statistics. Actually, when I was running for Mayor of Fort Wayne, I learned quickly how statistics--how it works. I was running against an incumbent. I looked at what had happened in crime in my community, and there had been times when crime went up. And so I'm digging out the statistics. The police chief at one time said, yes, crime was up because the economy was down. People lost their jobs, they were going to commit crimes. Then I found another clip from two years later, he said, well, crime is up because the economy is good, more people have things to steal. You can take statistics and do whatever you want with them so many times. The one statistic that doesn't lie are deaths. You have to do probability sampling for these other things, but when you look at deaths, you get the shocking statistics. That thirty-two people are killed with guns, murdered with guns every day in this country. That’s a Virginia Tech happening every day in this country. Thirty thousand people die from guns every year. That includes the suicides and the accidents. You get the situation like just a couple days ago in Massachusetts, some kid is shooting a machine gun at some gun show, and he kills himself because he can't hold it. What is going wrong with this country? Thirty thousand deaths. And then when you combine the seventy thousand people that are injured every year, people like Jim Brady, who, by the way, was with President Reagan at the time, surrounded by people with guns, the Secret Service. That didn't stop them from getting shot. Those guns didn't reduce that crime. The other argument that the proponents seem to make, is they're holding up this straw man of the gun bans, and how gun bans don’t work. And you can argue the statistics. Actually, after DC had their hand gun ban, gun suicides went down twenty-three percent, gun homicides went down twenty-five percent when you looked at a ten year period. So, there’s a lot of statistics there. But the real issue is not gun bans. We're not talking about gun bans, we’re talking about the question, do more guns reduce crime? And it’s clear that the more guns you get out there, the more likely those guns are going to be stolen. Where do you think the criminals get these guns? That these guns are going to be trafficked. Where do you think the criminals get these guns? Misused? Where do you think accidents happen from? Used in road rage. Used in the domestic violence situation. It’s the guns that add to the problem. Other countries in the world have the same level, generally, of rapes, and of burglaries, and of robberies, and of assaults that we do, industrialized countries. But we are far and away the most deadly country when it comes to gun crime, because we have so many guns. In fact, if you think about it for a second, if the proposition were true that guns reduce crime, we should be the safest country in the world, and we’re not. And it’s because we do have so many guns, and those guns too easily get in the wrong hands. And actually, when you think about this proposition, rather than voting to say that guns reduce crime, you should stop and think that really restricting access to guns is what would reduce crime. We’re coming up on the fifteen year anniversary of the Brady Bill. The Brady Bill said, instead of taking an individual’s word whether they're a felon or mentally dangerous, let’s do a background check. The Brady--you know, bright idea, right? Don’t just say, are you a felon? No, of course not. You know, it’s a… The Brady Background check system has stopped one point six million people from buying guns who weren't allowed to buy guns. We had a situation just last week in Virginia where somebody went in to buy a gun, turns out there’s a murder warrant for them in Baltimore, and the person got arrested. You know, criminals, like the chief said, aren't always the brightest people in the world. In fact, this guy tried to argue, well, I didn't commit the murder, I wouldn't have gone and bought a gun if I… It didn't make any sense. Brady background checks work. If we decide that some people are probably more prone to violence, again, people with a felony record, people that are dangerously mentally ill, let’s stop them from buying those guns, let’s use background checks, let’s have them in all sales, not just from federally licensed dealers. Let’s do things to stop gun trafficking. Do you realize that you can go in and buy eighty- one of the same make and model of a gun tomorrow, and what do you think is going to happen when someone did that in Charlie Brown’s Gun Store in Dayton, Ohio a few years back, eighty-one of the same make and model? They sell them out of the trunk of their car. People don’t realize how weak our gun laws are in this country. We basically allow almost anyone to get any kind of a gun. Last thing I wanted to comment on is the Supreme Court case. The Supreme Court case, while making it clear that gun bans are off the table, made it clear that we can have reasonable restrictions, that we can restrict who gets the guns, where they take the guns, how the guns are sold, how the guns are stored, and what, and all the things that deal with guns. That’s where this debate should come down. I'm not anti-gun. I’ve got my NRA pro-marksmanship badge from when I was in sixth grade. My friends all went hunting and did these things too. But once you see how easy we make it for dangerous people to get guns, you’ll conclude that you should vote against the proposition. Thank you.

## Round 2

### Moderator
Claim: Thank you, Paul Helmke, and I apologize to the people of Fort Wayne, Indiana. The mistake was mine alone, but I'm very much reminded of the fact that we are not in Indiana, that we are in New York City, because we have the numbers in. Polling the audience before the debate on the motion, and we’re going to put them up on the screen now, the motion being “Guns Reduce Crime.” Thirteen percent of you supported this motion before the debate, sixty percent of you opposed the motion, and twenty- seven percent were undecided. We’ll be polling you again toward the end of the debate to see whether any minds have been changed. We’re going to begin the section now, where the debaters address one another and also take questions from you, the audience. And again, I would very much encourage any of you who are here to participate. If you have expertise in the field, that is so much the better. Again, we would encourage you to keep your questions exceedingly short. What you need to do is raise your hand, and we have ushers who are moving around the aisles, and will come to you, and locate you. But I just want to go to John Lott, who, in a sense, your work embodies this motion that guns reduce crime, and your statistical work embodies that motion. And yet tonight I heard some of the fundamental work you’re done referred to as a fantasy. And I heard the question raised by former Mayor Helmke, if guns prevent crime, why isn't this the most safe nation in the world? What is the answer to that, and what about the fantasy issue?

### Conspiracy Advocate (CA)
Claim: Well, I mean, there are lots of academics that have, I’ll just take the fantasy issue first. There are lots of academics who have looked at the relationship between concealed hand gun laws and crime rates, and if you look at papers published in refereed academic journals by economists and criminologists, you’ll find about seventy percent of them find that when right to carry laws get passed, there’s drops in violent crime rates. About thirty percent say there’s no change that’s there. And then there’s not one refereed academic journal that I know of that finds that there’s a bad effect from these. So there’s a lot of people that looked at this in many different ways.

### Scientific Advocate (SA)
Claim: John, John, you're ignoring the National Academy of Science Panel—

### Conspiracy Advocate (CA)
Claim: I'm happy to—

### Scientific Advocate (SA)
Claim: 15 to one, including some of the top econometricians in the country—

### Conspiracy Advocate (CA)
Claim: Right.

### Scientific Advocate (SA)
Claim: —and their conclusion was your work is not supported by the scientific evidence.

### Conspiracy Advocate (CA)
Claim: Not true, we’re experts on it, their opinions on that issue have absolutely nothing to do with it, John’s talking about what experts thought.

### Conspiracy Advocate (CA)
Claim: But the promise—

### Conspiracy Advocate (CA)
Claim: And the real debate is simply between people who say there is a beneficial effect, versus those who say there’s no effect. There basically is no, no participation on John’s side, on John Donohue’s side. Basically there is no support for the view it has counterproductive violence-elevating effects.

### Conspiracy Advocate (CA)
Claim: But just to respond to the National Academy of Sciences, I mean, unfortunately I think, there’s a problem with government getting involved in evaluating research, and it’s very hard for the government to keep politics out of it. This was a panel set up by the Clinton administration; I don’t think it was unbiased—

### Scientific Advocate (SA)
Claim: This was not a panel set up by the Clinton administration—

### Conspiracy Advocate (CA)
Claim: It was started there. But the point is, what James Q. Wilson, who’s this hack that you were referring to, and I think a lot of people would regard James Q. Wilson as probably the top criminologist in the country, he was the person who was dissenting on this. And what…Jim showed, was that if you look at every single one of the National Academy of Sciences estimates on the impact of right-to-carry laws on murder rates, every single one of their own estimates showed that right-to-carry laws reduced murder rates. And if you looked at their other things, virtually all their other estimates for all the other types of crimes showed reductions in those also—

### Scientific Advocate (SA)
Claim: John, I have the report—

### Conspiracy Advocate (CA)
Claim: There was no estimate—

### Scientific Advocate (SA)
Claim: I have the report right here—

### Conspiracy Advocate (CA)
Claim: —not one estimate, that the National—

### Scientific Advocate (SA)
Claim: I have the report right in front of me, and it does not support what you just said.

### Conspiracy Advocate (CA)
Claim: Is it true or is it not true that every regression, every estimate that they had on right-to-carry and murder showed a drop. Is there one estimate they showed that it didn't fall?

### Scientific Advocate (SA)
Claim: Yeah—

### Conspiracy Advocate (CA)
Claim: Statistically—

### Scientific Advocate (SA)
Claim: Yeah, there are some, not— maybe not statistically significant, but— But, the bottom line, John, is, as the panel suggested, the elephant in the room was crack cocaine. The states that did not pass the right-to-carry laws were states that had a big problem with crack cocaine which had an enormous influence in running up crime.

### Conspiracy Advocate (CA)
Claim: Now, that’s—

### Scientific Advocate (SA)
Claim: The rural states that did pass these laws did not experience the big run-up in crime, and when you do your analysis, it is the difference between the flat performance in the rural states, and the increases in crime that generates that result. That’s why—

### Conspiracy Advocate (CA)
Claim: That’s simply not true—

### Scientific Advocate (SA)
Claim: —James Q. Wilson was outvoted 15 to 1.

### Conspiracy Advocate (CA)
Claim: Look—

### Moderator
Claim: Okay, I—I think we have impasse on this… And I— I wanna go to Chief Kerlikowske, Seattle police chief, because you were talking about British bobbies being unarmed, and preferring that in many situations because they felt being armed would invite assault, and yet Gary Kleck arguing for the motion said why are police armed in the first place unless it is to deter assault, do you—can you take that on?

### Scientific Advocate (SA)
Claim: Yes I can, and, remember what Truman said, if I could line up all the economists end to end, wouldn’t that be a beautiful sight, so that, I just— And one, and one is on my panel. So…getting away from the statistics and going to that police officers are highly trained with firearms. They practice and qualify, they can’t graduate from the academy with qualifying. Without question, they can use the gun in a defensive mode. But when you look at the numbers of police officers in the United States and I remember—I can picture every moment to this day, of the first time I had an officer killed in the line of duty. Young, bright, talented, incredible shape, shot 13 times with his own handgun. Wasn’t a question of training, wasn’t a question of anything else. Officers are routinely wounded and assaulted with their own guns. That’s why—

### Conspiracy Advocate (CA)
Claim: That’s not true, that’s absolutely not true—

### Scientific Advocate (SA)
Claim: Officers are routinely assaulted—

### Conspiracy Advocate (CA)
Claim: It’s an incredibly rare event—

### Moderator
Claim: Gary—Gary Kleck is—

### Scientific Advocate (SA)
Claim: But anyhow—

### Moderator
Claim: —objecting, but Gary, hold off—

### Scientific Advocate (SA)
Claim: There was a—

### Scientific Advocate (SA)
Claim: —the entire reason that the entire gun industry made significant changes in holsters. It used to be that we all wanted the quick- draw holster, how fast could we get the holster out. Now the holsters are designed, they’re cumbersome, they’re heavy, they are not quick-draw and they are designed and sold by the millions across this country for one reason and that is because of officers having the gun taken from them.

### Moderator
Claim: Gary—Gary Kleck is—

### Moderator
Claim: —Gary Kleck, I just want to remind our radio listeners, Gary Kleck is arguing for the motion, the liberal…who works just from the numbers.

### Conspiracy Advocate (CA)
Claim: You know, here’s a number for you and it’s a very easy number to understand, for the most recent years for which we have data in the entire United States, there was exactly one police officer killed with his own gun, one. It is—you can stretch the concept “routinely” quite a bit but I don’t think one—

### Scientific Advocate (SA)
Claim: But Gary, how many officers—

### Conspiracy Advocate (CA)
Claim: —out of 600,000 police officers in the entire United States—

### Scientific Advocate (SA)
Claim: But how many were actually shot—

### Conspiracy Advocate (CA)
Claim: —can really be described as routine. That’s, that’s some indication of the chief’s credibility when he says something happens frequently or routinely, one in 600,000 is not routine—

### Scientific Advocate (SA)
Claim: But Gary, you left out the number of the number of officers—

### Conspiracy Advocate (CA)
Claim: And—

### Scientific Advocate (SA)
Claim: —actually killed—

### Conspiracy Advocate (CA)
Claim: —what he fails to point out—

### Scientific Advocate (SA)
Claim: —very small—

### Conspiracy Advocate (CA)
Claim: —is that police officers in fact are not assaulted anywhere near as often as civilians, and he’s right, there’s a very straightforward reason, they’re all armed with firearms, and trained.

### Scientific Advocate (SA)
Claim: But—

### Moderator
Claim: Chief—Chief—let the Chief respond

### Scientific Advocate (SA)
Claim: I mean, actually you’d have to be pretty stupid to assault an armed police officer who has a baton, a uniform, a radio—

### Conspiracy Advocate (CA)
Claim: Indeed you would—

### Scientific Advocate (SA)
Claim: —a gun, pepper spray and extra ammunition and is wearing body armor. That probably is quite correct. But there are very few because of body armor and the changes in body armor in this country, there are very few police officers now killed or wounded in the line of duty, that the number—that the numbers that we used to see. So to say yes, one out of what, but what, 45 officers killed, shot—

### Conspiracy Advocate (CA)
Claim: There were never many—

### Conspiracy Advocate (CA)
Claim: So the ratio—

### Conspiracy Advocate (CA)
Claim: There were never many even 20 years ago or 30 years ago before the advent of body armor, it was no more true than now, it’s simply untrue—

### Conspiracy Advocate (CA)
Claim: Yeah, you’re talking about at most five a year or so, even in the high years that that is. Look, five, it’d be better if it was zero but if you look at the number of police officers who are assaulted in a year you’re talking about between 16 and 20,000. And so if you’re asking, what’s the rate of a police officer who’s assaulted, who’s going to lose control of his weapon and have it used against him—and going to result in his death, it’s a tiny number, but even more important I think to make is a comparison to civilians, because that’s partly the motivation for this. And police officers have a much more difficult job than civilians do, a police officer can’t brandish a gun, watch the criminal run away, and be satisfied that his job’s over with. If he has to come into physical contact with the criminal, and you’re much more likely to have something go wrong. One of the benefits a civilian has, if you take a right-to-carry class to get your permit someplace, one of the things they’re going to tell you is you’re not the police. Your job isn’t to go and arrest people. The benefit that you have of having a gun, is to maximize the distance between yourself and the criminal. If he runs away, that’s basically what you’re done with, and that’s the reason why you had the gun.

### Moderator
Claim: Paul Helmke—

### Scientific Advocate (SA)
Claim: Yeah, I—

### Moderator
Claim: —Paul Helmke, as a former mayor of Fort Wayne to whom the police reported, were you surprised to hear Stephen Halbrook, who represents the NRA, say that police do not have a responsibility to protect individuals?

### Scientific Advocate (SA)
Claim: It’s— I think Steve’s playing legalisms with what really happens, I mean the general slogan for most police departments is “To protect and defend.” I mean it’s their job to get out there, now they—

### Moderator
Claim: But his argument is that—

### Scientific Advocate (SA)
Claim: His argument is that you can’t sue them if they haven’t responded

### Moderator
Claim: His argument really is because the police can’t do it people have to do it for themselves.

### Scientific Advocate (SA)
Claim: And let me address that argument, it’s Steve’s argument, at some extent, is true. People do have a right of self-defense. The Supreme Court made that very clear in the Heller case, you know, I do wonder a little bit about Justice Roberts’s comments that he wasn’t, you know, he wanted to be able to shoot his gun but he needed to turn on the light and put on his reading glasses before that, and that’s the example Steve just gave and I thought gee, if the Chief Justice needs to put on his glasses and turn the light on before he can shoot maybe, he shouldn’t be shooting, but— It gets into the issue of, yes, people do have a—

### Scientific Advocate (SA)
Claim: People do have a right of self-defense. But what we do when we live in communities is we set up police departments because they’re the individuals that are trained, they’re the individuals that respond. And often when an individual has a gun in their home, again as I said it’s 22 times more likely to be used against them or a family member. Homes with more guns have more gun violence, cities with more guns have more gun violence, states with more guns, countries with more guns, more gun violence, now that includes gun suicides and gun accidents, not just gun homicides. And when you talk about police departments—I ran the police department. 20 percent of the time that an officer’s shot it’s his gun or his partner’s, so you’ve gotta expand that to the partner’s gun. 20 percent of the time when an officer’s in a shoot-out situation, they miss their target—

### Moderator
Claim: Well, you’re running—

### Scientific Advocate (SA)
Claim: —only 20 percent of the time do they hit their target—

### Moderator
Claim: —into a lot of numbers here, I want to give Stephen a chance to respond, Stephen Halbrook of the NRA—

### Conspiracy Advocate (CA)
Claim: There’s something really bizarre about this picture that citizens with guns are totally incompetent and police with guns are totally incompetent and they’re likely to be taken away from them, but somehow criminals are really good with guns, where— where did they get all this training.

### Scientific Advocate (SA)
Claim: Well, they’re not that good—

### Conspiracy Advocate (CA)
Claim: There’s something bizarre about this picture that, citizens and police cannot defend themselves with guns but criminals can successfully use guns to aggress against other people, it doesn’t make—it’s against common sense. I’m not a statistician, I don’t think Paul is either, we’re the two who aren’t here but it just doesn’t make sense to say that you should never be able to protect yourself, that you shouldn’t use a gun, that you’re incompetent, that you’re totally worthless with it and—it’s just, against any common sense. And, the fact that, this is not just a legalism, police have no duty to protect you. It’s not their fault by the way, of course their slogan is to protect and serve, they want to do that. But they have no legal compulsion to do it and of course even if you could sue them if they didn’t protect you after the kinds of scenarios we talked about, it wouldn’t do you any good, you may be dead or you’re otherwise injured. You want to be able to prevent the crime from happening. And the only way to do that in some circumstances is you have to be able to protect yourself.

### Moderator
Claim: We’re going to go to the audience for some questions, now there are a lot of hands up and what we’re gonna do is pick out… take two or three questions, do the questions first and then we’ll repeat them to the panel, so, why don’t you take that one right there…? Brief, please.

### Moderator
Claim: Um—

### Moderator
Claim: And I’m collecting questions so it’s me and then I’ll relay them.

### Moderator
Claim: To the gentlemen…for the motion, if you believe that guns reduce crimes, would you recommend that your children keep a gun handy.

### Moderator
Claim: Thank you. Down here? I’ll come back. Sorry, here?

### Moderator
Claim: Yes, I think that we’re conflating statistical data about societies and societal factors with the guns themselves. So I am not clear where you have had a concealed-carry law put into place, within that particular community so you can hold constant for crack use, or non-crack use, rural or urban. What has been the result, does it reduce crime, does it increase crime, and the other thing that I would appreciate you speaking to, is the word “regulate” in the second amendment, it seems to me that in our history, people regularly had gun ownership and it was not something that was precluded, so addressing that point and how it affected our—

### Moderator
Claim: Thank you—

### Moderator
Claim: —opinions would be helpful.

### Moderator
Claim: Thank you. Right to your left…?

### Moderator
Claim: Hi, I have a very quick question that’s a little bit more specific than just a broad topic. Do you think that gun buy-back programs, help reduce crime and if yes, who evaluates these programs and why are they started in the first place—

### Moderator
Claim: Okay—thank you, we—those are good, those are all questions and they’re quite good and brief. Should kids have guns to protect themselves, I suppose, what age are you talking about, when would you say— start saying this is a reasonable question to ask.

### Moderator
Claim: Um—

### Moderator
Claim: Microphone to your mouth.

### Moderator
Claim: I was really interested, all these gentlemen seem to have—to be old enough to have children over 18 or 21.

### Moderator
Claim: Mm-hmm.

### Moderator
Claim: I was wondering, their own children, would they recommend that their own children—

### Moderator
Claim: For self-defense. Not for hunting, not for sport—

### Conspiracy Advocate (CA)
Claim: Yeah—

### Moderator
Claim: —self-defense. Gentlemen, any of you support guns for children for self-defense.

### Conspiracy Advocate (CA)
Claim: I hope my kids have guns—

### Moderator
Claim: This is John Lott answering. Sorry, John, I spoke over you, go ahead?

### Conspiracy Advocate (CA)
Claim: I mean I hope my kids have guns, when they get—I mean I didn’t own a gun until 1996 after I’d started doing the research that I did. As far as I know my family had never owned a gun. But at this point, given that I believe the benefits far outweigh the risks, I think I’d be disappointed if my kids didn’t own a gun.

### Moderator
Claim: Anybody on the other side respond to that?

### Scientific Advocate (SA)
Claim: I wouldn’t want my daughter to have a gun.

### Moderator
Claim: That’s Paul Helmke—

### Scientific Advocate (SA)
Claim: When I look at the statistics about how that adds to the risk of suicide, the risk of being misused, the risk of it coming up, being stolen, used in a domestic quarrel, I think it’s just too much of a risk.

### Moderator
Claim: John Donahue against the motion.

### Scientific Advocate (SA)
Claim: There’s also the social factor that the NRA and our other panelists want to ignore. Sean Penn got the right to carry a concealed handgun in California which is tough to do, went to a Berkeley restaurant for lunch one day, came back, his gun was— his two guns that he had left in his car were gone because the car had been stolen. They got a car back, a few days later, but the two guns were missing, so maybe it might’ve helped him at some point, but now somebody’s got Sean Penn’s guns, and I suspect it’s a criminal—

### Moderator
Claim: Okay, we’re a little—

### Scientific Advocate (SA)
Claim: —that’s not going to use them very effectively—

### Moderator
Claim: —we’re a little off the point of the question about children who are—the second question went to whether there are studies that show the impact of a concealed-carry law within a given community actually having had an impact, before that I have a question. How is a concealed weapon a deterrent, to the guy who can’t see it.

### Conspiracy Advocate (CA)
Claim: Because they don’t know who has it, and if you have a—

### Moderator
Claim: So the community has it, in other words—

### Conspiracy Advocate (CA)
Claim: If you’re in a state that has mandatory issuance of concealed- weapon permits, then criminals have no knowledge of who might be carrying legally, and you would think there would be more who would carry if it is legal than those who would do it out of desperation because of fear—

### Moderator
Claim: So people who would not be carrying in that community would also be protected under that theory, because—

### Conspiracy Advocate (CA)
Claim: Absolutely, because the criminals don’t know who has the gun.

### Moderator
Claim: John Lott, you were going answer the question that the questioner put to us—

### Conspiracy Advocate (CA)
Claim: Right—

### Moderator
Claim: —about whether the, sta—there is a—

### Conspiracy Advocate (CA)
Claim: No, excellent question, actually. And, that’s precisely what you want to do, you don’t want to just compare across places because, you know, Idaho is different than California and England has a different underlying crime rate before they change any types of gun control laws than the United States has. And so what you’re doing in these tests is, you’re precisely doing that, you’re seeing how crime rates change in a state after that state’s adopted right-to-carry laws, and how that change is comparing to other places that didn’t change their laws over that period of time. And there are lots of other things you’ll do, you’ll see, as that state issues more permits, you know, is there a greater drop that you see…Stephen Halbrook was just mentioning is the probability that a criminal may come across somebody who’s able to defend themselves, is there some relationship between the increased risk that the criminal faces and, and further drops in crime. But, you know, that’s exactly the way that you want to do the test and all the tests that I do, that’s precisely the type of test—

### Moderator
Claim: I’m seeing a great deal of skeptical looks from the opposing table. John—

### Scientific Advocate (SA)
Claim: All the tests that John do—

### Moderator
Claim: —John Donohue’s taking this—

### Scientific Advocate (SA)
Claim: All the tests that John do—

### Scientific Advocate (SA)
Claim: —show that, crime gets better. But, again, this is exactly what the National Academy of Science looked at. And, they concluded the opposite, that the data did not—

### Conspiracy Advocate (CA)
Claim: They did not conclude the opposite.

### Scientific Advocate (SA)
Claim: They concluded that the data does not support the proposition that we’re debating today which is that guns reduce crime.

### Conspiracy Advocate (CA)
Claim: No, actually what that report—

### Moderator
Claim: Gary Kleck—

### Conspiracy Advocate (CA)
Claim: —persistently said was, we don’t have strong enough evidence to draw firm conclusions about virtually every issue they addressed, so, that was more of a no-decision decision than it was reaching the opposite conclusion, they did not reach the conclusion that making it easy to get a carry permit increases crime. They did not conclude that John Lott was wrong, and basically, you know, you learn nothing from what that particular panel said—

### Moderator
Claim: I—

### Conspiracy Advocate (CA)
Claim: —be—precisely because it was—

### Moderator
Claim: —I’ve read the same report and I have to say, Gary, that I read it the same way, actually, it was a bit of a Pontius Pilate moment that didn’t know who was right or who was wrong—

### Conspiracy Advocate (CA)
Claim: We need more data—

### Conspiracy Advocate (CA)
Claim: Yeah, you kind of read the thing and you ask was this trip really necessary. I mean—

### Scientific Advocate (SA)
Claim: One of the things, just real quick on concealed-carry—

### Moderator
Claim: Paul Helmke—

### Scientific Advocate (SA)
Claim: —The real issue is, who makes the decision on whether you’re getting a concealed-carry permit, and, and the real difference between states are those where it’s a shall-issue or versus may- issue. And a lot of states as the

### Moderator
Claim: You have to explain what shall-and-may means—

### Scientific Advocate (SA)
Claim: Yeah, I was going to do that, shall-issue states, it basically, someone fills out a form, sometimes they don’t have to take a class, a lot of times in Utah they don’t even have to live in the state. Sometimes you can just send in a form that says, yes, I listened to a video or whatever, and send— here’s my check, and you get a concealed-carry permit. In other states it actually goes to the Chief of Police or to the Sheriff, who does a check to see whether you—not only is your record clean but, in terms of the felony conviction, but they check to see are the police responding to your house every week because of domestic quarrels, is this a kid that you’ve had to arrest a number of times on minor things that aren’t going to be a disqualifier. Then the police have some discretion, I had a police chief who turned down somebody for a gun because—he had a clean record, turns out the kid had been acquitted of killing his parents in a neighboring country five years earlier. It was questionable whether he should’ve been acquitted, it was one of those cases. My chief turned him down a few years later when it was easier to get those guns, he ended up killing his brother, brother-in-law, neighbor, with one of his 25 AK-47’s that he kept in the attic, so— It’s give the police a little more discretion on who’s getting these guns. Right now, 48 of the 50 states have some version of either may issue or shall issue, so it’s hard to make comparisons between states that do and don’t have these things—

### Moderator
Claim: Let’s bring Chief Kerlikowske also to address the gun buy-back questioner.

### Scientific Advocate (SA)
Claim: I will, I think the issue for us is clearly that there has to be far more than being mobile and not being blind as a reason to give someone a firearms permit. And just within the last several months at one of the largest festivals in the city, the Folklife Festival, tens of thousands of people and literally dozens of police officers, officers within spitting distance in fact of the crowd, a young man who had been on methadone, who had had a number of other problems, had a license issued by the Sheriff in a neighboring county, so that he could carry a concealed firearm anywhere. And in the middle of this crowd he looked at someone, that person looked at him and they got into a fight, the gun went off and it not only discharged across the assailant, the person that he was fighting with--and all they’d been fighting with were their hands--the gun also then ended up going through the hand of a young man and into the thigh of another woman. That is a person that should’ve never had a concealed firearms permit. On the issue of gun buy-backs I think the research is pretty clear, does it deter crime, does it result in guns being taken off the street that are crime guns… A lot of times they’re old guns, they’re guns that are not being used in crimes and they’re being found by people cleaning out garages, et cetera. Taking those guns off the street is not a bad thing, remember a hundred-year- old firearm can kill someone. But I don’t think we see it as a huge issue as far as reducing crime.

### Moderator
Claim: John, could you—just one second, I have just a little bit of business I need to do for our radio broadcast, to remind everyone that I’m John Donvan of ABC News and this is Intelligence Squared US, Oxford-style debating, we have six panelists, three for and three against the motion, “Guns reduce crime,” we are in the head-to-head section of the debate and taking questions from the audience—John Lott.

### Conspiracy Advocate (CA)
Claim: On the gun buy-back issue, I don’t know of one single academic study by any type of academic, that finds that they reduce any type of violent crime rate. We could talk about that more if you want to, but— One question that keeps on coming up here, a point from the other side is that, people with concealed handgun permits, they may do bad things. And it’s easy to check. In the state of Washington you’ve had permits being issued since 1960. The type of incident that there was, this wounding, is the only case I know like that in the state of Washington, nobody has been convicted of murder for example in Washington that’s had a concealed-carry permit, and you’re talking about almost 50 years. And you see that in state after state. In Florida, you can go to the website for the department that issues permits, and they have detailed data there, you find that, from October 1987 through September 31st of this year, they had issued over 1.41 million permits to 1.41 million people. Of those people, 166 had had their permits revoked for any type of firearms violation. Virtually all those were for one type of violation, that was someone who accidentally carried a concealed handgun into a gun-free zone like an airport or what have you—

### Scientific Advocate (SA)
Claim: It’s interesting that—

### Moderator
Claim: This is Paul Helmke

### Scientific Advocate (SA)
Claim: —it’s interesting that Florida’s brought up though, the—

### Scientific Advocate (SA)
Claim: —the Sun-Sentinel, did a study in 2006, before the legislature closed off this website, this is the new move by the way, is that the gun pushers come in and they say we don’t want this information to be public because we don’t want you to know what’s happening with the concealed carry permit holders. But the Sun-Sentinel found 216 people with active warrants, 128 with domestic violence restraining orders, nine people charged with felonies or reckle—or violent reckless demeanors, six red— registered sex offenders, at least one prison inmate, and another 1400 people who had pled guilty or no-contest to felony charges, all had concealed-carry permits in the state of Florida—

### Scientific Advocate (SA)
Claim: And then—and the Florida legislature, said, we don’t want to make this information public anymore.

### Moderator
Claim: Gary Kleck says that Paul Helmke is leaving something out—

### Conspiracy Advocate (CA)
Claim: But notice what Paul is leaving out of that, you may have been listening for how many people did something with their gun that they are now legally entitled to carry around in public places. How many times did they commit a violent crime in a public place, that’s the oily thing a carry permit allows you to do that you couldn’t do without the permit. In fact, none of those people did a violent crime with a gun in a public place and the fact that they had carry permits had absolutely nothing to do with anything, there was no—

### Moderator
Claim: We’re gonna go back to—

### Conspiracy Advocate (CA)
Claim: —there was no harmful consequence—

### Moderator
Claim: —questions from the audience while we still have some time—

### Conspiracy Advocate (CA)
Claim: —of them getting those carry permits.

### Moderator
Claim: Down in the front, we’ll do three again, as before.

### Moderator
Claim: Right, my question is for those who are in favor of the proposition. Isn’t there a distinction between a handgun, and a more excessive weapon like an AK-47, would you have the same attitude toward those more—

### Moderator
Claim: Thank you. That’s— I take the point, in the, in the back? Yes, sir.

### Moderator
Claim: The question went unanswered earlier, why isn’t the United States the safest country in the world, if we have so many guns, and if you add to that, the fact that the incarceration rate here is so high so theoretically we’ve already taken off a large amount of criminals from the street.

### Conspiracy Advocate (CA)
Claim: Can I answer that—

### Moderator
Claim: Well, we’ll come to the third question, I just wanna bring in a third question, where, do we have a mic? Okay. You have a bunch of hands around here.

### Moderator
Claim: I’m just wondering with, regards to illegal gun ownership, how, no one has addressed exactly how to reduce that. You know, we’re talking about increasing the supply of guns. How about reducing the supply to criminals and people that shouldn’t have them.

### Moderator
Claim: I’m going to not take the question because it’s a little bit off the point of our actual motion, with respect, but thank you, we’ll take one more? Can you move to the lady… I—you can’t see, but a little bit forward? She’s standing to you? Thank you.

### Moderator
Claim: To the whole panel, can you back off a bit, and say what exactly would constitute supporting or refuting the proposition that gun reduces crime How would you, um, adjust for, um…other contributing circumstances, how do you evaluate what is anecdotal evidence and what is significant evidence, how can you determine that you’re comparing, not comparing apples and oranges. Surely, calling the NRA execrable doesn’t constitute evidence one way or another so—

### Moderator
Claim: Okay, we take your point on the question and thank you for it. Is an AK-47 something that people should have a right to carry around, in the—on the same terms as a handgun. Stephen Halbrook, who represents the NRA—

### Conspiracy Advocate (CA)
Claim: The Second Amendment protects the right to keep and bear arms and the question is what kinds of arms are Constitutionally protected and the Supreme Court just addressed that in the Heller case and said that, handguns are commonly possessed by law-abiding citizens historically for lawful purposes. Rifles and shotguns, now, the term AK-47 is very ambiguous, if it means a real AK-47 that means a fully automatic machine gun. They’re very highly restricted in this country, they have to be registered with the Bureau of Alcohol, Tobacco, Firearms and Explosives. They’re not possessed by that many people, they’re not used in crimes by the way, registered AK-47’s, there’s not very many of them around. But that’s really never where the debate has been, the debate has always been, for example the Brady Center supporting the D.C. handgun ban. What people are concerned about is the ability to have a normal kind of gun in their house to protect themselves and to have rifles, pistols and shotguns for sporting purposes or other lawful purposes. The debate has never been about AK-47, there’s been… there are certain kinds of rifles that might look like an AK-47 and they’re called by the press assault weapons but they’re not assault weapons and they’re not AK-47’s, they just have certain cosmetic features that are similar, so—

### Moderator
Claim: But from a public relations point of view I think the question makes some sense if it’s put in terms of do you—are there certain categories that should be restricted more from the public than handguns are.

### Conspiracy Advocate (CA)
Claim: Real AK-47’s, I don’t know of anybody who advocates deregulating them under current, the federal law which is very strict—

### Scientific Advocate (SA)
Claim: Steve, didn’t you file—

### Moderator
Claim: Paul Helmke—

### Scientific Advocate (SA)
Claim: —something with the Supreme Court arguing that the machine gun ban was unconstitutional? I mean you’ve argued that machine guns should be allowed, right—

### Conspiracy Advocate (CA)
Claim: The—

### Conspiracy Advocate (CA)
Claim: You know, this whole thing is really a red herring—

### Moderator
Claim: Wait, let Stephen answer that, that was a question to Stephen.

### Conspiracy Advocate (CA)
Claim: Right, the National Firearms Act passed in 1934 provides that, certain kinds of highly restricted firearms can be registered and possessed by law-abiding citizens who go through these extreme background checks and… If you were to pass a ban on any kind of gun it does raise questions under the Second Amendment as well as the Interstate Commerce Clause, and there was a Supreme Court where we raised that issue. We did not argue that machine guns were protected by the Second Amendment, we argued that, a constitutional issue was raised by whether they should be banned or not and it’s something that— It had to do with a statutory interpretation, it’s not a case that was a Second Amendment case—the only Second Amendment case the Supreme Court has dealt with is the Heller case, and it’s decided that the kind of guns that we’re all ordinarily talking about here, rifles, pistols and handguns are the ones that are, I’m sorry, rifles, shotguns and handguns are the ones that are constitutionally protected— these other issues are red herrings.

### Moderator
Claim: Gary Kleck, your fellow team member—

### Conspiracy Advocate (CA)
Claim: I think it’s kind of ironic here that we hear an echo of the NRA’s old slippery slope argument, you know, that if they have even moderate control it’ll eventually lead to prohibition, this is kind of the flip-side of that. That if we in any way allow non-criminal citizens to have guns for self-protection that it’s bound to lead somehow down a slippery slope to everybody having machine guns and opening up in church on Sunday—

### Scientific Advocate (SA)
Claim: Now, come on—we are not arguing that—

### Conspiracy Advocate (CA)
Claim: And, also—

### Scientific Advocate (SA)
Claim: —we are not supporting—

### Conspiracy Advocate (CA)
Claim: —you know, you kinda—why do these guys on the other side—

### Scientific Advocate (SA)
Claim: We—

### Conspiracy Advocate (CA)
Claim: —always come up with weirdo anecdotes—

### Scientific Advocate (SA)
Claim: We don’t argue for gun bans—

### Conspiracy Advocate (CA)
Claim: —about the one in a million—

### Scientific Advocate (SA)
Claim: —I’ve got no—

### Conspiracy Advocate (CA)
Claim: —case where—

### Moderator
Claim: Okay—

### Conspiracy Advocate (CA)
Claim: —where things go badly—

### Moderator
Claim: —simultaneous conversation actually is not working—

### Scientific Advocate (SA)
Claim: I’ve got no problems with folks, I’ve got no problems with folks owning guns for hunting, for collecting, for self-defense, I want them to make sure they understand the responsibilities that go with that gun, I want them to know that the Heller case says that there are restrictions that you’re allowed to have on guns and that governments can do those restrictions. And I think if you get that commonsense approach and realize we got gun bans off the table, and we’ve got the whole idea of anybody, any gun, anywhere, anytime is off the table too, let’s figure out what can work to make our communities safer in the middle. That means I think some restrictions on these large-capacity clips, restrictions on machine guns, doing the background checks, limiting the number of guns you can buy at one time—

### Conspiracy Advocate (CA)
Claim: Paul—

### Scientific Advocate (SA)
Claim: —doing things to deal with illegal trafficking—

### Conspiracy Advocate (CA)
Claim: Your organization supported bans—

### Scientific Advocate (SA)
Claim: Those things make sense and it’s not a—

### Moderator
Claim: I want to wrap this up because our third questioner asked the question for the third time tonight, if the United States has so many handguns why is it not the safest nation in the world, and John Lott, I think the question— Or Gary Kleck, you can answer it.

### Conspiracy Advocate (CA)
Claim: And my response is, you know, if we have 600,000 police officers, more than any other democracy in the world, why didn’t we eliminate crime. You know, if we lock up two million people in prison, why didn’t it eliminate crime. The simple answer is no one solution is going to solve crime and no one proposed that it did, that’s a non-argument. Nothing is a perfect solution or a complete solution and you hear no one on this panel make that argument. It’s just a matter of given that we don’t have a complete solution to the problem, what do we do in the meanwhile, what do we do right now, what do individuals do, and why would you want to prevent them from doing something that makes them safer.

### Moderator
Claim: And John Lott, you’re gonna have the final word in this section, go ahead—

### Conspiracy Advocate (CA)
Claim: Okay, thank you. Even across countries, there are countries in the world that have more gun ownership than occurs in the United States, you have Switzerland, for example, you have— which has one of the lowest—

### Scientific Advocate (SA)
Claim: self-defense—

### Conspiracy Advocate (CA)
Claim: —traditionally one of the lowest murder rates in Europe. You have Israel, which probably has the highest gun possession rate in the world and yet, traditionally has one of the lowest murder rates in the world. There are lots of things that affect crime rates across places. If you look in the United States, 50 percent of the counties in the United States have zero murders in any given year. 25 percent of the counties have one murder. Over 70 percent of the murders in the United States are concentrated in just over 3 percent of the counties, those counties represent over 20 percent of the population but they get over 70 percent of the murders. And yet if you look across it, it’s the counties without any murders that have by far the highest gun ownership rates, it’s the, it’s the few percent that have 70 percent where you have by far the lowest gun ownership rates. So, I mean there are lots of things that are going on there, there are drug gangs that I think populate these high-crime urban areas that’s a real problem. And one can go and talk about the problems there, that’ll be a different subject to go into. And—

## Round 3

### Moderator
Claim: All right, John, I’m going to stop you there because of a time issue. I want to point out where we at this point, we’ve wrapped up the, the head-to-head section, and we are at the point, approaching the point where we need all of you to make the decision that decides, how this evening ends. Let’s— to remind you when you came in and we polled you on the motion, “Guns reduce crime,” 13 percent of you agreed, 60 percent of you disagreed. And 27 percent were undecided, we have heard the bulk of the arguments and the back-and-forth. But now we’re going to allow each panelist to sum up his position with a two- minute statement, beginning with the Seattle Chief of Police, Gil Kerlikowske. Chief?

### Scientific Advocate (SA)
Claim: Sure, I want to restate in the second sentence when I did my seven minutes, I said there is no debate about people’s right to own and possess guns. It is what the Supreme Court has defined as the reasonableness issue. John Lott told you that, well, people with concealed firearms rarely commit murders. Guess what, people that go through some type of check and go through a police department to get their concealed firearms permit, don’t go out and commit a lot of crimes. But, he also used the same argument that, well, let me tell you that people wouldn’t make the newspaper if you threaten somebody with a gun who was trying to rob you and it went off and it wouldn’t even be reported. I can tell you that people with concealed firearms permits drive drunk—with a gun in their holster in their car. People with concealed firearms permits in which we sent a clerk home because she issued one on a Monday, and on Friday when she was filing saw that the person had, after getting the permit committed suicide with a gun within the same week. And one of our young women officers who talked a drunken women out of a gun who was holding it to her head and her face and in her lap, and finally was able to wrestle it away, had just gotten her concealed firearms permits. None of those cases made the newspapers, so there are plenty of cases out there, as an example. I think reasonableness should enter into this, it should be more than just being upright and not being blind to allow you to carry a gun.

### Moderator
Claim: Thank you, Chief Kerlikowske, Seattle Chief of Police speaking against the motion. Speaking for the motion in his summarizing statement, John Lott, senior research scholar at the University of Maryland.

### Conspiracy Advocate (CA)
Claim: Thank you all again very much for inviting us here, it’s a great pleasure to be here. You know, there are a lots of things that affect crime. I think—as I said before I think police are the single most important factor. But we can deal with numbers on a lot of these things, we have anecdotal stories, the police chief just went through some. I advise you, you can go and check these things out. The Florida department of—of issuing these concealed handgun permits has detailed records, you can go to their website. The Texas Department of Public Safety, if you just Google Texas Department of Public Safety, concealed handguns, they’ll go through year by year, and tell you how many permit- holders have been convicted for driving under the influence of alcohol. And you’ll—it’s an incredibly tiny number, that this happens. I’m not saying it’s zero. But the rate at which people lose their permits for any type of firearms-related violation, he gave examples of that, you look, state after state, it’s hundreds or thousands of one percentage point. Off-duty police officers in Florida, were arrested and convicted at higher rates by about four times greater than concealed-carry permit holders were arrested in Florida during the same period of time. And I want to respond to John Donohue’s comments about D.C. It’s not true whether you look at rates or you look at numbers that you’re going to see the murder rates fall or robbery rates fall after D.C.’s handgun ban. It goes up in either case. It just goes up more with the rate, and with—when he says it falls what happens is, when you’re just looking at the numbers, the numbers are falling quickly before the ban, and rising relatively slowly after, and what he does is compare the before average, and the after average, and that makes it look like the before average is higher than the after average, so it looks like, well, it’s fallen, but it’s just the average, if you look at year by year, you use it’s falling slowly and then rising faster afterwards. There’s no way you can break down these numbers, and not see that D.C., Chicago, England, Jamaica, Ireland, other countries which have banned guns have not seen increases in violent crime rates afterwards. And D.C. just didn’t rise relative to what it was before, it went from being 15th to one or two in the country.

### Moderator
Claim: Thank you, John Lott. Summarizing his position against the motion, John Donohue, economist and professor of law at Yale.

### Scientific Advocate (SA)
Claim: Again, the D.C. case is a case of a city that was massively depopulating with its most affluent citizens leaving at the time. Steve Levitt, the author of Freakanomics, is a John Bates Clark Award winner, sometimes described as the junior Nobel Prize in economics. He dismissed John Lott’s more guns, less crime theory in his books and writing, when other scholars tried to look at this work they found that right-to-carry laws simply don’t bring down the rate of crime. We have heard the discussion in the United States. There are many features of the United States that would suggest we’d have one of the lowest rates of violent crime, rich countries in general have low rates of violent crime, we’re the richest. We have more people in prison than any other country in, in world history. In fact no European country has even half the level of incarceration rate that we have. Yet, our crime rate is phenomenally high and you hear, the proposition is that more guns would reduce crime, we have 42 percent of the world’s guns in civilian hands in the United States, how many more would we need to get down to the level of crime of our European allies, they mentioned Switzerland and Israel, again these are completely inapposite. Switzerland has a regime in which individuals are in a militia, they take home an assault weapon, and they are given a locked container of ammunition that they’re not allowed to open up, they have to repeatedly come to headquarters and show that they haven’t opened it up and if they have they’re put in jail. In Israel, they do put you in jail if you lose your gun. This is the problem. They keep ignoring the fact that millions, or between 500,000 and a million of guns are stolen every year, that means a gun in a criminal’s hands, even if it’s keeping you epsilon safer by having a gun, when your gun gets turned over to a criminal, that’s making everybody else more unsafe. So it doesn’t matter what happens to the right-to-carry holder, and what he did, it matters what happens to the gun that he got, that then got used by a criminal to kill someone else.

### Moderator
Claim: Thank you, John Donahue. Summing up his position for the motion, “Guns reduce crime,” Stephen Halbrook, attorney representing the NRA in several lawsuits.

### Conspiracy Advocate (CA)
Claim: Thank you, John, I want to respond to two things that Professor Donohue has stated in the Heller case the Supreme Court decided that the Second Amendment guarantees the individual right of, of individual citizens to keep and bear arms including handguns. That’s the position that the NRA has taken, for many, many decades through— of its history since 1871. And Mr. Donohue said that the NRA does not tell the truth on the Second Amendment. Well, then the Supreme Court doesn’t either because that’s what the Supreme Court held in the Heller case. If you walk out back and you go to the bookstand here at this auditorium you’ll see a book called The Founders’ Second Amendment, which I authored-- it’s a new book on the history of the Second Amendment and you’ll see, basically agreement with what the Supreme Court held, that it is an individual right, that the NRA did not make it up. In addition, I’ve been to Switzerland many times and participated in shooting matches with military rifles. And you can buy all the ammunition you want at the shooting ranges and at gun shops. You’re issued a tin of ammunition that you’re not allowed to open because they want it to be available if the militia army has to be mobilized, but there’s no restriction on your ammunition usage or purchases, so it’s— every Swiss male when he enters age 20 is issued a military assault rifle and he keeps it at home. And there’s an extremely low crime rate in Switzerland. A remaining thought I would like to say in favor of the proposition, is, I would like everybody to kind of think about yourself. You’ve heard here tonight, that we’re all potential murderers, that if we get angry if we have a gun we’re gonna kill somebody. It’s just not true, most people with these concealed-weapon permits, are just like you and me, they’re normal people, they don’t just suddenly get angry or, or have a couple glasses of wine and, and go on murderous sprees. We’re not like that, most Americans are good people—they can be trusted with guns, and they should be trained. Children should be trained in gun safety but to somehow act like all potential criminals is just, completely beyond the pale.

### Moderator
Claim: Thank you, Stephen Halbrook. Summing up his position against the motion, “Guns reduce crime,” Paul Helmke, president of the Brady Campaign and Brady Center to Reduce Gun Violence.

### Scientific Advocate (SA)
Claim: Again I want to thank all of our listeners tonight, the question you have to ask yourself is, did the other side prove its case, did they prove that guns reduce crime. You haven’t really heard any evidence that shows that it did. And I think the question you should ask yourself to just get a gut-check on this is, when you’re at the next sporting event, or when you’re sitting in the restaurant, would you feel safer thinking that everyone had a gun, or that no one had a gun. The reason that you react that way, is because you know instinctively that we make it too easy for dangerous people and people that don’t know the responsibilities that go with guns to get guns. I ask the question, why aren’t we the safest country in the world if we’ve got so many guns. It’s because we make it too easy, we don’t know where those guns are, we don’t know who has the guns. And if you have a gun, and again I’m not anti-gun and if you want a gun and understand the responsibilities, fine. But there are responsibilities that go with it, the Supreme Court made it clear there are restrictions that go with it. Where do the guns come from that the bad guys, that the gang members get. They steal them from people like you. They steal them from gun stores who lose their—quote, “lose” 30,000 guns every year. They get them through straw purchase. There are no limits on the number of guns you can buy at one time, there are very few limits on the type of guns you can buy. In most places in this country there really are no laws…very few laws, restricting who gets guns. We make it too easy for dangerous people to get guns.

The way to reduce crime is to do things like background checks. Fight the illegal trafficking in guns. Say that some guns should not be in the hands of the civilian population. Those are things that can help take down the crime rates in our communities, not flooding our communities with more guns. Thank you very much.

### Moderator
Claim: Thank you, Paul Helmke. And our final speaker, as we approach the moment of truth…speaking for the motion, “Guns reduce crime,” Gary Kleck, professor of criminology and criminal justice at Florida State.

### Conspiracy Advocate (CA)
Claim: You may remember I started out my opening remarks by saying you sometimes need to listen for the silences, and I think the panelists on the other side demonstrated that because they didn’t in fact address the evidence that we presented…Paul Helmke insists we didn’t present any evidence, we cited some of the most thoroughly vetted scientific evidence we have on the question. Study after study repeatedly showed the same thing, it showed defensive gun use as common, it showed defensive gun use as effective. It shows that after we pass these shall-issue carry laws and make it easy to, to get a carry permit, crime does not go up… It’s also a sign of a weakness, of a particular position when people have to misstate what the issue is, remember the proposition was that guns reduce crime, okay, do they make you safer to have a gun…well, we didn’t really hear anything about that. Instead we hear Paul Helmke saying would you feel comfortable with everybody having a gun, well of course that’s not the issue, nobody here proposed that because of course “everybody” includes lunatics, convicted murderers, robbers, rapists and so on. It’s not the proposition, and in fact no one here even secretly thinks that we ought to do that, it’s not an issue, so why not confront the issue, do guns reduce crime. Well, in fact guns in the hands of non-criminals, guns in the hands of crime victims, do make them safer. So what does this imply for policy, well, the implication for policy is, let’s do what we can to keep guns away from criminals, but that should not include taking them away from non-criminals who would use them to save their lives, to prevent the completion of rapes and robberies, to prevent injuries, and to prevent the loss of property, we should instead do what common-sensically most of America has been doing for decades which is moderate controls aimed at preventing criminals from getting guns but without denying them to non-criminals.

### Moderator
Claim: That was Gary Kleck, thank you. And now we are at the moment of truth, you can turn once again to the keypads by your seats and we want you to vote on our motion, “Guns reduce crime.” Press “1” if you support the motion, press number “2” if you are against, press number “3” if you are undecided, it will take us about 90 seconds to tabulate the results, in the meantime I want to point out what’s coming up next. On Tuesday, November 18th, the motion of our debate will be, “Google Violates Its ‘Don’t Be Evil’ Motto.” Panelists for the motion include Harry Lewis, a professor of computer science at Harvard, Randall Picker, a professor of commercial law at the University of Chicago Law School, and Siva Vaidhyanathan who is professor of media studies and law at the University of Virginia. Against the motion, we have John Batelle who is founder, chairman and CEO of Federated Media Publishing, Esther Dyson, an investor in information technology companies, and Jeff Jarvis, director of the interactive journalism program at the City University of New York. These debates as we’ve made clear several times can be heard on more than 150 NPR stations across the country. So just check your local NPR station for the date and times of the broadcast. The results are coming down…as I point out the copies of books and DVD’s, books by all of these people are on sale in the lobby… And they are very willing to sell and sign. And finally a reminder that our debate on December 2nd, “Bush 43 is the Worst President of the Last 50 Years”… which was not meant to be an applause line— will be recorded for broadcast on BBC World News Television and to accommodate that taping for that broadcast, we will be moving the debate to the Symphony Space. That’s at 95th and Broadway, and for more information, please visit our website, and now, the results… Hmm. Before the debate, 13 percent were for the motion, 60 percent were against, and 27 percent were undecided. After the debate, there was movement on all fronts but it looks as though the motion— the side for the motion moved more of you. 27 percent agree with the motion that guns reduce crime, 64 percent of you disagree, and now only 10 percent of you are undecided. So, it was a close, a close call, with a little bit of an edge to those for the motion in terms of moving and changing minds. Congratulations to all of our panelists.
