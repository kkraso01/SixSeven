# Debate Transcript

Topic: Clean Energy Can Drive America's Economic Recovery
Motion: Clean Energy Can Drive America's Economic Recovery

Debate ID: clean-energy


## Round 1

### Moderator
Claim: True or false: Clean energy can drive America’s economic recovery. Well, let’s have it out. This is a debate from Intelligence Squared U.S. I’m John Donvan of ABC News. We are at the Skirball Center for the Performing Arts at New York University where we have two teams of debaters, two against two. They include a governor and investor in green energy, a thinker on green energy, and a writer on the topic. They will be trying to change your minds because this is a debate. It is not a seminar or a panel discussion. It is a contest, a contest of ideas and logic and well-presented arguments. In this case, you, our live audience, are our judges. By the time the debate has ended, you will have been asked to vote twice, once before the debate and once again at the end of the debate. And the team that has changed the most minds in the course of the arguing will be declared our winners.

So let’s go to register your first vote on the motion.

Our motion is “Clean energy can drive America’s economic recovery.” If you agree with the motion, push number one. If you disagree, push number two. And if you’re undecided, push number three. And if you feel you’ve made a mistake, just correct your mistake, and the system will lock in your last vote. I just want to ask-- technically, I have a problem with the wire into my ear, and I’m hearing delightful music, so-- So I’ve pulled it out. So we’re going to take a little bit of a break. In San Francisco and Washington, I understand they’re actually in a restaurant, so, at this point, while we’re doing this, you can all move on to the hors d'oeuvres. can I just get a test from the truck that I can-- yeah, I hear you clearly, terrifically. Okay, we’re all back in business again. So you’ve now voted. That has been locked in, and at the end of the debate, you’ll vote again after the closing arguments, and very quickly we will have the results.

So, our motion is “Clean energy can drive America’s economic recovery.” On to round one: opening statements by each debater in turn. They will be seven minutes each. And debating first for the motion, I’d like to introduce Bill Ritter, former governor of Colorado whose state has the fourth highest concentration of clean energy workers in the country. He’s now director of the Center for the New Energy Economy at Colorado State University. And Bill, I think, with a resume like that, America wants to know what kind of car does a former governor of Colorado drive?

### Conspiracy Advocate (CA)
Claim: That’s a great question. I have four kids, my wife, family of six. So, I have a lot of options. We have our own fleet.

I did just, because I’m commuting, buy a 1999 Saab that gets a little over 30 miles to the gallon.

### Moderator
Claim: So, you’re putting your money where your mouth is.

### Conspiracy Advocate (CA)
Claim: I was driven for four years in a row so I had to do something other than find a driver.

### Moderator
Claim: It’s nice to be driven. Ladies and gentlemen, Bill Ritter.

### Conspiracy Advocate (CA)
Claim: Thanks, John. And thank you for being here tonight to discuss what I think is one of the most important issues that we have, really, as a nation facing us. You know, Americans are not a group of people that sit out a revolution. If you think about our founding and where we come from, we began with a revolution, the American Revolutionary War. And there have been a few revolutions in our time as well that Americans have not just participated in, but they’ve led. Think about the Industrial Revolution where we established really our ability to be an economic powerhouse.

Or, more recently, the information revolution where we reaffirmed in the minds of the world our ability as innovators and creators and inventors, people who really understand the power of technological development. What is this revolution that is upon us now? It is the clean energy revolution. And it’s global. And the question we have before us as Americans is will we lead or will we follow? Will we accept a place on the sidelines, or will we actively participate in moving this issue ahead?

Tonight I’m joined by Kassia Yanosek, who’s my partner in this. And you’re going to get to hear Kassia as well, but we stand for the proposition tonight that, in fact, clean energy can drive America’s economic recovery. Energy itself, if you think about the revenues generated globally, the largest industry in terms of revenue generation.

So, if we get it right, it absolutely can be a significant part of our economic recovery. And it’s important for us to define the terms to some extent. When people hear “clean energy” in a lot of places in the world, they think it’s just wind or just solar. Kassia and I tonight, we’re going to talk about clean energy in this broad spectrum. It is about renewable, about solar and wind and geothermal biomass, but it’s also about all those parts of the spectrum that involve the things that we’re doing to promote clean energy, and the research and development laboratories across this country, both public and private, how you commercialize that technology and get it into the marketplace, those things that involve transmission and Smart Grid technology that help us to manage loads on grid, those parts of the clean energy world that involve transportation-- think electric vehicles or fuel cell vehicles, hybrid cars-- but again, the broad spectrum.

When we think about clean energy, we do think about natural gas and believe that natural gas and nuclear and even clean coal can perhaps play a role in building out a clean energy economy in America and that it has to be every part of that, from stem to stern, in terms of our thinking about it. It’s important for us to understand as well that workforce development has to be part of our policy considerations.

So one of the reasons I’m here tonight and one of the reasons I was fortunate to be invited is because, as the Colorado governor, I said in Colorado, “We’re going to build a new energy economy.” And I said this when I was campaigning, and over a four-year period, I signed 57 different bills into law, bills that we believe made a tremendous difference as it related to our energy portfolio going forward, but particularly relevant to tonight’s topic, made a significant difference in our ability to see economic development attached to clean energy. One of those bills was a renewable energy standard bill in the first 100 days that took us to a 20 percent standard by 2020 with a rate cap in place for consumers.

In fact, last year, the utility and I, after talking with each other, said, you know what? We can get to 30 percent by 2020 with the same rate cap in place. So, as a state, we’ve got a 30 percent renewable energy standard. But in those 57 bills, we did Smart metering, meaning people who were residential and industrial consumers could actually get paid if they put energy back onto the grid. We did a variety of things to inspire the bill out of transmission, inspire new technology, energy efficiency. When we talk about clean energy, energy efficiency is one of the most significant things we as a country can do to move this country in a direction toward, in fact, a clean energy economy. So I’m not going to go through the 57 bills, but what I’ll tell you is the proof is in the pudding. We have significant economic development tied to that, and I’ll give you just a couple of examples. Vestas wind turbines, the Danish company, building wind turbines in Colorado, made the announcement just after I made the-- signed the bill.

That allowed us to go to a 20 percent by 2020, they in fact then have four factories since that they’ve announced that, at the end of the day, it’s going to be 2,600 employees, a billion dollar investment. SMA, it’s a German company-- they’re manufacturing solar inverters in Colorado for the first time outside of Germany. We have home-grown companies, companies, again, where the technology was developed in a laboratory in Colorado we have, the National Renewable Energy Laboratory or one of our research universities, or even private laboratories. One of the thin-film photovoltaic technologies was developed in a Lockheed Martin laboratory, and so we’ve commercialized that and see these companies grow from the ground up. We’ve seen all sorts of growth in this sector, even during a recession. And it’s not just Colorado. If you look around the country, in places in the Midwest, in the South, in the Southeast, in California, in the Northeast, here in New York, we’ve all sorts of investments in clean energy that is related to job growth.

If you look at the last 10 years and if you look at Michigan for example where they've had terrible job loss. In many of their conventional sectors, they’ve seen job increases, a 5.7 percent increase in jobs in Michigan over the last decade. Colorado had an 18 percent increase and as John said we’re the fourth if you look at where we stand, we are fourth in terms of how we have clean tech workers as a state. Now in my last minute I’m just going to tell you there’s a reason for doing this that’s beyond just the economic development. We have a powerful example in Colorado, powerful examples around the country that demonstrate economic development as a part of this. But there’re a couple of other things that are very important too. When you build out a clean energy economy, you actually do something in a very significant way to address the environmental challenges that are upon us. Even if you don’t believe that global warming is human caused there are still significant environmental challenges. They are a part of a carbon based energy production sector.

And in addition to that you wind up addressing another very serious problem we have in this country which is energy security. Domestically produced energy does a variety of things including reducing our trade deficit and reducing it in such a way that we can look and say the health of the country is better going forward because we have proposed an agenda that relies upon domestically produced energy. It’s the trifecta, right? It is about energy security, it’s about environmental security, and it’s about economic security. Thank you very much.

### Moderator
Claim: Thank you, Bill Ritter. Our motion at this Intelligence Squared U. S. Debate, "Clean energy can drive America’s economic recovery." Now to speak against that motion, Steven Hayward, a fellow at the American Enterprise Institute, a senior fellow at the Pacific Research Institute for Public Policy, how wrote when Al Gore was given the Nobel Peace Prize you wrote that it was a further degradation of a-- a further debasement of a once prestigious award for Parson Al-- are you saying our former vice president’s a little preachy?

### Scientific Advocate (SA)
Claim: I think it’s fairly self evident, isn’t it?

### Moderator
Claim: Ladies and gentleman, Steven Hayward.

### Scientific Advocate (SA)
Claim: Thank you, John. Our case against the motion tonight comes in two main parts, first that it represents a brazen case of bait and switch. I thought there’d be two of them, I’ve already heard of the third one, already tonight. And second that it rests on a basic but surprisingly widespread economic fallacy that paying more for energy will somehow make us richer. There are a number of collateral arguments in our case which my partner, Robert Bryce, will explore further, such as the fact that most forms of so-called clean energy are inferior energy sources, ill suited to many of our needs. Now, the bait and switch comes in just two parts, I’ll have to leave the third for later. We’ve been told for the better part of the last two decades that we need to make a rapid transition to clean energy away from fossil fuels in order to stave off climate catastrophe. And all of the official assessments of the matter from the national and international bodies that have studied the matter such as the U.N.’s IPCC concluded that the cost of doing so would be substantial.

And the pessimists said the costs that would hurt economic growth and lower GDP. The pessimists said it would hurt a lot, the optimists said the costs would be only modest, but the point is all of the assessments concluded that the sign before the economic cost would be negative. But with the collapse of meaningful climate legislation here and abroad, and the arrival of the great recession, suddenly the argument for clean energy has been shifted into the form of tonight’s motion. Clean energy will make us richer, it is the path to prosperity itself. Happy days are here again. It’s the new domain of free lunch economics, I call it three lumens. Now, the basic problem with so-called clean energy is that nearly every form of it is more expensive than the fossil fuel energy it seeks to displace. Now, I know of no economic theory that says the economy benefits by reducing the purchasing power of consumers. The case for this motion rests on the same fallacy as the retailer who loses money on each sale, but promises to make up for it with additional volume.

The second bait and switch concerns what we mean by clean energy, because the working definition of clean energy seems to shift to make the term almost meaningless. Typically clean energy has meant purely renewable sources such as wind, solar, tidal energy and geothermal, along with environmentally neutral technologies like biomass and biofuels, though I could add that corn ethanol badly failed the test of environmental neutrality. And despite more than 30 years of strong emphasis on these sources they still account for less than five percent of our energy supply. But now suddenly we’re told that natural gas is a clean energy source that should be used to displace coal. But there’s something very odd if we’re now counting a fossil fuel, a finite hydrocarbon, as a clean energy source. Do carbon dioxide emissions no longer matter in the definition of clean energy? Consider that climate policy orthodoxy says we need to reduce our carbon dioxide emissions to one billion tons by the year 2050. Today right now, carbon dioxide emissions from current use of natural gas 1.2 billion times.

Above the target for every source for the year 2050. This is why the Sierra Club, two weeks ago, changed its position and said we should now make it an object of national policy to phase out natural gas entirely by the year 2050. Their director of climate and energy told the Politico two weeks ago, quote, “We want people to know that natural gas is not a clean fuel.” Mark Brownstein, Environmental Defense Fund, told Politico, quote “Simply because coal is awful doesn't mean natural gas gets to be terrible.” How is it that natural gas, which, as I say, produces over a billion tons of CO2, is clean energy, but nuclear power, which produces zero CO2 emissions, is usually considered not to be clean energy. Governor Ritter includes it as clean energy. The U.S. Congress specifically excluded it from Climate and Energy legislation the last two years. Moreover, if natural gas is clean energy, then guess what, so is oil. An awful lot of natural gas is produced in the production of oil, and oil has almost the same green house gas emissions per unit of energy produced as natural gas.

And if you want to spend enough money, you can make coal clean. Governor Ritter used the same phrase President Obama likes to use: “clean coal.” And so you're left with the rest of the clean energy suite that cannot scale up without mandates and massive subsidies from taxpayers. And even then, they still fail. In recent months, you've seen solar power-makers like Solyndra in California, and Evergreen Solar in Massachusetts, lay off a thousand employees, and cut about half their production capacity, despite receiving nearly a billion dollars in loan guarantees and subsidies from government. And we've seen a number of bio-fuel companies fail despite mandates of lavish subsidies.

Now, the idea that clean energy will be the sector that leads us out of the recession is equally risible. There are a number of studies on this. I'll give you one quotation from a study from the Stanford University, a very highly-regarded energy modeling forum that concluded, quote, “The advantages of increased jobs for renewable energy are vastly overstated at costs prevailing today.” They note that most energy investments produce between two and six jobs.

That's true of conventional oil and coal, and natural gas, but also of renewable sources like windmills. Well, of course, if you spend a million dollars on any sector of the economy, the Department of Commerce's models say you get about 9.7 new jobs. That's why the energy modeling forum concluded, quote, “Electricity generation across all sources creates far fewer jobs than other activities in the economy. Subsidies to either green or conventional sources will detract, rather than expand economy's job base, because they will shift investments from other sectors that will create warms climates. In other words, if you're looking for a sector to generate job growth, to lead us out of the recession, the energy sector, clean or otherwise, isn't it.

Now, I'll conclude with an observation on the essential absurdity of this motion. If this motion were true, we would not need to debate it at all. Did we have to debate whether railroads, and automobiles, and the telegraph, and the telephone, would transform transportation and communication? Did we have to debate whether the technology revolution and the Internet would change our lives?

And change American productivity? Did we, a hundred years ago, have to debate the motion that new oil, coal, and gas supplies will power the next generation of American industry? Of course not. And above all, did we ever need a mandate from the government, like a renewable portfolio standard, to get consumers to buy cars or desktop computers? The answer to that is fairly obvious.

Clean energy, however defined, does not resemble any of the past histories of recession- busting forces. And the odd thing is, most recession-busting forces, like the housing sector in previous recessions, are because of this pent-up demand. There actually isn't a pent-up demand for new energy at the moment. Energy consumption in America has fallen sharply as a result of the recession. Our energy consumption is down by the largest percentage amount since the end of World War II. So building new energy supplies right now makes about as much sense as building new tracts of suburban housing.

And by the way, none of the ideas I've heard tonight, with the partial exception of electrified cars such as hybrids, do anything to affect the one part of the energy picture that bothers us the most, and that's our dependence on foreign oil. Most of what you're going to hear tonight is about the electricity sector. We can put a windmill on every single house in America, and put solar panels on every roof, and it will not reduce our oil imports at all. The motion, in my mind, fails badly.

### Moderator
Claim: Thank you, Steven Hayward. So here's where we are, we are halfway through the opening statement in this Intelligence Squared U.S. Debate. I'm John Donvan of ABC News. We have four debaters, two teams of two, fighting it out over this motion: “Clean energy can drive America's economic recovery.” You've heard two opening statements, and now onto the third. Kassia Yanosek is founding principle of Tana Energy Capitol, and co-founder of the U.S. Partnership for Renewable Energy Finance. We also want to thank her, we were originally going to have, Dan Reicher, who was going to be sitting in this seat. He is literally snowed in, after an avalanche hit a road in Utah last night.

Kassia came extremely highly recommended and was also an enormously good sport to step in on several hours’ notice. So we want to thank you first of all for that. And, Kassia, when I did my quick research on you, I went to YouTube and I found a video of you standing in a business suit, holding a live frog, which was what?

### Conspiracy Advocate (CA)
Claim: Well, first of all, I love frogs. And I’m willing to hold one in a business suit. But it was a function I went to in the U.K. for the Prince’s Rain Forest project, so it was--

### Moderator
Claim: It was a promotional.

### Conspiracy Advocate (CA)
Claim: It was a promotional.

### Moderator
Claim: And I’m assuming that no frogs were harmed in the filming of that promotion.

### Conspiracy Advocate (CA)
Claim: No, it was a video effect.

### Moderator
Claim: Ladies and gentlemen, Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: Thank you. Again, my name is Kassia Yanosek and I come to you tonight as an investor. I’ve been an investor in the energy sector for the past decade, and I used to invest in dirty energy.

My background includes investing at Bechtel Enterprises, the private equity arm of Bechtel which is a large engineering firm. I also worked at BP. So I started out my career investing in coal and gas. And, you know, as an investor, I look for the biggest growth markets. So that’s why I’m a clean energy investor right now. I don’t sit in an ivory tower or a think tank. Instead, I often sit in airplane seats, travel around the country, roll up my sleeves, meet with energy innovators and entrepreneurs, and I figure out where to create value in this economy, which is why we’re here tonight. And this is what we’re talking about tonight. You know, most recently, before starting my firm, I was a senior member of a billion dollar private equity firm that’s deployed millions of capital in the sector of clean energy. I currently invest with New York investment houses around the subject of innovation and clean energy technologies, and that’s where I think the opportunities are in this market. So I’m going to give you the real story tonight about why clean energy will drive our economic recovery.

The other thing I’d like to point out is that I actually don’t think we should be having this debate-- not will it or won’t it drive economic prosperity but how it can drive our economy. We need to start competing and get out from behind our computers where we write op-eds, stop resting on our laurels of the past, stop wimping out about how China is going to cream us. Is that any way to win a match or a race? So my goal tonight is to convince us that we can continue to be an innovation leader in other sectors that we’ve done in the past, and that clean energy is the next growth market for the U.S.

And here’s why clean energy can drive economic growth. I’m going to give you three reasons. First of all, innovation in new industries drives job creation and investment, and I’m going to provide some examples, from I.T. to the auto industry, and also why government has in the past, and it needs to continue to be, an integral part of this growth for the energy sector.

Number two, clean energy will drive exports which are critical to our future growth. So, instead of complaining about China, let’s start competing so we can sell into China. And then, third, we do need to talk about our dependence on oil. Oil does not help economic recovery. Our dependence on oil doesn’t help economic recovery; it actually hinders economic recovery. So we actually need a broad menu of energy options to reduce our dependence on any one commodity, which smoothes out volatility and helps our economy grow.

So, point number one: innovation drives job creation and lower costs in our energy sector. You know, we can see this in our I.T. markets. We now lead the world in research, product, and deployment. And certainly, Silicon Valley has been a huge driving force of the U.S. economy. Right now, I believe that about 16 percent of our total exports are related to advanced technologies. Well, guess what?

That wasn’t part of our economy 30 to 40 years ago, so clean energy has a great future ahead of it if we’re going to actually put our heads together and start innovating. And government was a big part of that. DARPA which is an arm of the government was instrumental in the development of the Internet.

And secondly, the auto industry-- dinosaur industry. You know, we got our pants beat off by Japan. But guess what? Detroit is turning around. We’re starting to see Ford and Chevrolet start developing electric vehicles. There’s a lot of activity out there, and it’s winning accolades. So it really debunks this view that we can’t afford to have this job creation in the United States.

And then, finally, without going too much into the weeds, I’ll point out some obvious statistics about how clean energy is driving investment in jobs. Last year, $243 billion was invested in clean energy globally. This is essentially a 25 percent compound average growth rate that we’ve seen over the past five years. And this is really one of the biggest drivers that we’re seeing in the markets today.

In the past 10 years clean jobs grew 9.1 percent in the United States while total jobs grew by only 3.7 percent. So I have a little bit of different perspective and some different statistics than my opponents over there. And then, finally, I’ll point out that costs are coming down, count down the curve. Electric batteries cost about $1,000 a kilowatt hour two years ago; today it’s about half that, and we’re on track for some very competitive technology that we’re going to see in our electric vehicles within the next 10 years. So we’re starting to see a real big steepness in the innovation curve.

Point two, clean energy will drive exports which are critical to our future growth. It’s important that we grow a domestic market not only for us but for our export markets. It’s an opportunity worth trillions of dollars and millions of jobs. My opponent actually pointed out a very important point: There is not a whole lot of energy growth going on in the U.S. and in the next 10-20 years. Ninety percent of the growth and energy consumption over the next two decades is going to come from developing countries.

So we better get on that so we can actually benefit from the growth that we’re going to see in these export markets. So, finally, we need to learn from the information technology industry. We need to develop the energy economy the way we did the I.T. And we’re starting to do that. Clean tech really is where information technology was 30 years ago and where biotech was 20 years ago. So we’re at the beginning of a very long and prosperous future for this sector. And then, point three, we need a portfolio of energy choice. Dependence on fossil fuels doesn’t help economic recovery. As I said, it actually hinders it. You know, we’re seeing $100 oil. We’ve seen this happen before, and price spikes really do not help the economy. Rising energy prices act as a drag on GDP growth. A 10 percent oil shock is-- could actually lower GDP growth by .2 percent per year for the next two years, and that’s a recent statistic that Goldman Sachs just put out.

We’re also seeing that high oil prices can increase inflation which compresses corporate margins, impacts the consumers, so when we talk about the price of energy, I don’t necessarily see that the current state of affairs in fossil fuel is helping the energy economy in keeping costs down for consumers. So, essentially, with that, I’m going to close with bringing you back to the focus of this debate, which is that clean energy can drive the future of our economy. And, frankly, if you’re not for the clean energy economy, then you’re not for economic recovery. Thank you.

### Moderator
Claim: Thank you, Kassia Yanosek. Our motion is “Clean energy can drive America’s economic recovery.” And here to speak against the motion, Robert Bryce. He is the author of “Power Hungry: The Myths of “Green” Energy and the Real Fuels of the Future.” He’s a senior fellow at the Manhattan Institute and former managing editor of the Energy Tribune.

And you write, Robert, in one of your books, about your experience with solar panels, which you’ve installed on your house in Boston and you conclude that, after all, you’re just not sure they’re worth it. Why?

### Scientific Advocate (SA)
Claim: That’s true.

### Moderator
Claim: What happened up there on the roof?

### Scientific Advocate (SA)
Claim: I have to get up there and clean them, for one. Second, the economics-- well, the reason I did, I got a subsidy, a nice big fat subsidy. The city of Boston paid two-thirds of the cost, so I got a $23,000 system for about $8,000. But the payback, assuming no cost of capital and assuming electric rates stay flat, is 20 years. The life of a panel is about 20 years, so I don’t know whether it’s a good investment or not. We’ll see.

### Moderator
Claim: Okay, ladies and gentlemen, Robert Bryce.

### Scientific Advocate (SA)
Claim: So, please, by a show of hands, who here is in favor of dirty energy? One. Okay, two maybe. Okay, thank you. That’s what I expected.

Well, the fact is that clean energy sounds tremendously appealing. There is no question about it. And debunking clean energy is a dirty job, but Steve and I are here to do just that.

Reality is that clean energy is not a specific thing; it is a marketing slogan. If you remember, the Waxman-Markey Bill in 2009 was called the American Clean Energy and Security Act. To the specifics, Governor Ritter mentioned natural gas. I am as pro- natural gas as anyone. I’m also ardently pro-nuclear. N to N, natural gas to nuclear-- I believe these are the paths to the future for a number of reasons. But he also included in his statement that coal, natural gas, nuclear, wind, and solar are clean. The reality is if all of our energy sources are clean, then none of them are. Regarding clean coal, I view that oxymoronic, akin to family vacation or jumbo shrimp. Took a while, but I’m glad you finally got it. Thank you. Wind energy is often viewed as the political darling of the moment. This is the clean energy source of the future. Well, if you saw WGBH just yesterday they had a story about Falmouth, Massachusetts, in which they talked about the objections and, in fact, the strenuous protest by local residents against a new wind turbine in that town. I can point you to localities all over the world. I have interviewed people in New Zealand, Australia, Ontario, Nova Scotia, Missouri, Wisconsin, New York, some very heated debates here in New York State over the sighting of industrial wind turbines. What is the problem? Infrasound, low level noise that is driving people out of their homes. The wind energy industry says, “Oh, well, these people that are complaining just need psychological counseling." I kid you not. This is a serious problem that they cannot solve and they try to dismiss it out of hand, it cannot be resolved.

My opponent said that natural gas or rather that fossil fuels can’t possibly lead to any kind of economic recovery, I completely disagree. Natural gas today is selling for less than $4, why? Because of a tremendous technological innovation in the upstream oil and gas business. It's selling for about $4 per million BTUs, that’s a reduction of about $3 per MMBTU compared to just three years ago. That reduction in price is one of the rare bright spots in the commodity markets in the U.S. It is now saving American consumers $65 billion per year or $180 million per day, and that’s a minimum number. The reality is clean energy is such a nebulous phrase it cannot possibly be supported because the phrase doesn’t mean anything, therefore, you must vote against. Second point, green jobs do not exist or are so expensive as to be crippling to the economy.

If you’d believe the corn ethanol scammers, one of the longest running robberies of taxpayers in this country’s history, they just put out a report last month that said they’re-- they support 70,000 jobs. Well, if you believe the Congressional Budget Office numbers, the total taxpayer cost of the corn ethanol scam is over $16 billion. That works out to $230,000 per job. What about the wind industry? We hear this continually from the American Wind-- Energy Association, "Oh, we’re creating all kinds of manufacturing jobs, blah, blah, blah, blah, blah, blah, blah." Texas Comptroller Public Accounts Susan Colmes just came out with a report in December, estimated that every wind job in Texas, where I live, Texas leads the country in new-- in wind generation capacity, 10,000 megawatts, each job associated with the wind industry costs $1.6 million to the taxpayers.

Third point, clean energy cannot possibly drive America’s economic recovery because it is simply too small in scale. I pride myself on doing my research, doing my numbers, here they are.

Every day coal provides about 10 million barrels of oil equivalent to the U.S. economy. Natural gas provides about 12 million barrels of oil equivalent every day to the U.S. economy. We also use roughly 17 million barrels of oil. So roughly 39 million barrels of oil equivalent from those three hydrocarbons, that dirty, nasty energy that nobody likes but everybody uses. Okay, so what about the political darlings of the moment, the clean energy sources that we’ve been discussing here? Non-hydro sources because we can’t build any more dams here, geothermal, wind, biomass, and solar. In 2010, according to the EIA they provided 166 million megawatt hours of electricity to the U.S. That works out to277,000 barrels of oil equivalent per day. So how does that compare then? If we just look at the two dirty, nasty sources of energy, oil and coal, they provide 100 times as much energy to the U.S. economy as the political darlings of the moment, the clean energy darlings of the moment.

And if we include natural gas, which I believe is clean incredibly pro-natural gas, the ratio is 140 times as much energy from the three hydrocarbons as we get from the clean energy sources. We could double, triple, quadruple, quintuple the amount of energy that we’re getting from the clean energy sources that we’re discussing here, it will be so small as to make no difference to the U.S. economy, and it certainly will not drive America’s economic recovery, therefore, you must vote against the motion.

Final point, clean energy cannot fuel America’s economic recovery because it is simply too expensive. Latest data from the Energy Information Administration estimate that over the next five years or so, gas fired electricity will cost about $63 per megawatt hour, onshore wind will cost about 50 percent more than that, offshore wind, four times as much as that, and solar thermal generated electricity, five times as much as that.

In January, The Los Angeles Times reported on the city of Los Angeles' goal of having 33 percent of its electricity coming from renewables by 2020. I quote from The Times, that, “this push for renewables could result in electricity rate hikes of five to eight percent in each of the next five years.” What's happening now, the city of Los Angeles is quietly rolling back the renewable targets. In the governor's, Governor Ritter's home state, electricity rates have increased by 21 percent over the past six years, and the Denver Post just reported they are likely to increase by 20 percent over the next six. Over the last six years, the increase has been twice the rate of inflation. The reality is that oil price spikes hurt the U.S. economy, there's no question about that. With the coming rate, electricity rate hikes that will come from these renewable portfolio standards in the electricity markets, will be even worse for the economic recovery. You must vote against the motion. Thank you.

## Round 2

### Moderator
Claim: Thank you, Robert Bryce.

And that concludes Round One of this Intelligence Squared U.S. Debate. Now onto Round Two, where the debaters address each other directly, and answer questions from you in the audience, and from me, John Donvan. We're here at the Skirball Center at New York University in New York. We have two teams of two on the stage. Bill Ritter and Kassia Yanosek are arguing for the motion “Clean energy can drive America's economic recovery.” They are arguing that clean energy is a growth field, it is a revolution, you don't sit out revolutions. Their opponents, Robert Bryce and Steven Hayward, are arguing, as a resolution, it's very tiny, more of a fantasy.

We're going to, now, take questions from you and from them, and have them mix it up directly. And I want to go to the side arguing against the motion, against the clean energy as a solution for America's economic recovery. Your opponents have made the case that, that the clean energy field represents a field of innovation, that innovation leads to jobs, innovation leads to exports. They cite the computer industry in our lifetimes as an example of this.

Okay, so there's a certain logic to that, that I think you can see.

### Scientific Advocate (SA)
Claim: Sure.

### Moderator
Claim: Take it on, Robert Bryce.

### Scientific Advocate (SA)
Claim: I'm glad to, this is an easy one. What is the most admired company in America today? While it might be Google, I would argue it's Apple. Apple's market cap today is over $330 billion. What does Apple do? It designs its products in the United States, and manufactures them in China. Are we supposed to be opposed to that? Are we supposed to say, “Oh, no, Apple, you have to, you have to manufacture those products here in the U.S., even though it would be much more expensive, and then you need to export them”? This makes no sense whatsoever. Apple is an incredibly dynamic company, and incredibly successful company, one of the most admired companies in the world, and yet we're told, “Oh, no, there's something wrong with that”? Further, and another, just, quick point. We heard that $243 billion is invested globally in clean energy. I have no doubt that that's the, maybe, the correct number.

I can tell you that, here in the United States, the upstream oil and gas industry spends that much alone drilling new oil and gas wells every year. You don't think that they're innovating? Of course they're innovating. And what have we seen? Incredible success in the shale gas revolution that is driving--

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: --down the costs of

### Moderator
Claim: So let me go to your opponents, the two arguing for clean energy as a driver of the economy. You've heard, he's basically saying that, yeah, there's innovation, but there's not much bang for the buck. Can you take that on? Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: Sure. Well, I think that, you know, first of all, we're going to have to define what clean energy is. Clean energy is not just wind and solar, which I agree makes up a very small portion, less than eight percent, of our global, of our U.S. power generation. We have to include cleaner sources, cleaner ways to develop and produce energy that's being produced from coal, and natural gas, and nuclear. So when we talk about clean energy and the opportunity for economic growth we're not just limiting ourselves to renewables here.

We're actually bringing in the opportunity to bring down costs, improve efficiency. One thing we haven't even started talking about tonight is actually energy efficiency, and the opportunities there. So, first, I would say that, number one, this is not a small industry. This is a huge industry. And there's so much opportunity--

### Moderator
Claim: But the wind power part of it--

### Moderator
Claim: --they're right, is a small part of it. It's miniscule--

### Conspiracy Advocate (CA)
Claim: Wind and solar make up about five percent of our global power generation, in the, well, definitely in the United States, less in the--

### Moderator
Claim: And do you see that becoming significantly more in the near to mid-term future?

### Conspiracy Advocate (CA)
Claim: It's certainly growing by leaps and bounds, but, and so, as an investor, I care about growth, and where the best opportunities for investment are. So certainly the growth is happening in the renewable sector, and much higher growth rates than traditional energy.

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: But I would say that, when we're talking about, how do you grow the clean economy, it's about growing opportunity, broadly-speaking. And there are new innovations we haven't even thought about, I mean, think about the electric vehicle market.

We didn’t think about building that market 10 years ago, so there are step changes that we haven’t seen that we need to be innovating for now.

### Moderator
Claim: Steven Hayward, electric vehicles?

### Scientific Advocate (SA)
Claim: Well, they’ve got an awful long way to go yet. Their performance metrics are not very good.

### Moderator
Claim: But that doesn’t mean they can’t improve.

### Scientific Advocate (SA)
Claim: No, but you’re going to need to make some huge breakthroughs in battery technology and other things to make them work. It’s sort of going step by step, and I’m something of an optimist on that. But, look, let’s suppose we wave a magic wand and we invent the perfect electric vehicle tomorrow that can be sold at a competitive price to a gasoline engine. We have what, 100 million cars in this country?

### Scientific Advocate (SA)
Claim: Two hundred million.

### Scientific Advocate (SA)
Claim: Two hundred-- those people not only keep them 10 to 15 years, people aren’t going to rush out and buy 200 million cars in the next two years if we do that, so that means we need oil for quite a while to come, right? I just want-- I have to say one other thing though to respond to Kassia directly about energy efficiency. And the cars are part of the story, but they’re a separate thing too. If this debate were scored by the very strict rules of the Oxford Union, Kassia would be ruled out of order for not speaking to the motion.

Energy efficiency is about the consumption of energy and how much of it we consume. Clean energy refers to the supply of energy. We’re talking about two different things here. Simple thought experiment, seems to me, clears this up. If you have a factory that gets all of its electricity by coal-fired power and you insulate it and do all the things we want to do to weatherize it and you lower your electricity consumption 25 percent, does that make that energy from the coal fire power plant clean energy all of a sudden? This is like saying we have a motion saying you should eat more vegetables because it’s good for your nutrition and then arguing, but actually, you should just eat less food overall.

### Moderator
Claim: Let’s bring in Bill Ritter.

### Conspiracy Advocate (CA)
Claim: Well, I think that’s-- I disagree that Kassia should be thrown out of this debate. I think that that would be a problem--

### Scientific Advocate (SA)
Claim: I said “ruled out of order.”

### Conspiracy Advocate (CA)
Claim: That would be an awful thing for my team. But why are we talking about clean? I mean--

### Scientific Advocate (SA)
Claim: Because it’s in the title of the resolution.

### Conspiracy Advocate (CA)
Claim: No, we say new energy-- the energy sources aren’t new. The energy sources have all been there, but the transfer has been to talking about clean because we care about emissions.

And that’s really what-- I mean, why do we do this at all? Because we care about what we emit. And if you don’t buy into human change or human-caused climate change, there are still serious environmental hazards that happen from burning hydrocarbons, right, so we care about clean. And think about an industry that’s focused on people using less energy, and actually, by using less energy, bringing down the cost of energy, that would be the cleanest form of energy because you’re not emitting at all. So, we’ve done a variety of things as a state that looks at how we go into homes where people have fixed incomes, low incomes, but they don’t have very efficient homes and we try and do what we can to modernize those homes and bring down their energy costs.

### Moderator
Claim: But, Bill, in your opening, I had more the sense that your argument was that this innovative industry would require-- will create jobs with the establishment of the plants and the factories that build the turbines and that sort of thing.

And you’re broadening it now to-- am I right? That was your point.

### Conspiracy Advocate (CA)
Claim: Well, no, I mentioned energy efficiency somewhere in my opening and probably didn’t give it enough play perhaps because I do think that it is this powerful part of our thinking about clean energy, that we can build an industry around it. And, quite frankly, a lot of that industry has to do with the construction industry. If you look at this goal that we would reduce our emissions by 80 percent by 2050, there are people-- scientists-- who believe that we could get there, 40 percent of the way there, just by retrofitting the built environment, and that’s about energy efficiency.

### Scientific Advocate (SA)
Claim: But still, I think we haven’t answered Steve’s fundamental point, which is the motion is “Clean energy can drive America’s economic recovery.” I’m all for efficiency. Who isn’t? Every engineer in the world is for efficiency. We are getting dramatically more efficient. Today, in America, we use about the same amount of oil as we did in 1973 even though we drive twice as many miles and have twice as many cars, but clean energy, the motion is about the production of energy.

That’s the key point.

### Moderator
Claim: But I think your opponents are arguing that clean and efficient may be the same thing.

### Scientific Advocate (SA)
Claim: But I think that that is not what the motion says. That is not what the motion speaks to.

### Conspiracy Advocate (CA)
Claim: The motion is about clean, and it’s how you define “clean.”

### Scientific Advocate (SA)
Claim: Okay, then tell us what clean is, because I’m still confused.

### Conspiracy Advocate (CA)
Claim: I think the governor had a very strong point that clean is about-- it could be defined as reducing emissions. And so, by improving the efficiency of a coal fire power plant and natural gas turbines, that, in our definition, is clean.

### Scientific Advocate (SA)
Claim: John, if I may.

### Moderator
Claim: Steven Hayward.

### Scientific Advocate (SA)
Claim: By that definition, all fossil fuels are clean. A few facts then about this. We have tripled the amount of coal burned in this country since 1970 and reduced sulfur dioxide emissions in that same period by 70 percent. And the EPA expects that we will fall a further 50 percent from current levels just based on existing control technologies that are going to be retrofitted on plants.

Right now, changes in technology for burning oil mean that emissions from our car and truck fleet-- of conventional air pollutants are falling by about eight percent a year on net. The EPA’s own projections, which they never seem to talk about much, project that emissions of conventional air pollutants from the car and truck fleet will fall about another 70 percent over the next 20 years. And I’ve been saying for a long time, “But our grandchildren are going to say, ‘Smog? What was that all about?’” And actually, having grown up in L.A., believe me, that’s an impressive thing to say.

### Conspiracy Advocate (CA)
Claim: I really can’t imagine that you’re saying that we should not-- that we should sustain this level of emissions from coal burning plants that we currently have.

### Scientific Advocate (SA)
Claim: No, what I’m saying is that your definition of clean is incoherent.

### Conspiracy Advocate (CA)
Claim: No, no, it’s not because you can look at the different kinds of things that we are undertaking to lessen emissions. And if you’d rather, the operating principle here is that we should look at emissions. You pick out sulfur dioxide. We’ve done a good job with sulfur dioxide, but if you put in place-- let’s take natural gas-- natural gas, you decreased sulfur dioxide and nitrous oxygen by 70 to 80 percent.

You wipe out the mercury. So you’re not mentioning mercury. We have lakes in this country we don’t eat fish out of because of the mercury that is part of coal pollutant.

### Scientific Advocate (SA)
Claim: Mercury emissions, by the way, have fallen 60 percent in the last 15 years, by the way.

### Moderator
Claim: Robert Bryce.

### Conspiracy Advocate (CA)
Claim: You can eliminate the mercury through natural gas services as well.

### Moderator
Claim: Robert Bryce.

### Scientific Advocate (SA)
Claim: Thank you, John. Can you say that one more time? We are using more natural gas. Why are we using more natural gas? The coal industry is under obviously a lot of regulatory pressure for mercury. I think it’s appropriate. But they’re also under regulatory pressure for coal ash. That’s certainly appropriate. But last year, in 2010, according to the EIA, the U.S. used more natural gas than it ever has, 24.1 trillion cubic feet, and yet still the price of gas has fallen. That is incredibly good news. Your position is that natural gas is clean. I agree. Your other position is that somehow that fossil fuels are not a benefit to the economy, which I think is completely untenable. Let me move on to one other point.

That is clean energy, the fundamental question here-- clean energy adds nothing to the economy. It is only a substitution for existing electricity. Do I care-- these lights. I like electricity. But if this wind-- if this electricity is coming from a wind turbine or a solar panel and it costs twice as much as the electricity I might get from a coal-fired or natural gas-fired power plant, where is the benefit to me? I’ll gladly pay for a nicer tie or nicer--

### Moderator
Claim: Let’s let Kassia Yanosek answer that question. If clean energy is more expensive than conventional energy, then how does that help the economy?

### Conspiracy Advocate (CA)
Claim: Well, actually, I think you’re wrong on that point. I mean, if you look at the numbers, and I know you’ve got the numbers because you said clearly you have all the numbers.

### Scientific Advocate (SA)
Claim: They are important.

### Conspiracy Advocate (CA)
Claim: You know, the IEA, for example, has done a study of the amount of subsidies that go for the fossil fuel generation globally. I believe that number last year was 312 billion. For renewables, it was about 37 billion.

So we’re not really comparing apples to apples here. So I’ll just start with that. But secondly, I want to clear up this point about what--

### Moderator
Claim: Wait, I’m not satisfied with your answer to his point. It wasn’t detailed enough for me. The notion that-- and I think most of us have that sense that energy provided through alternative-- what we would call renewable alternative means costs more now and will for the long future. And that that doesn’t sound like a way to lift off. Let Bill Ritter-- I think your--

### Conspiracy Advocate (CA)
Claim: in Colorado, coal, without any price on carbon, is six cents a kilowatt hour. Wind is about nine. Coal can get to 6.5. Wind is at nine. And when I became governor, solar was 40 percent more than it is now. In a four-year period, solar came down 40 percent. Still not competitive with wind if you just say apples to apples, but this is the kind of argument that you hear from you guys. And I’m thinking here about the flat screen TV. It was $15,000 a TV four years ago, and now it’s $350.

So we give up on flat screen TVs because they cost way too much. This is something that’s happened and as, I think, Kassia said, this is happening around the world, that people are looking for clean energy alternatives. You’ve got wind without a price on carbon very close to coal. You’ve got solar coming down 40 percent, and it is our-- incumbent upon us to be innovators and--

### Moderator
Claim: Okay. So your argument is through innovation the prices are going to get lower. And I want to take that back to Robert Bryce.

### Scientific Advocate (SA)
Claim: Well, let me just address the subsidy question. The effective subsidy for wind now is two cents per kilowatt hour. But let’s compare apples to apples and take it to per million BTU cost. That is an effective subside of $6.44 per million BTU of energy created by the wind industry. The market price, the market price for natural gas today is under $4.

### Moderator
Claim: You’re talking about now, but your opponents are talking about future in which the price will get lower through innovation. That’s the point of the flat screen TVs.

### Scientific Advocate (SA)
Claim: Okay, fair enough. I want a flat screen TV. We have flat screen TVs in our house. I don’t want a wind turbine next to my house. The demand for--

### Moderator
Claim: But, again, Robert, that’s not the point.

### Scientific Advocate (SA)
Claim: Okay, why not

### Moderator
Claim: The point is the price of the energy.

### Scientific Advocate (SA)
Claim: Oh, come on, but it was a good one, yeah,

### Moderator
Claim: Not the noise of the wind turbine engine.

### Conspiracy Advocate (CA)
Claim: talking about the history of energy innovation and technology development, and if you look back through the history of how these costs came down the cost curve because it was not always that easy and that cheap to drill for oil and natural gas. Governments had to be involved; these industries had to be helped along with industry.

### Scientific Advocate (SA)
Claim: Well, but how long do we need to help them? In the Carter administration we heard that solar energy was going to be the dominant form of energy by the year 2000. What happened? The problem here is not about subsidies, it’s not-- it’s not even about want to or belief in global warming, it’s basic physics and math. I sound a little wonky here, it’s all about power density. How much power can you harness from a given area, or volume, or mass, and that’s where solar and wind just fall down.

We’re talking about one watt per square meter for a wind turbine, for an-- even a marginal natural gas, well, we’re talking about 20 or more watts per square meter. This is basic physics. It’s not about want to or government policy. The reason these energy sources have not been able to get off of subsidies is that they’re fighting uphill in terms of physics.

### Moderator
Claim: I think he’s saying the price can’t go down because of the physics of it, because of the space, because of the intensity. No, no, I think that-- seriously, I think that’s your argument and I-- because what does it take to-- these enormous solar farms take enormous amounts of investment in land and you’re saying that it’s going to be a long, long time before it ever pays for itself, so I want to take that back to Bill Ritter because you have experience in this area.

### Conspiracy Advocate (CA)
Claim: Well, again-- so, here, we develop wind farms, we develop them from start to finish in the State of Colorado. We've got a fellow that’s got 112 turbines on his land, he’s making about $5,000 per turbine, so it’s a half a million dollars that he’s earning in income and he’s got 68 acres out of production, 68 acres, he’s still able to farm, this is-- he’s a wheat farmer, still able to farm all of that.

And time, after time, after time not only have we seen the ability to put up a wind farm but we’ve seen the economic development possibilities for rural Colorado in an industry that, quite frankly, sort of lives at the margin. Think about the Mohave Desert right now where they’re building out solar and they’re doing concentrated solar power with natural gas, and this is why I don’t accept that we have this either/or. It’s this false choice. The folks at Bright Source have 2.6 gigawatts of purchase power agreements with Southern California, and so they’re going to build out these solar towers, and they’re going to put natural gas turbines on there, and if you look at the emissions, back to thinking about it in terms of emissions, if the sun shines like it’s supposed to in the desert, and the rest of it’s natural gas, they get 24-hour power, but they reduce emissions 75 percent in that 2.6 gigawatts of power going into Southern California.

### Moderator
Claim: Steven Hayward.

### Scientific Advocate (SA)
Claim: Well, this raises an interesting point about how there is no form of energy that doesn’t have some kind of environmental tradeoff except maybe for that bicycle generator the professor made for Gilligan. So environmentalists are-- have a whole bevy of lawsuits against those solar power projects right now in California because they’re built on the habitat of the desert tortoise and other endangered species, and there are separate lawsuits to block the very long transmission lines you have to build to bring them into Southern California. At last count there are 70 wind projects around the country that are facing environmental lawsuits to stop them for various impacts. You know, we get upset when birds die from a spill in the Gulf of Mexico, okay, fine. Windmills kill about 10,000 birds a year, and they also kill a lot of bats. And, you know, bats, as you know, have sonar. Do you know how wind-- and they don’t run into the blades like birds do. Do you know how they kill the bats? Air pressure changes by the blades explodes their lungs, so there’s no form of energy itself, the point is, is that not only have we heard that fossil fuels are clean, but so-called clean energy sources have their own environmental defects, and I’m still waiting for a coherent definition for clean for you that doesn’t conveniently feed into whatever it is you guys like.

### Moderator
Claim: Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: Well, first of all, I’m a fan of frogs, but not of bats, so I’m not actually going to take that argument on.

### Scientific Advocate (SA)
Claim: What about birds? How do you feel about birds?

### Conspiracy Advocate (CA)
Claim: But, again, I'm a frog person, so I'm just going to

### Scientific Advocate (SA)
Claim: I'm a bird person.

### Conspiracy Advocate (CA)
Claim: But I want to go back to this, you know, definition of clean energy and the cost issue because there's something that we have not really been able to focus on tonight and that is the actual reason we're here, to talk about growing the economy and if clean energy can actually get us out of this economic challenging environment that we're in. So first of all we talked about our view of what defines clean energy, it's about more efficient, cleaner energy in terms of less emissions, it's about not just talking about wind and solar here, but innovations that go beyond wind and solar. It's about cleaner fossil fuels. It's about innovations we haven't seen yet.

It's about energy storage and all the ancillary investments and innovations that need to go on to building and creating a new energy economy. And then, going back to the cost issue, I think we've made some very big points tonight, about how the costs are coming down the curve. And we need to be spending our time, and money, and efforts right now building an innovation economy. Because not only do we need to do that domestically, but we need to, we need an investment strategy for how we're going to be building our export economy.

### Moderator
Claim: Kassia, where are the jobs in what you're talking about?

### Conspiracy Advocate (CA)
Claim: The jobs are all over the place. They're everywhere, from investment houses, research firms, there are engineering jobs. So, I used to work at Bechtel and BP, you know what Bechtel and BP's biggest problem is? It's about getting young people into that business, into their businesses. Because people don't want to be drilling engineers. They want to be solar entrepreneurs and energy engineers. So--

### Scientific Advocate (SA)
Claim: Well, we need to change their minds.

### Moderator
Claim: Steven Hayward, of jobs and clean energy.

### Scientific Advocate (SA)
Claim: Well, I wrote down something Kassia said earlier about “oil won't help us with our economic predicament.” Well, tell that to the people of North Dakota, which currently has a 3.5 percent unemployment rate because they're having an oil boom. And, by the way, it's the state where they budget surplus, which Governor Ritter might find it a nice thing to have. I am tempted, by the way, to ask Governor Ritter, maybe I will, how many jobs might you get in Colorado if we opened up the oil shale, 800 billion barrels worth that the Department of Energy says could be produced at about $50 a barrel. That might produce some jobs for something we actually need, which is more oil supply.

### Moderator
Claim: Right, right. But the question, and I take your point that the oil industry provides jobs, but their point is that the clean energy industry will provide jobs. And what did you just

### Scientific Advocate (SA)
Claim: You know, I testified on the green exports idea to a congressional committee a few months ago, and I looked up the latest figures. We currently have a $20 billion trade deficit in green energy components, wind, and solar, and things of that kind, because, and that's why the company in Massachusetts moved to China.

Like our computer manufacturers, Robert mentioned, they can make it cheaper than we do. They also have the raw materials that we don't have, by the way. We only have one lithium mine in this country, by the way, we can talk about lithium batteries later, if we want. And so, you know, I agree to some extent that we will do a lot of innovating here, but the manufacturing is going to be done overseas, folks, for all the traditional reasons, sorry about that.

### Conspiracy Advocate (CA)
Claim: Well that's not true about wind--

### Moderator
Claim: Bill Ritter.

### Conspiracy Advocate (CA)
Claim: --that's not true at all about wind, we've got Vestas wind turbines, that's 2,600 jobs. You can't make small of 2,600 jobs in a state like Colorado, it's five million people. And a variety of other parts of the wind manufacturing sector. And, quite frankly, you have it in Pennsylvania, you have it, I think, in Ohio, you have it in Iowa. Where there is wind manufacturing, you cannot do those jobs in Canada, or China, and that's part of the reason Vestas located there. But even as it relates to solar. I wonder if there's a debate in China tonight, where they're saying, “you know, SunTech moved to Arizona, and they're making things in Arizona, and so, this is a bad thing for us to do in China, to invest in an innovation economy.” They're not doing that.

And there are solar companies that are coming here, manufacturing here, from China. There's exports we have to China. And the solar industry itself is a net exporter outside of the United States. It exports more than it brings in.

### Scientific Advocate (SA)
Claim: Well, fair enough, I mean--

### Moderator
Claim: Robert Bryce.

### Scientific Advocate (SA)
Claim: I'm much more bullish on solar than I am on wind, and if you look at the data from John Byrne at the University of Delaware, he talks about the learning rate in the solar industry and solar PV, and has talked a lot about the price on solar PV coming down. I'm very encouraged by that. I have PV panels on the roof of my house; I wish I was able to buy them now instead of eight, nine years ago, as I did. But what is happening globally? And then, when we talk about what's happening in the U.S. In Europe, Holland, Spain, Germany, all across the EU, we're seeing huge cuts in these renewable solar, renewable energy subsidies. In your own home state, Governor, Xcel is cutting their solar subsidies by half. Why? Because they're too expensive.

Now, let me address the issue of cost here.

Because as I pointed out, the EIA numbers show that renewable energy from solar and wind is significantly more expensive than is conventional electricity. Forty-three million Americans are today on food stamps. They've set records, now. Twenty-six consecutive months, the food stamp roles in this country have increased. The food stamp roles today are 40 percent higher than they were just three or four years ago. Do you think that these people are living on the edge of hunger, care whether their electricity is green or not?

### Moderator
Claim: All right.

### Scientific Advocate (SA)
Claim: I don't think they do.

### Moderator
Claim: I want to go to the audience for some questions now. And I want to remind you again, to make, keep it terse, and to try to think of, keep our motion in mind, that we want to stay on this topic, and, this very rich topic is very easy to go off in many different directions. We really want to bring it on, back to the issue of the effect on the economy of the clean energy industry and developing it. And, if you raise your hand, there are people in the audience who will come to you with microphones, and hold it about this far away from your mouth, about a fist's distance away, so that it can be picked up on the radio and television broadcasts.

And before we do that, I just need to do one more little bit for television and radio. This is a debate from Intelligence Squared U.S. Our motion is “Clean energy can drive America’s economic recovery.” I’m John Donvan, your moderator. We have four debaters, two teams of two, debating this motion. “Clean energy can drive America’s recovery.” All right, let’s go to some questions now. There’s a gentleman in a blue shirt and a blue blazer, right at the edge of the aisle.

### Moderator
Claim: All right, Mr. Hayward, we’re in New York City, NY University. As you walk around the city, look up at the chimneys and you’ll see the black smoke coming out. Well, here at NYU, the Institute of Policy Integrity teaches us that one percent of the buildings in New York City burning bunker fuel produces as much pollution as all of the cars and trucks in the city. Two hundred and fifty-nine people die every year because of respiratory diseases.

Over $1 billion a year in health costs--

### Moderator
Claim: What is your question, sir?

### Moderator
Claim: --economic benefits are almost a billion dollars. It seems to me that replacing the bunker fuel with natural gas, okay, would be vastly cleaner, would give us lots of jobs, would return almost $2 billion to our economy on a yearly basis. That would help our economic recovery.

### Moderator
Claim: Steven Hayward.

### Scientific Advocate (SA)
Claim: Now the odd thing to me is that it’s still allowed to be burned in New York City or any urban area. The odd thing about New York’s air quality-- I did a whole book on air pollution a few years ago, conventional air pollution-- is air pollution levels are actually higher in the suburbs in downtown Manhattan for some really odd and quirky reasons. Look, I won’t quote with your figures. The EPA’s got a thing out last week about conventional energy. I’m not sure that it nets out to saying that this is going to be an engine that’s going to drive our economy the way housing has done in previous sectors, the way high technology has done. And that’s the promise of the resolution tonight. You see, this is going to lead us to a boom, right. And I’m just saying that it seems to me it looks like any other sector that will produce only modest results.

### Moderator
Claim: Sir, what do you think of that answer? If you could rise again, so the camera can find you. Do you feel your question was addressed?

### Moderator
Claim: No, I didn’t.

### Moderator
Claim: Why? But be specific. Why not? I think he just disagreed with you.

### Moderator
Claim: It may be. This is a question of perceptions. To me, it sounded like you just avoided it. If we put--

### Scientific Advocate (SA)
Claim: No, I said I don’t know why it’s allowed to have bunker fuel being burned here at all. It astounds me. It would have been shut down in L.A. 30 years ago.

### Moderator
Claim: Well, I think there are a lot of people who would say we don’t understand why it’s allowed to burn oil just about anywhere, why it’s allowed to burn coal anywhere. We have much cleaner alternatives. Converting to those alternatives in many cases will be cheaper, and this New York example is very specific, which is vastly cheaper.

### Moderator
Claim: Robert Bryce.

### Moderator
Claim: Natural gas is much cheaper than bunker fuel.

### Scientific Advocate (SA)
Claim: Fair enough, but did you arrive here by car tonight?

### Moderator
Claim: No question, I live in New York City. I took the subway. don’t have cars in New York City.

I came here in a car, and it burned that dirty, nasty oil, and so I’m kind of biased toward it, I guess.

Come live in a city where it’s clean.

### Moderator
Claim: Let’s go to this side.

### Scientific Advocate (SA)
Claim: That one hurt by the way, it really did.

### Moderator
Claim: Yeah, you walked into that.

### Scientific Advocate (SA)
Claim: I did.

### Moderator
Claim: I’m really glad I went back to you on that. There’s a gentleman in a leather jacket right by the end of the aisle. And if there are folks in the back where the lights aren’t on, I want to let you know, I can’t see you but there are some seats down towards the front. If you want to make your way down, I could then see you and call on you. Sir?

### Moderator
Claim: On the subject of cost, can both panels give us an outlook-- their outlook-- for the price of oil, let’s say going out five, seven, 10 years, because that seems to be key to the proposition. If the price of oil spikes and stays there, then there is really no choice but to innovate. If the panel thinks it stays flat or goes down, then we have options.

### Moderator
Claim: Let’s let Kassia, yes, you can take that.

### Conspiracy Advocate (CA)
Claim: Okay, so, I’ll answer in two parts. Number one, the spike issue-- I think that we’re vulnerable to price spikes in any environment over the next five to seven years. Currently we’re experiencing a price spike. We could see that again in two years. We could see that in five years. We could see that in another month. I think that one other point I would make, and this is based on my experience at BP, which is that, we’re not going to see oil at $10 or $20 a barrel anymore. And part of that is because the above- ground and below-ground risks have changed for the oil industry. So, number one, we have to drill further and in more difficult places to get the oil out of the ground. Clearly, we’ve seen that in the Gulf of Mexico incident. And then, secondly, the above-ground risks. So most of the oil in the future is going to be developed in non-OECD countries, and we’re already seeing that happen. So what does that mean?

It means that the natural oil companies have more control over their resources and that it is certainly raising the cost of getting a barrel of oil out of the ground for the IOCs, for the independent oil companies.

### Moderator
Claim: And is the point of your question then that as the price of oil goes higher, it makes alternatives more viable economically?

### Moderator
Claim: If it goes high enough, there’s really no choice.

### Moderator
Claim: Okay, let me put that to the other side. Steven Hayward.

### Scientific Advocate (SA)
Claim: Yeah, it’s-- this is an interesting question, and I’m almost reluctant to take it on because it’s going to help out the other side slightly perhaps if they have the wit to pick up on it. We actually already got off oil once. In the late 1970s, oil was the number two source of electricity generation in this country, and now it’s less than one percent. And how do we do it? Well, coal and nuclear power. And the interesting thing is that in the first oil shocks in the ‘70s, about half of our energy-- total energy consumption was from oil. Today it’s now about 35 percent. We’ve gradually electrified more. And so, some of the things we’ve briefly mentioned tonight like electric cars, better battery storage and so forth, that would give us some option over time to accelerate a transition away from oil.

I’ll just say about the first part of the question, predicting oil prices out five years has made fools out of more people than I’m able to keep count of, and so I don’t do it anymore. And there aren’t any simple solutions to that.

### Moderator
Claim: Well, that almost does help the other side, your answer. I can see why you didn’t want to take it on. I’d like to get a female voice, but everybody raising hands that I see-- ah, thank you. Let the mic come on down, just for the balance.

### Moderator
Claim: I have a question about other kinds of consumer products because there’s a lot of focus on the automobile industry and, like, you guys mentioned computer products, but what about growth in other kinds of consumer products, like that seems like that could be a possibility to grow the economy?

### Moderator
Claim: In relation to-- but how do you relate that to the energy issue? I’m not sure what you’re saying.

### Moderator
Claim: Oh, I’m saying that there’s a lot of products that have been advertising themselves as like green products.

### Moderator
Claim: Okay, thank you. Steven Hayward.

### Scientific Advocate (SA)
Claim: To sort of address that, I’d recommend reading John Tierney’s column in The New York Times today that talks about one of the problems in energy efficiency is that we end up consuming more energy down the road. So, one of my favorite examples is jet aircraft engines, 70 percent more energy efficient than they were 30 years ago. Do we use more jet fuel or less jet fuel today than 30 years ago? Well, more because we fly more because it brought the price down. So everybody’s got these things, right. These things have the electricity footprint of a refrigerator, not the device itself. That’s absurd obviously, but when you think about the network of cell towers and the electricity that goes into all the servers that we plug into and we download data and make calls, that gives each one of these smart phones that we all have the electricity footprint of a refrigerator. So we get a lot more energy efficient appliances through mandates and standards and also the marketplace driving it that way, but we find more things to spend energy on, which is why even though we get more efficient year by year-- actually better than European countries in the last 10 years-- our energy consumption continues to go up. We keep buying gadgets like that.

### Moderator
Claim: I want to take the question to the other side, Bill Ritter, because I think the question was, in a sense, talking about refrigerators and other green energy-rated devices and that that’s the sort of innovation that I think your side is talking about, that there’s growth there and that there are jobs there.

### Conspiracy Advocate (CA)
Claim: If Dan Reicher were here and not stuck behind an avalanche in Utah, he would now tell a joke about a fridge to the future because he talks about refrigerators as this way to think about energy efficiency and, you know, the energy use of those refrigerators has come down, there’s greater volume, and 75 percent less energy use since the early 1970s because of a commitment to innovation. You’re right. You know, as it relates to the PDA, they’re very-- they go to data centers. Those data centers consume a lot of energy. That makes our point, right. We can’t keep the demand for energy growing. You said at one point in time that it’s less, but then you just said it’s more. And I think, you know, you look at IBM. IBM understands they use data centers very heavily, and you know what IBM’s made a commitment to?

Green energy. And they’ve made a commitment to clean energy because they understand that there are costs maybe apart from just the economic costs of continuing to have this industry that uses so much energy rely on fossil fuels or rely heavily on coal. So IBM in Colorado has the greenest data center I think, maybe, in America, and they did it specifically because of their energy demand growing and not wanting to be viewed as a polluter.

### Moderator
Claim: Did he get you?

### Scientific Advocate (SA)
Claim: Well, okay, being in favor of efficiency is like saying you’re in favor of air or breathing. I mean, at a certain point, it makes no-- it doesn’t set you apart at all. The economy is becoming more efficient because, as Steve’s example with the iPhone. You mentioned flat screen televisions. As flat screen televisions become cheaper, people buy more of them. I don’t know how many-- I have seven computers in my house now. I used to just have one.

Now part of it-- I have teenagers, but the reality is that as we become more efficient, we use more because we have more excess money to then buy more, to do more. So this is not a new area of study. The Jevons Paradox, William Stanley Jevons, 1865, wrote a book called, “The Coal Question”, laid this out very clearly, and so the idea-- and he said it very clearly. He said that, in fact, as you become more efficient you use more fuel. It is paradoxical. Now, in the U.S. and the developed countries we may be plateau-ing in terms of our energy use, but look at the three billion other people who live in the five most populous countries in the world, China, India, Brazil, Pakistan, and Indonesia, they use on a per capita basis one-tenth as much energy as we do. So, the fact is, as we become more efficient, we are. All around the world people are becoming more efficient, but they’re using more energy because it’s our nature to do so.

### Moderator
Claim: All right, let’s go back to the audience. Sir, you're-- got-- I’m looking right at you. If you just stand up-- Yeah, yeah, yeah, yeah, he just went like that. Got an unusual hat on. I didn’t want to say the hat part but worked.

### Moderator
Claim: It's actually the Teenage Mutant Ninja Turtles, Michelangelo. Just thought I’d educate you in that.

### Moderator
Claim: That’s good. That's good.

### Moderator
Claim: All right.

### Moderator
Claim: Don’t make me regret this.

### Scientific Advocate (SA)
Claim: I think you already do.

### Moderator
Claim: Well, I guess that alleviates my first question. My second question would be-- this is to all of you-- where should America see the rest of the world in this? Like, should we see them as enemies, should we see them as friends, business partners, should we see their governments as business partners? I mean, where does the rest of the world play into America’s economic recovery in terms of clean energy?

### Moderator
Claim: Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: I think we see them as all of the above. I certainly would say that when I think about where I want to be putting my dollars to work I think about, “Where are my export markets? Where are my customers?” I mentioned a statistic earlier tonight that 90 percent of the real energy growth that’s going to be happening over the next two decades is in non-OECD countries-- developing countries.

So we have to be partnering, we have to be developing our customer base; we have to be developing the appropriate trade policies. You know, one of the points that was made earlier tonight was that Apple was viewed as a great company, and Apple has innovated here in the United States, the value is created, the IP is here, some of the manufacturing's abroad. We’re going to have to have some, not all, certainly for the large cap-ex projects where it makes sense to have local industry develop those products like wind, that needs to be domestic, but for certainly for a lot of other products we will need to partner with place-- with countries like China.

### Moderator
Claim: Robert Bryce.

### Scientific Advocate (SA)
Claim: Just quickly in terms of one of the issues-- in terms-- your question is a complicated one. I think we’re partners, we're competitors, it depends. But one of the best pieces of news that I’ve read in the last three months was in West Bengal in India, ONGC, the Indian energy giant announced the first shale gas production from a shale gas well in West Bengal.

We’re seeing now shale gas production potential in Poland, in Australia, in China. The potential for natural gas is to set a new paradigm globally, for a low carbon, clean burning, energy source that is cheap, ultra abundant, and reliable to produce electricity to use for transportation is incredibly good news. Where did it come from? It came from the United States.

### Moderator
Claim: So are you agreeing with the other side on this point?

### Scientific Advocate (SA)
Claim: With regard to innovation in-- yes, look-- well, innovation is-- Innovation is innovation, and it is going to spread no matter whether it’s in the oil field or in flat screens TVs or whatever.

### Scientific Advocate (SA)
Claim: We’re agreeing with them if we agree with their very elastic definition of clean. You’ll notice this in the old fossil fuel industry. I think the question is an interesting one, I think there’s two parts to it. One is the traditional question about competition for resources which is, you know, a big knotty question. The second one is closer to our resolutions about tonight which is competition for a technological edge in energy.

So we hear that China’s going to spend 850 billion the next 10 years on renewable-- or, yeah, renewable energy, yeah, wind, and solar, and so forth. Let’s just round up and call it an even trillion, you know, a lot more than we’re going to spend on it. Partly, by the way, I think they’re creating an export industry to us saps, but that’s my opinion, but the other part of it is they’re going to spend five to $10 trillion on old fashioned coal and natural gas. India, the ratio will look similar because they need so much more energy and I think as Robert says, I have a hunch that our export numbers in traditional coal, oil, and natural gas drilling is going to be a lot larger than our exports even in the best IP we have in the-- you know, batteries and other purely clean technology.

### Moderator
Claim: Your opponent arguing for clean energy, Bill Ritter would like to come in on this.

### Conspiracy Advocate (CA)
Claim: I’m going to respond to this a little bit differently. I lived in Zambia for three years as a Catholic missionary and I’m telling you we could do all sorts of things in innovating products that we could export to very, very poor countries where their ability to use energy differently could help them expand their economies in a ways that we don't now think of.

In the university that I'm now at, Colorado State University, we developed a two-cycle engine at that university that really can reduce emissions in a tremendous way. If you think about India and the use the two cycle engine, so. We have, actually, this other thing that's, apart from just the economic driver, we have this other thing that happens with innovation, that can be very positive for some of the poorest places in the world.

### Moderator
Claim: Okay. Ma'am in the blue, light, powder-blue sweater.

### Moderator
Claim: This evening, no one's really addressed the fact that we have a very aging electric generation infrastructure. And that 50 percent of our generation today, approximately, is produced by coal. And most, many of those plants are very old and aging. And even the younger plants, that are maybe 20 years old, have been grossly under-invested in.

So what I don't hear tonight is, it's not simply about, you know, making money, it's about the risk of producing electricity. It's not simply that the electricity grows, is not going to be there, it's that what's going to happen and who's going to produce the investment that needs to be made in our generation infrastructure--

### Moderator
Claim: All right, but that-- but, ma'am, that could go to either channel, so can you relate it to our, I mean convention--

### Moderator
Claim: I'd like to relate it to these folks, who have not really addressed this issue--

### Moderator
Claim: So what's--

### Moderator
Claim: It's a huge investment opportunity, for, it's an investment opportunity that our economy, quite frankly, cannot afford to miss. And I'd like your comments--

### Moderator
Claim: You mean investment in clean energy.

### Moderator
Claim: I'm saying the investment in our electric generation infrastructure for the next 15 years.

### Moderator
Claim: Okay, I'm going to pass on the question, because I really need you to relate it to the motion, which is clean energy.

### Moderator
Claim: Well, the issue is that clean energy, and investment in things like fuel cell technology, okay, are critical to figuring out how the investment, for example, in our coal plants, needs to be made.

### Moderator
Claim: Okay.

### Moderator
Claim: And there's a whole area--

### Moderator
Claim: No, you did it, you hit it. So, Robert Bryce.

### Scientific Advocate (SA)
Claim: If you look at any of the projections, Deutsche Bank did a report on this in December, the Energy Information Administration, the vast majority of new electric generation capacity in the United States will be, over the next 20 years, natural gas-fired. And I'm fully in favor of fuel cells, they are still far too expensive to be commercially viable throughout most of the U.S., unless you're in California, where you get those big subsidies. What are they going to run on? Natural gas.

### Scientific Advocate (SA)
Claim: There's also the question about the grid there, which is a long subject--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Scientific Advocate (SA)
Claim: --that I think we shouldn't actually try. But if you really insist, we could do that.

### Moderator
Claim: No, I'm not insisting. Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: I'm going to make a quick point on this, because I think it's a very important one. And you're right, we did not really address it tonight. I work with utilities quite a bit, and those that are very exposed with their coal fleets----they are very concerned, and very interested in figuring out energy, again, the future of energy innovation, and how they can strategize the future portfolio for the next five, 10, 20 years. And yes, natural gas is definitely going to be part of that solution. But guess what, we've had experiences where we've had a big build-up in natural gas power generation, I experienced it in California when I was working for Bechtel, we were building and investing in natural gas power plants, one a week, almost. And guess what, the net price of natural gas spiked 10, $13 a kilowatt hour. So, guess what. We need to be thinking a bit broadly about how we're going to be developing our future generation plate, because you're absolutely right. We've got a big challenge ahead of us, and we need to be thinking very broadly about a big portfolio--

### Moderator
Claim: Right. I don't think your side disagrees with what she just said.

### Scientific Advocate (SA)
Claim: No, I--

### Scientific Advocate (SA)
Claim: No.

### Scientific Advocate (SA)
Claim: We're moving more toward natural gas, not just in the U.S., but globally. Why? Because we're de-carbonizing the global economy. The de-carbonization trend has been underway for 200 years. It's going to continue for the next 200.

It will include solar panels, it will include fuel cells, it will include a lot of things. But we're moving toward cleaner fuels. Why? Because it's what we want as consumers. Okay.

### Conspiracy Advocate (CA)
Claim: So that sounds like that could drive the economic recovery in America, to do that, right?

### Scientific Advocate (SA)
Claim: It will, because natural gas is cheap.

### Conspiracy Advocate (CA)
Claim: Natural gas is only one part of it, though. We're getting, I mean, and I agree, it is a part of it. We actually are promoting the use of natural gas. But to focus it solely on that fossil fuel is still--

### Scientific Advocate (SA)
Claim: Let me just ask one question, then, Governor. So you're pro-natural gas, I am too. So a lot of our natural gas is produced alongside oil. So you're bringing oil and gas out of the same well bore. So the natural gas is clean, but the oil is dirty.

### Conspiracy Advocate (CA)
Claim: No, I wasn't saying that at all. But I do think, I didn't say that oil was dirty. What I said is, we have a supply of natural gas, it is cleaner burning, we have the technology and government sponsored the natural gas turbine to get to a place where it became more efficient, and increased its efficiency by 30 percent.

Interesting that it was a government subsidy that actually made that happen, but the fact of the matter is that natural gas or oil should not be the only part of our portfolio. If we really look at this from an emissions perspective, you get a 50 percent reduction in emissions at best from natural gas when you transfer it from coal. But with a portfolio that includes all these other things, we can get to this 80 percent reduction by 2050. We can’t get to there from a natural gas--

### Scientific Advocate (SA)
Claim: It won’t happen, no way. Not a chance.

### Scientific Advocate (SA)
Claim: I can’t believe that nobody ever seems to do the math on this, except by the way for some researchers at the University of Colorado in the governor’s home state. That 80 percent reduction takes us back to, as I mentioned earlier, about a billion tons of CO2. The last time we emitted a billion tons of CO2 from fossil fuel sources in this country was over 100 years ago when we only had 92 million people living in the country.

One factoid for you: if the share of just our households, so our houses and apartments and condos that we all live in, if the share of CO2 emissions from the household sector is proportionally the same in 2050 as it is today, the emissions of CO2 will have to be no more than 206 million tons. Today, carbon dioxide emissions from current household natural gas use: 236 million tons. We cannot use more natural gas and make that target, Governor. The math does not add up.

### Scientific Advocate (SA)
Claim: Quick point, John. To hit that 80 percent reduction by 2050 would take U.S. CO2 emissions to current level of emissions in North Korea, Syria, or Cuba. It is not going to happen. It is a pipe dream, and I think it’s irresponsible for the government to even be repeating those numbers, and the president has said them and I think it’s just--

### Moderator
Claim: All right, once the word “irresponsible” come out, I have to give you a comeback on that.

### Conspiracy Advocate (CA)
Claim: No, I don’t think it’s irresponsible at all. This is totally achievable. This is totally achievable through a variety of strategies that include investment in clean energy, that includes renewables, that includes nuclear, that we can look, and we’ve said clean coal-- people are like, what’s clean coal?

Well there is also--

### Scientific Advocate (SA)
Claim: Can you give me an emissions inventory?

### Conspiracy Advocate (CA)
Claim: What’s that?

### Scientific Advocate (SA)
Claim: Can you give me an emissions inventory for 2050, of specific sources that will add up to more than a billion tons?

### Conspiracy Advocate (CA)
Claim: Well, no, I’m not able to sitting right here, but what I’m telling you is that it’s absolutely achievable and the reason it’s achievable. So, I don’t know--

### Scientific Advocate (SA)
Claim: If it’s absolutely achievable, you ought to be able to tell us how.

### Moderator
Claim: I think we’ve reached a point-- we’re at the religious stage of the--

### Conspiracy Advocate (CA)
Claim: Can I finish one thing? Steven Chu’s a-- he’s a Nobel laureate, right. He’s the secretary of Energy, and what he’ll tell you is that 40 percent of those emissions reductions you get from retrofitting the built environment, so it’s not about growing the portfolio. It’s about finding ways to do energy efficiency.

### Scientific Advocate (SA)
Claim: That’s statistically misstated, by the way. It’s from our building sector, you get 40 percent. That’s not 40 percent of total emissions. It’s only about 10 percent total emissions.

### Moderator
Claim: All right. I’m going to cut this off, and there’s a bearded gentlemen-- we were making eye contact before. would really love it if you didn’t read your question because you know what it is.

### Moderator
Claim: Rather than just the meaning of clean energy, I’d like to ask the question about the meaning of economic recovery. Given that until just now, nobody had the sort of the wherewithal to bring up climate change because there’s some who will contest the indisputable scientific evidence behind global climate change, I’d like to just ask that if there’s the potential for climate change to derail not only our society but our entire economy in the longer term, in the middle term, in the long term, can we choose to act in any other way but to embrace the precautionary principle and address this problem immediately rather than finding out what happens with clean energy and--

### Moderator
Claim: Robert Bryce, you write directly to this issue in your new book, so why don’t you take that question.

### Scientific Advocate (SA)
Claim: Well, I’m agnostic on the question of climate change. I’ve read both sides on the CO2 that some say it’s catastrophic, others say that it’s not a problem. To me, it’s, okay, if you believe CO2 is bad, then what? What is the solution?

And I say it clearly has to be natural gas and nuclear, and nuclear in particular because of the power density numbers because you get such incredible amounts of energy from a very small amount of real estate and relatively small amounts of steel and concrete. And those resource inputs are going to be incredibly important going forward. So, you know, were I the king, if I were the energy czar, I’d say let’s go nuclear in a big way because of the obvious benefits. And I think that the people who are, in my view-- if you are anti- carbon dioxide and anti-nuclear, you’re pro-blackout.

### Moderator
Claim: Let me bring in Kassia. Let me bring in Kassia Yanosek, and then I’ll come back to you. Kassia, can you make this one brief, though?-- ish, brief-ish.

### Conspiracy Advocate (CA)
Claim: Well, the one thing, and I was just going to make one point here which is I actually agree with our opponents here. I do think nuclear and natural gas are part of the solution.

What we haven’t spoken about tonight is actually the importance of having efficient, appropriate long-term transparent government policies to get us there. So if we are going to have an economic recovery that’s going to be fueled by clean energy, we’ve got to have the appropriate government policies in place to get us there in the most efficient and the cheapest manner.

### Moderator
Claim: Okay, Steven Hayward.

### Scientific Advocate (SA)
Claim: Yeah, the question I was trying to address in my opening remarks-- that it’s one thing to be told that it’s necessary to do this; it’s another thing to be told, as the motion does tonight, that it will make us richer to do so. Here is the blunt problem though. The International Energy Agency a couple years ago put out an assessment and they caught hell for it because what it said was the United States and European countries could disappear off the face of the earth tomorrow, which means their emissions would go to zero, and the growth in emissions of fossil fuel use of the developing world will make up for all of our emissions in about 15 years, which means if you can’t solve the problem globally, it doesn’t matter what we do.

That’s why I like to say the problem is so much bigger, whatever your view on the climate question is, you can accept the catastrophic view and, in fact, that makes it so much bigger than all the piddly things we’ve been talking about with Waxman-Markey or even incremental improvements and efficiency in this country. That’s a sobering answer for you.

### Moderator
Claim: Question down in the front row.

### Moderator
Claim: I think Kassia just hit the core of this resolution and the difference between the two sides perhaps. A government policy, which to me is code for subsidies, which were only obliquely discussed earlier, so if we return to that subject and if indeed clean energy by any definition is technologically achievable, economically achievable, what kind of government policy is necessary, slash subsidy, and why can it not be left to the market?

### Moderator
Claim: Bill Ritter.

### Conspiracy Advocate (CA)
Claim: So there are three things that the government policy can include: a public strategy that helps invest in the innovation-- that can be a part of it. And government policy can certainly be helping think about ways that there are financial instruments.

And there are instruments apart from subsides that also lead to investment. There’re a variety of things municipal governments can do, state governments can do that are financial mechanisms. And so, if you have the technology and you have the finance in place, then you look at sort of the other policies that might spur the kind of innovation, and that was our experience in Colorado, that our renewable energy standard absolutely made a significant difference in jobs coming to the state because there was a market certainty.

### Moderator
Claim: Steven Hayward.

### Scientific Advocate (SA)
Claim: I don’t know where to begin. I mean, Governor, if a 20 percent renewable standard are good, why not 50 percent?

### Conspiracy Advocate (CA)
Claim: Well, we went to 30, and we went to 30 with a two percent rate cap.

### Scientific Advocate (SA)
Claim: Well, why not 50?

### Conspiracy Advocate (CA)
Claim: Well, because we couldn’t get the coalition of people that I believe were necessary for us to do it to make a wise policy--

### Scientific Advocate (SA)
Claim: And cause was not a consideration at all?

### Conspiracy Advocate (CA)
Claim: We got to 30 with a two percent rate cap, that’s a pretty good thing to be, the second most aggressive renewable energy standard and to do that with people at the table agreeing that it was possible and achievable.

### Scientific Advocate (SA)
Claim: But your utilities are agreeing why?

Because there was a pass-through cost to their rate payers. That’s the interesting thing about all the subsidies that are being discussed now is that-- I take the questioners point is directly on point here. I’m all for renewable, but why can’t they exist on their own. Why do they need my tax dollars? Why do they need everyone else’s tax dollars?

### Scientific Advocate (SA)
Claim: Well, with the rate cap-- I mean, our history of price controls is real successful.

### Moderator
Claim: Yeah, I mean, I went to bat for the natural gas industry when they were going to remove the tax credit for intangible drilling costs. You’ve written about that. So there’s subsides. There are big subsidies out there, but the fact of the matter is we did this with a two percent rate cap and, in fact-- somebody referenced a story that said we’ve had this kind of inflation in our energy costs, a Denver Post story that went and looked at this, said the biggest increase in cost came from the opening of a new coal plant, not from renewable resources being at 30 percent renewable by 2020.

### Scientific Advocate (SA)
Claim: Okay, well, fair enough. Would you agree then to--

### Conspiracy Advocate (CA)
Claim: Well, that wasn’t mentioned in your-- that’s fair enough, but you didn’t mention it.

### Scientific Advocate (SA)
Claim: Okay, so would you agree then, fair field, eliminate all subsidies? Fair field, no favor?

The oil and gas tax preferences amount to $4.4 billion per year. Ethanol alone gets $16 billion.

### Conspiracy Advocate (CA)
Claim: I’m not a fan of ethanol.

### Scientific Advocate (SA)
Claim: Okay, fair enough, but would you support fair field, no favor--

### Conspiracy Advocate (CA)
Claim: Actually, I’ve got a point here I’d like to make.

### Moderator
Claim: Kassia Yanosek.

### Conspiracy Advocate (CA)
Claim: And this is a very important question. I think that what we haven’t seen enough of in this country is enough policies that actually pool technologies into the marketplace. We’ve seen a lot push. Well you need some of the push because you actually need to be developing the end market so that you have the development of the turbines and the solar panels who actually sell into a big market, but I absolutely think that the pool of technologies is the most important thing that we need to be focusing on. That could be through a carbon price, a tax or just some sort of price on carbon.

I think the clean energy standard, and certainly a federal one is certainly a good way to go rather than the patchwork of state policies that make investors, I think, very concerned because we don’t-- we’d like to see a big federal approach so that we have an easier time in putting our money to work.

### Moderator
Claim: Steven Hayward, final word for you.

### Scientific Advocate (SA)
Claim: Yeah, this is the price on carbon question, that comes up a lot. I actually did a paper with a Tufts economist a few years ago on what a $15 a ton price on carbon would get you. We thought about a 10 percent reduction in CO2 emissions, not a lot, but something. But here’s the problem with the idea of the price on carbon. You know, Europe has had a big price on carbon for a long time. They’ve had high fuel taxes for decades as a-- strictly as a revenue measure. It later became an environmental measure. You know, so their equivalent price of gas is as high as $8 a gallon in some countries and their utility rates are much higher than ours and yet even with those high prices you don’t see any breakthrough in green clean energy technologies in Europe. Their numbers are about the same as ours. If the price on carbon incentivised the market you’d see a lot more going on in Europe than we do.

## Round 3

### Moderator
Claim: And that concludes round two of our debate. And here’s where we are. We’re about to hear brief closing statements from each debater. They will be two minutes each, and this is their last chance to change your minds. Remember you voted before the debate and we’re going to ask you to vote once again right after their closing statements. And the team that has changed the most of your minds will be declared our winner. So round three closing statements, each debater in turn. Our motion is "Clean energy can drive America’s economic recovery." Here to summarize his position against the motion, Steven Hayward, F. K. Weyerhaeuser Fellow at the American Enterprise Institute and author of the "Almanac for Environmental Trends."

### Scientific Advocate (SA)
Claim: Thank you, John. Remember that the motion tonight is directed not at whether we think clean energy however defined is a good thing, or a necessary thing, but whether clean energy can be the sector that will lead this country out of what we’re still calling the great recession. Now I wish we could talk more about this.

If you mandate or subsidize something of course you’ll create jobs and if the government spends lots of money on something, you will create jobs. That’s why we do defense spending because it’s necessary and if you have a defense plant in your area of course you create lots of jobs. But of course if we thought just the government spending money on things was the answer to prosperity we would never cut the defense budget after a war. The reason we build prisons, because it’s necessary. And there’s lots more demand for prisons unfortunately in this country, but no one thinks that, that is the path to prosperity, even though it creates jobs. The question does it create net new jobs across the economy, does it add value where value doesn’t currently exist.

The light bulbs up here really don’t discriminate what kind of electron it comes from. Electrons are all the same, these lights don’t care whether it’s from a coal fire powered plant or natural gas or a windmill except when the windmill is not turning. A problem we haven’t talked about a lot is the reliability of many forms of clean energy. I cannot think ever of a sector of the economy that led us out of a recession because the government mandated that we buy the product.

And I could spend a lot of time talking about some of the important things that have been pointed to like the Internet, jet turbine engines which were the result of government research, but not mandates that the public buy them. I think for all these reasons the sign behind us says think twice, I think you should think twice about letting sentimental slogans do our thinking for us rather than the hard headed reality of the energy world. Thank you.

### Moderator
Claim: Thank you, Steven Hayward. Kassia, do I pronounce your firm, "Tana"?

### Conspiracy Advocate (CA)
Claim: Tana.

### Moderator
Claim: Tana, okay, I just wanted to be correct, because you were a late entry I didn’t get pronunciations on all this. And thank you again for filling in, it was terrific that you did this. Our motion is clean energy can drive America’s economic recovery and here to summarize for the motion, Kassia Yanosek, founding principal of Tana Energy Capital and cofounder of the U.S. Partnership for Renewable Energy Finance.

### Conspiracy Advocate (CA)
Claim: Well I’d like to summarize tonight by saying first of all our opposing side has done us a great benefit tonight.

They’ve said that they’re bullish on solar, that natural gas is clean, that Apple is a great example of a company that has innovated here but manufactures their products abroad in China. And all of those points help us because essentially they’re saying that they agree with us, that the clean energy economy will help to grow our economy and get us into a state of recovery. I’d also like to bring it back to why I’m here tonight. I’m not an environmentalist; I don’t like bats and birds. I like making money and I wouldn’t be here talking about the importance of clean energy if I didn’t think that there was an opportunity for investors and consumers to improve our state by either making money or reducing our costs of consuming energy. We’ve talked about subsidies; we've talked about how subsidies in the United States help dirty and clean energy.

We've been in agreement that we're seeing costs come down the cost curve for many clean energy technologies, whether it be batteries for electric vehicles, or solar energy. And we've also agreed here that, you know, oil price spikes aren't great. And therefore, we need to be expanding our energy options into a variety of different fuels, clean and dirty, and make them cleaner.

So, I would just finalize here, my points, by saying, I think that we need to be focusing on what's actually going to be getting us into this next stage of growing our economy. And we're already doing that. We're already seeing energy technology move to a place where, we saw IT and Biotech 10, 20, 30 years ago. And it's about focusing on the technology, focusing on the smart policies that actually promote energy innovation, and promote pooling technologies and having them compete with one another.

And finally, it's about policies that actually bring finance into the, into this industry. And leverage--

Tana.

### Moderator
Claim: Thank you, Kassia your time's up.

### Conspiracy Advocate (CA)
Claim: Thank you.

### Moderator
Claim: Thank you. Our motion is “Clean energy can drive America's economic recovery.” Here to summarize his position against the motion, Robert Bryce, author of “Power Hungry: The Myths of Green Energy and the Real Fuels of the Future.”

### Scientific Advocate (SA)
Claim: Recall the motion. “Clean energy can drive America's economic recovery.” The key word there is “drive,” that this is going to be the catalyst for the economic recovery. Energy transitions, like it or not, happen over decades, or even centuries, not years. And that economic recovery, the implied timeline here is maybe a half-decade? Steve and I have repeatedly shown that this “clean energy” term is so vague as to be meaningless. That's one reason why you should vote against this motion.

In 1974, Richard Nixon promised that we would be energy independent in six years.

Today, we import a lot of foreign oil. We've been an importer of foreign oil since 1908, a net crude oil importer since 1908. Now, we hear President Obama saying 80 percent of our electricity will be clean energy by the year 2035. We didn't get energy independence, and we won't meet this goal of 80 percent of our electricity from clean energy by 2035 either. Because it is such a nebulous idea. If everything is clean energy, then nothing is. Look at the latest numbers from the EIA. Today we produce about 50 percent of our electricity from coal. Their latest projections are that, by 2035, coal will still be providing about 40 percent of our electricity. Why? Because of cost. The latest EIA projections also show that by 2035, coal, oil, and natural gas will be providing 78 percent of our primary energy. That's only slightly down from 83 percent today. Clean energy won't fuel America's economic recovery, because we don't know exactly what it means.

Unfortunately, Steve and I can't talk about power density, and cost, and scale, in ways that will drive these points home. It takes physics, it takes math. This issue that we're hearing, this beating of the drum for clean energy, unfortunately, is just a further cheapening of our political discussion in this country. Rather than having real discussions about energy and energy policy, we're stuck with yet another slogan, and that will not help our economic recovery at all.

### Moderator
Claim: Thank you, Robert Bryce.

### Scientific Advocate (SA)
Claim: Thank you.

### Moderator
Claim: The motion: “Clean energy can drive America's economic recovery.” And here to summarize his position for the motion, Bill Ritter, director of the Center for the New Energy Economy at Colorado State University, and former governor of Colorado.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you very much for your time and your attention tonight. This is a debate that's far more important than any kind of political slogan, or any kind of politicking. This is a debate that I think has everything to do with the economic future of this state, this country, and quite frankly, the future for our kids and our grandkids.

And people who think that Americans don't care what kind of power source delivers electricity through a light bulb are wrong about that. Everything that I've seen, in terms of public opinion polling, says that Americans absolutely do care that we make investments in clean energy.

Why do they care about it? They care about it because they believe that, in this place, America, that we are inventors, that we are creators. You can look at costs and say, “Costs of this, and that's why coal will be, going forward, 40 percent of our energy.” That's a static view of the world. It doesn't take into account the tremendous cost curve reductions that we've seen in a variety of places that are absolutely non-carbon sources of energy, solar, wind, and things of that nature. And, quite frankly, Americans believe in the star of innovation and creation, and say, “Yeah, we can do it.” We can do it with the right set of policies. And we're not here defending every subsidy and saying it has to happen this way, in a subsidized way.

What we're saying is, if you put the right set of policies in place to support taxing-- sorry-- financing, technology, and those things that help bring technologies forward and move them forward, then you get to a place where you can see a vision for a clean energy economy that can be part of this economic recovery. States across the country have seen job growth because they committed investments and innovation. They committed policy to this, and they’ve seen job growth in this sector and no other sector. And that’s just one laboratory. If we did it at the federal level and we did it as a nation, we would see economic recovery in this sector even in the place where we’re slow to recover in a variety of other sectors because it’s a global market and a global demand. Thank you.

### Moderator
Claim: Bill Ritter, thank you. And that concludes our closing statements. And now it’s time to learn which side has argued best. We’re asking you again to go to the keypads at your seat that will register your vote.

Our motion is “Clean energy can drive America’s economic recovery.” If you agree with the motion, having heard the arguments, press number one. If you disagree, press number two. If you are or became undecided, push number three. And we will have the results in just a minute. And also, in San Francisco and in Washington, D.C., our observers there are also registering their vote, and we’re going to report both results tonight. So, before we get to the results which will only take about a minute, a few things I want to take care of. First of all, I would really like to-- I’ve already thanked you personally, Kassia, but I’d like to thank all four of our panelists for coming here, really bringing their game today. Thank you. Thank you, all of you. And tonight was one of those nights when the questions from the audience members were actually terrific and on point no matter what kind of hat you’re wearing. I want to thank all of the people who got up and asked questions because it’s not that easy to do. And a special thank you goes out to the American Clean Skies Foundation for helping to underwrite this season of debates. And again, thank you Greg Staples. And what this season is about is a theme that we call “America’s House Divided,” and our next debate will be Tuesday, April 5. The motion then, “It’s time to clip America’s global wings.” Arguing for the motion, we have Peter Galbraith, the U.N.’s deputy special representative for Afghanistan in 2009, the first U.S. ambassador to Croatia as well where he was actively involved in the Bosnia and Croatia peace process. Joining him as his teammate is Lawrence Korb and assistant secretary of Defense under Ronald Reagan, Korb was once in charge of administering 70 percent of the defense budget. He is currently a senior fellow at the Center for American Progress.

Arguing against the motion are Elliott Abrams, a fellow at the Council on Foreign Relations who held positions in the Reagan administration and the George W. Bush administration where he was deputy national security adviser in charge of Middle Eastern affairs. His partner will be Elliot Cohen. We have a double Elliot coming up, and that’s very rare. He’s a professor at-- I was once on a shoot for ABC News in Romania, and I was joined by three ABC colleagues. All came from different countries. We all converged there, and all three of them were named Bruno. Now that is rare. Eliot Cohen is professor of the School of Advanced International Studies at Johns Hopkins who, despite taking the Bush administration to task over its handling of the Iraq war, served as counselor at the Department of State. Tickets are available for those debates, for that debate and others following through our Web site and at the Skirball box office. And you can also follow Intelligence Squared U.S. on Twitter. And make sure to become a fan on Facebook to receive a discount on upcoming debates. And actually, this entire debate was streamed live on Facebook tonight.

This is the first time that we’ve done that. Also, all of our debates, as we’ve said before, can be heard on NPR stations across the country, and you can watch the debates on the Bloomberg Television Network starting next Monday at 9pm. Visit Bloomberg.com to find your local channel.

So I’m just waiting for the results to come. They’re probably taking a little bit longer because of the D.C. and San Francisco votes. And since I mentioned Charles Ferguson earlier, Oscar winner, I don’t know if you’re actually here because I never saw you. Are you here, Charles? Can you just shout yes?

### Moderator
Claim: I am.

### Moderator
Claim: You are. I just want to again-- Congratulations to you. And an interesting little fact, my son who’s a 14-year-old eighth grader, got extra credit for going to see your movie and showing up at school with the ticket stub. So, as his father, I’m glad that I could contribute a little bit to your income on that, but congratulations to you. Now, Dana, do we have word from-- why don’t we announce the hall vote and then afterwards I can announce the D.C. and San Francisco vote.

### Moderator
Claim: That’s going to embarrass her a great deal.

### Moderator
Claim: All right, well, talk to your neighbor. Here it comes. Here comes the vote. All right, so, we didn’t actually hear back from San Francisco. I’m not sure what’s happening out there.

So here are the-- I just want to do the math here. It’s pretty close in D.C. Okay, so, in Washington, here are the results before the debate: 52 percent were for the motion, 14 percent were against, and 34 percent were undecided. After the debate, 46 percent are for the motion, 23 percent are against, and 31 percent undecided. As I see it, the “against” side won in Washington by moving the number nine percent versus the “for” side’s moving at eight percent. So, in Washington-- so congratulations to them. All right, here is the final result then from all of you in the hall who have voted twice now on the topic and motion and the arguments that you have heard.

Before the debate, 46 percent were for the motion, 21 percent against, and 33 percent undecided. After the debate, 43 percent are “for”-- that’s down three percent. 47 percent are “against”-- that’s up 26 percent, and 10 percent remain undecided. The team arguing against the motion, “Clean energy can drive America’s recovery,” has carried the debate. Our congratulations to them, and thank you from me, John Donvan, at
