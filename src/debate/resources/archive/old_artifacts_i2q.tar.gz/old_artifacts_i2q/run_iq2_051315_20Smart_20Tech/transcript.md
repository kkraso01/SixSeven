# Debate Transcript

Topic: Smart Technology Is Making Us Dumb
Motion: Smart Technology Is Making Us Dumb

Debate ID: 051315%20Smart%20Tech


## Round 1

### Moderator
Claim: Let's please give a round of applause to our chairman, Mr. Robert Rosenkranz.

Hi, Bob.

### Moderator
Claim: Hi, John.

### Moderator
Claim: Hey, Bob, how are you?

### Moderator
Claim: I'm good, thank you.

### Moderator
Claim: As I just told the audience-- and the old-timers know this-- this is where we chat a little bit about what's in store for us. But we were talking beforehand, and it's interesting what you told Smart Technology is Making Us Dumb me is in relation to technology and a little-- you know, a little dabbling you've done in your career in a thing called finance, that you had some experience on both sides of the gift of technology. So what's the first part of that?

### Moderator
Claim: Well, I have. So about a decade ago, I thought it would be interesting to hire some people and see if they could figure out how to beat the stock market. And I got a group of PhDs, computer scientists from MIT and Harvard and so forth. And basically, with a team of six people, we were able to look at every single trade in every one of 6,000 public companies, look at every bit of financial data that they-- that they produced and went public with, and were able, ultimately, to figure out a way to get-- pick stocks that were going to go up faster than the market or down relative to those stocks.

And by having long and short positions, we were making fairly consistent and good returns--

### Moderator
Claim: It worked out.

### Moderator
Claim: --for quite a long period of time, yes.

### Moderator
Claim: Well, we're actually all very happy for you on that point.

### Moderator
Claim: Well, thank you so much.

### Moderator
Claim: Sure.

### Moderator
Claim: But it didn't exactly work out all the time. And there was an occasion of a period of about three weeks when all the money that the system had made over about three or four years was lost.

### Moderator
Claim: Oh. Now we feel bad for you.

### Moderator
Claim: Well, thank you very much. I appreciate that. And the reason for that was, in a sense, smart technology making us dumb, or at least narrower in our-- in our thought processes.

Smart Technology is Making Us DumbBecause most people who run successful hedge funds, which this was, learn that-- to be very cautious about what's called a "crowded trade," a lot of people doing the same thing at the same time, and particularly to not use a lot of debt in a crowded trade, because if you have to get out and you're forced to sell by the firm that loaned you the money, you're really in trouble. Everybody is rushing for the exit at the same time. So here you had, I mean, our group of guys. But it turned out that there were 15 or 20 similar groups of computer scientists at different banking firms, all doing more or less the same thing, all looking at their algorithms, all looking at their data, and none of them looking at each other.

So they never realized that what they were doing was being in a very, very crowded trade. And when one person overdid it and was forced to sell, it set off a whole domino effect, and everybody, including us, lost a lot of money. So there it is.

### Moderator
Claim: Well, what we do with that?

### Moderator
Claim: What do we do with it? We know that there's something to be said on both sides of this motion, and we should have a debate.

### Moderator
Claim: All right. Thank you very much, Bob Rosenkranz.

And let's welcome-- let's welcome our debaters to the stage. Let's welcome our debaters to the stage.

Okay, if there are folks who are standing who want to come sit down, why don't we take an eight-second break, and you can sprint, because otherwise you'll be waiting for the intermission, and there is none.

Smart Technology is Making Us Dumb All right. Once again, because this is a radio broadcast, I want to ask for a round of applause for Bob Rosenkranz and to get us launched. Thank you.

A personal pocket computer wizard so small you can take it with you anywhere. That sure sounds familiar. But in fact I am quoting from an ad published in a newspaper in Midland, Texas, in 1975. It was advertising the Sharp number 1802 calculator which boasted, in its advanced technology, it boasted the broad mathematical abilities of a slide rule. Well, we've come a long way since then to the point where probably a lot of us don't even know what a slide rule is. But are we smarter now because technology has come so far and put a lot more than a slide rule into our pockets?

Or are we so dependent on this wizard that is technology to do things for us that we are losing the ability to make our own magic, mentally, socially, politically? Well, that sounds like the makings of a debate, so let's have it. Yes or no to this statement: Smart technology is making us dumb, a debate from Intelligence Squared U.S. I'm John Donvan. We are at the Kaufman Music Center in New York City. We have four superbly qualified debaters, two against two, who will be arguing for and against the motion, "Smart Technology is Making Us Dumb.” As always, our debate goes in three rounds. And then our live audience here in New York votes to choose the winner, and only one side wins. Let's meet our debaters. The team arguing for the motion, please, ladies and gentlemen, let's welcome Nicholas Carr. And, Nick Carr, you are the author of "The Glass Cage: Automation and Us" as well as "The Shallows: What the Internet Is Doing to Our Brains.” That was a Pulitzer Prize finalist. In these books, Nick, you are warning readers about the danger of our growing reliance on computers. So I am wondering do you possess a smartphone?

### Conspiracy Advocate (CA)
Claim: Smart Technology is Making Us Dumb Well, I resisted for a long time, but about six months ago I finally broke down and bought my first smartphone.

### Moderator
Claim: And how is that relationship working out?

### Conspiracy Advocate (CA)
Claim: We're still feeling each other out.

### Moderator
Claim: Ladies and gentlemen, Nicholas Carr. And, Nick, who is your partner?

### Conspiracy Advocate (CA)
Claim: My partner is the acclaimed writer and thinker, Andrew Keen.

### Moderator
Claim: Ladies and gentlemen, Andrew Keen, please welcome him. Andrew, you are also arguing for the motion that smart technology is making us dumb. You are an entrepreneur. You're executive director of FutureCast Salon. You're host of the web series, "Keen On," and you've also written a lot of books including "The Internet Is Not the Answer.” However, your critics have chosen some lively language to describe you. They've described you as "a mastodon growling against the warm wind of change." And your Wikipedia entry once briefly read, "Andrew Keen is an expletive, expletive." So what do you do to deserve all this hostility?

### Conspiracy Advocate (CA)
Claim: I tell the truth.

Smart Technology is Making Us Dumb

### Moderator
Claim: I'm guessing we're going to hear some of that tonight.

### Conspiracy Advocate (CA)
Claim: Yes.

### Moderator
Claim: But we won't be hearing expletives from the other side. Ladies and gentlemen, team arguing for the motion, "Smart Technology is Making Us Dumb." And we have a team arguing against the motion. First, please welcome Genevieve Bell. Genevieve Bell, very, very interesting story. You're a vice president Intel Fellow and you work in Intel's Corporate Strategy Office where your job basically is to worry about the future. Before all of this, however, you were teaching in the anthropology department at Stanford, so our question is for all of the humanities and social science majors out there, how does a cultural anthropologist end up working at Intel?

### Scientific Advocate (SA)
Claim: Well, like all good Australians, I met a man in a bar.

### Moderator
Claim: Details to come later. Thank you. And, Genevieve, who is your partner?

### Scientific Advocate (SA)
Claim: My partner is the lovely, talented, and charming David Weinberger.

### Moderator
Claim: Ladies and gentlemen, David Weinberger.

Smart Technology is Making Us Dumb David Weinberger, you're also arguing against the motion that "Smart Technology is Making Us Dumb.” You're a senior researcher at Harvard's Berkman Center for Internet and Society. You're at the Shorenstein Center at Harvard-- at the Kennedy School. You've written a bunch of books also including, "Too Big to Know," and "The Cluetrain Manifesto.” You wrote that back in 1999, which was an early book looking at the Internet's effect on business. And you came up with 95 theses. So have they stood up to the test of time?

### Scientific Advocate (SA)
Claim: Yeah, pretty well. The most important point that we make-- because it was coauthored-- was that the web is actually a social place, although it didn't look like it at the time. What we got-- one of the things we got very wrong was that we didn't know we would have to fight to keep the web the way it was.

### Moderator
Claim: Ah, so you were only a partial visionary?

### Scientific Advocate (SA)
Claim: I am a very shaded if not shady--

### Moderator
Claim: I'm going to get you out of that. Ladies and gentlemen, please welcome David Weinberger. Thank you. And these are our teams arguing for and against this motion, "Smart Technology is Making Us Dumb.” Now, this is a debate, and that means there will be winners and losers. And the winners and losers will be determined by a vote of our live audience here in New York. Before the debate has ended, you will have been asked to vote twice, once before the debate and once again afterwards. And the team whose numbers have changed the most in percentage point terms will be declared our winner. So let's go to the preliminary vote, if you go to those keypads at your seat and take a look at just keys one, two, and three, the only ones that are live on that keypad, and if you agree with this motion, push number one. And if you disagree with this motion, push number two. And if you are undecided, push number three. And we will share the result of this vote at the end of the evening, when we also share the result of the second vote.

And in between you will have heard the arguments, and judged the quality of the debates, and staked your final position-- whether that's different from the first is up to our debaters. On to Smart Technology is Making Us Dumb Round 1. Round 1 are opening statements by each debater in turn. They are uninterrupted. They are seven minutes each. Our motion is "Smart Technology is Making Us Dumb.” And here to make his opening statement in support of the motion, please welcome to the lectern Nick Carr. He is author of "The Glass Cage: Automation and Us," and "The Shallows: What the Internet is Doing to Our Brains.” Ladies and gentlemen, Nick Carr.

### Conspiracy Advocate (CA)
Claim: Thank you. And thank you, John. We're gathered here tonight to talk about our intelligence, and about whether our smartphones, and our apps, and our social media accounts are expanding it or eroding it.

Are we more thoughtful now, thanks to our technologies, or less thoughtful? And I think you can approach that question from two different angles. And a little bit later, my colleague, Andrew Keen, is going to look at it from a social and cultural angle. How is the technology influencing our collective intelligence? What I'd like to do is talk about it from a very personal, individual level. How is the technology influencing the way our minds work? And now, by now I think all of us, if we're honest, know pretty well how we use our gadgets. We use them compulsively. And the research bears this out. The average person with a smartphone will pull out the phone and look at it about 150 times a day. And that breaks down to about six minutes for your every waking hour. The average teenager or 20-- early 20-something-year-old will send or receive about 4,000 text messages a month.

And that also breaks down to about one every six minutes. And when you start to add up all the messages, all the notifications, all the alerts, all the Pins, all the Instagrams, all the Google searches, and everything else, what you get is a clear picture that we have created, with this powerful digital technology, a new environment for ourselves. An environment of constant distraction-- almost perpetual interruption. Now, that suits the purposes, suits the interests of companies like Google and Facebook, because they make more money the more we gobble up little bits of information. But what does it actually do to our brains and how our brains operate? To answer that question, I think we have to look at how we transform information, which is just the raw material of thinking, into actual knowledge.

And that process hinges on the transfer of that information between two forms of memory. On the one hand, you have your working memory, which is essentially the contents of your consciousness at any given moment. What you're thinking about right now is your working memory. And we know-- what we know about working memory is it has an extremely small Smart Technology is Making Us Dumb capacity. You can only hold about two to four pieces of information in your mind, your conscious mind, simultaneously. And then on the other side, you have our long-term memory, what we usually refer to as "memory.” The store of all the facts you know, the experiences you've had, the people you recognize. And this-- if working memory is very small capacity, long-term memory has a huge capacity. You can never actually fill it up. You can never get to the point where you say, "I can't remember anything anymore.” The key to building knowledge, the key to deep intelligence is being able to move incoming information from your conscious mind over into your long-term memory.

This is a process called "memory consolidation," and it's through this consolidation that you create connections and associations between what you're experiencing now, what you're learning now, and what you already know. And it's those connections and associations between the information and the experiences in your mind that form the basis for true knowledge. That is the foundation for conceptual thinking, critical thinking, creative thinking. The problem, today, is that we're constantly overloading that small store of our working memory. And this creates a phenomenon-- an actual biological phenomenon called "cognitive overload.” If you think about it, if you can only hold two to four pieces of information in your conscious mind, then if you're constantly taking in new information, you have to push the existing information out very, very quickly in order to make room.

And what we know is that consolidation, this kind of weaving together of information into knowledge, requires attentiveness. It's only when you attend to something in your working memory that you actually transfer it to your working memory and make it part of your knowledge. What we've created, in other words, is an environment that is constantly frustrating our mind's ability to create deep knowledge and to think deeply. Now, we are right to celebrate all the great things we get from smart technologies, from the internet. It's great to celebrate the fact that we have access to all this information and all this conversation immediately. But what we too often forget is that information is not knowledge, it's not intelligence, and it's certainly not wisdom. And when we spend all of our time gathering information, what gets crowded out is the time to distance yourself from distractions and interruptions and think deeply about things, think deeply about the experiences you're having, think deeply about the new facts you're learning, think deeply about the conversation you're having.

This is the kind of thinking that the internet and smart devices in general, by peppering us with messages and little bits of information all day long, is stealing from us. We're losing that contemplative, deep, focused, attentive state of mind that is crucial to the creation of knowledge, the creation of intelligence, and deep thinking in general. So even though we can Smart Technology is Making Us Dumb celebrate all the great things the internet does, I think we have to be honest with ourselves. And I would suggest you look not only to the science and not only to what everybody on the stage is going to say, but to your own experience with the technology, how you use it, whether, when you want to think deeply, you pull out your smartphone, or you try to distance yourself from your smartphone and from your computers. And by thinking about your own experience, I think you'll get a clue to the broader theme of what this technology is doing to us.

And I think, if you're honest with yourself, you'll conclude that indeed our smart technologies are making us dumb, and you'll vote for that proposition. Thank you very much.

### Moderator
Claim: Thank you, Nicholas Carr. And that is the motion, "Smart technology is making us dumb.” And here to argue against the motion, David Weinberger, author of "Too Big to Know: Rethinking Knowledge Now That the Facts Aren't the Facts, Experts are Everywhere, the Smartest Person in the Room is the Room.” Ladies and gentlemen, David Weinberger.

### Scientific Advocate (SA)
Claim: Thank you. Thank you. Thank you, Nick and-- so if Nick is right, and our technology is having this physical effect on our physical brain, keeping us from being able to form knowledge out of information, then why is this-- it seems to me to that this is-- this is the greatest time in human history to be somebody who cares about knowledge.

This is-- this is a renaissance of knowledge. If we take the question, "Is our smart tech making us dumb," I want to not even refute that. I want to ask, why do we keep asking that? Because if "smart" means that we make good decisions, then we are-- new predictive technologies, very smart-- enable us to do that. If being smart means understanding more, we now have from the Higgs boson to the Hubble telescope, we have the ability through our smart technology to understand more about a universe that's 14 billion years old. And if "smart" means better at our work, then I absolutely, and you absolutely, want your doctor, your auto mechanic, and your airplane pilot to have the smartest technology that there is. So why do we have ask? I think in part it's because of the shock of the new. And this is very, very new, what's going on. Andy Clark is a philosopher who makes a point that we don't know, we don't think in our heads.

Smart Technology is Making Us DumbWe think with things in the world, out in the world. So a mathematician thinks with chalk on a blackboard. An architect thinks with models in her hands or using a straight edge or something. And a meteorologist who is using our old tech, who just has a weather vane is not going to be nearly as smart as a meteorologist who's gather data from sensors around the world, big data put to use to predict the weather down to the hour. That's really, really smart. And it's our smart technology that lets us do that. If Clark is right, and I think he is, that we think of objects out in the world, and if those tools change, and if they change radically, then the way that we think changes radically, which is why I think we even consider the possibility that our smart tech is making us dumb when all the evidence seems to be that in fact we are smarter in the important ways than ever. Another reason perhaps we entertain this notion is that we have a natural tendency to think that the technology we grew up with is natural and is good. But that's not the case.

We didn't invent gatekeepers because we said-- in the old world, in a prior world-- we didn't invent gatekeepers because we thought it was just a swell idea to vastly limit the amount of information and knowledge that we were going to make public, and we didn't say, "You know what would be really swell? Let's create a set of homogenous white guys, and they'll decide what makes it through those gates.” We invented gatekeepers because the old medium, that technology of paper, was so limited. It had gates, and the gates were really, really narrow. And so we needed to have gatekeepers. But now we don't. Now the gates are down. We have this huge abundance, and we adopt new strategies for that. And sometimes it's disconcerting. One of the main strategies is that we skim. We skim a lot. That's actually a really adaptive technology-- technique for dealing with it. And it's not even an old technique. It's a technique that we use when we go into an old-fashioned real bookstore and there are thousands of titles, and we skim them on the shelves really quickly to find what we're interested-- and that-- so we still do that now.

We're doing it online. And just as then, when we find something that's interesting to us, we are able to drill down into it. We start reading it. It's-- in this age of constant distraction, we can't focus, we're watching seven years of "Game of Thrones," the most complex narrative that we've ever seen in our world. And I'll see you Sunday night. It's great. We love this stuff. Our children are reading seven volumes of complex, intricate narrative and characterization. Our universities are turning out experts and scholars who are deep into their topics, deeper than ever because they can go that deep because of the internet. So I don't think the evidence is there, despite the brain chemistry, that we are in fact not knowing. We are knowing more and better than ever.

Smart Technology is Making Us DumbIf you think back to the 1980s, for example, you get a newspaper, you'd read the article, you'd find something, you'd read an article. It was really exciting, you wanted to know more. You want-- but you can't because it's 1980. And all you've got was that rectangle of print. That's what it was like before we had smart technology. You were just stuck. It's infuriating even to think about at this point. That's not right. It's certainly not natural. So let me give you an example: 1911, with the-- sorry, Britannica, Encyclopedia Britannica had its first article on Oliver Goldsmith, the playwright, 6,000 words long. Each new edition, that gets shorter because they've got to cram in more stuff. By 1994, it's down to 1,500 words which means that it's-- the editors of the Britannica, the gatekeepers of knowledge and culture, have thrown out 75 percent of what Britannica knows about Goldsmith, because that's how paper works. Wikipedia article, it's 1,400 words, but you've got to count all of the-- look into all of the links, decide which ones of those count in the total for Goldsmith.

You can do the apples to apples. It's-- and there will be much more. And people will disagree about what-- which of those links count, which is fine, because in Wikipedia and on the web overall, knowledge is no longer crammed into rectangles. They assume a much more natural shape, which is that of a web, which is-- has near infinite capacity. It enables us to accommodate much more complexity of relationships, indefinite complexity, is much bigger than any one brain could ever have made. And we get to see how the knowledge is made, which is in many ways very disconcerting. We see that it's human. It's a human product. It's full of fallibility, we see the people are arguing, they're adding, they're getting things wrong, they're getting things right. That's how knowledge is made. That's how knowledge was always made. But now we can see it. It's in our face. And that's a truth. That's a truth about knowledge that was always true of knowledge. But now that we can see it, we're beginning-- it's an amazing thing. We're beginning to invent and discover together new ways of building knowledge, of talking together and building knowledge.

This has-- we've never been in a period like this before. But it may-- it's upsetting because now we have to face the truth that knowledge has always, always been a human product and always, therefore, subject to and characterized by the fallibility of humans. So it seems clear to me that to argue that our smart tech is making us dumb is not only to be on the wrong side of history; in this case, it's to be on the wrong side of evolution. So I urge you to vote against the proposition and to do so emphatically.

Smart Technology is Making Us Dumb

It's on right now.

Smart Technology is Making Us Dumb

### Moderator
Claim: Thank you, David Weinberger.

And a reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate where our motion is, "Smart technology is making us dumb.” You have heard from the first two debaters and now on to the third. Debating for the motion that "Smart Technology is Making Us Dumb.” Let's welcome to the lectern Andrew Keen.

He is executive director of the Silicon Valley Salon FutureCast and author of the book, "The Internet is Not the Answer."

### Conspiracy Advocate (CA)
Claim: Well, I've often been accused of being on the wrong side of history, but I love the idea of being on the wrong side of evolution. If my mother was alive, she would particularly appreciate that. That's why I'm not married either. So David is clearly a passionate man, I have a great deal of respect and love for him. We've jousted many times before, but I've never heard him quite as effusive of our world. He talks about something he calls a "renaissance of knowledge.” A renaissance of knowledge, David, when was the last time you turned the Internet on?

### Scientific Advocate (SA)
Claim: It's on right now.

Smart Technology is Making Us Dumb

### Conspiracy Advocate (CA)
Claim: When was the list time you looked at Twitter? When was the last time you went on Facebook? When was the last time you observed the nature of our digital culture, the very culture that Nick so brilliantly tore apart in his opening remarks? You argue that-- and Nick brings up this word, "distance"-- we're talking, of course, in this new media, the media that you describe as a "renaissance of knowledge"-- what Nick is describing is the end of distance. Perhaps if we were academics, we would call it, "the death of distance," the end of distance. So we have these devices. I know this is radio, but on the radio you can imagine what I'm waving. We have the death of distance. We have a culture of intimacy, of personalization.

This is the culture of intimacy and personalization that has replaced what you described as "narrow gatekeepers.” We all become the media in this world. We all have our devices. We all have our publishing platforms. We can all tell the world what we're thinking, what we're doing, where we're going, what we're wearing, unfortunately sometimes what we're not wearing. We all have these technologies-- Wiki, YouTube, blogging technologies-- that allow us to express what Nick called the "death of distance," the end of distance. It explains our contemporary cult of authenticity, this idea that we always have to be true to ourselves.

It's, of course, a manifestation of a particularly corrupted nature of democracy, a world where everything is intimate, everything is personalized. Nick described it in scientific terms I guess as not only the end of distance, the end of depth, and the end of objectivity. Everything, then, in this media, in this world of smart technology is personalized. Everything is intimate. Everything is telling the world what we think. Everything is confirming what we already think. So this so- called smart technology-- I don't know where we get this term. The person who came up with the term, "smart technology," should be spanked, at least metaphorically, because I don't know where the word came from. There's nothing smart about personalized, intimate technology. It simply confirms our misplaced ideal that the world revolves around us. It's a pre-Copernican notion. And ironically it's technology confirming that.

Smart Technology is Making Us Dumb Technology by definition, as I'm sure some Frankfurt theorist like Walter Benjamin once argued, technology is by definition romantic and nostalgic and reactionary. So don't accuse Nick and I of being that. We are the progressives. We are the ones looking forward. It's technologists, or people with a belief in the idea of technology as salvation who are reactionaries, they-- they're the ones who want to drive us back, like Rousseau, to some idealized community. So what do we have? We have then a technology of intimacy, which is resulting, in cultural and social terms, in a more and more personalized culture, a platform where we tell the world what we're doing, what we're thinking. It represents the disappearance, the death not only of distance but of communication. We struggle more and more to talk to one another. Sherry Turkle wrote a brilliant book called, "Alone Together.”This technology is indeed making us alone together. It's a technology not only, as Nick said, of distraction, but of atomization, of alienation. This is Durkheim on steroids. This is a world of profound disorientation and destruction of the community. So what we have, then, in epistemological terms, is the disappearance of that kind of objectivity that Nick talks about. I think David described it-- he thinks this is a good thing, epistemological chaos. Everyone saying everything at the same time, and no one listening to anyone else. The ultimate-- the ultimate consequence, of course, of this is the selfie. This is a selfie culture. This is a culture where the ultimate expression is photographing ourselves in front of a masterpiece, in front of Auschwitz, in front of someone jumping off the Bay Bridge.

These are true examples of selfie culture. Meanwhile, what's going on? David celebrates the narrow gatekeepers that are being destroyed. But of course, since we have this so-called smart technology, what has happened to those gatekeepers? We're seeing not only the death of distance, but the death of newspapers, the death of recorded music, the death of the professional creative class, the people who made their living thinking, the people who have made their living writing books, the people who made their living writing articles for newspapers, the people who made their living taking photographs. That kind of Smart Technology is Making Us Dumb professionalism is in crisis. Some people even believe that the creative professional is a thing of the past. So, what we have is this double whammy. On the one hand, personalization, intimacy, driven more and more into ourselves, into an echo chamber culture, where we never listen to anything anyone else is saying, particularly if it dissonates with us.

And on the other hand, the death of a professional culture. That is why you should believe that smart culture-- whoops-- smart technology-- that was Freudian-- smart technology – is certainly making us dumb. Thank you.

### Moderator
Claim: Thank you. Andrew Keen. And that is the motion: Smart Technology is Making Us Dumb. And here's our final debater against the motion in this opening round. Please welcome Genevieve Bell. She's an anthropologist, Intel fellow, and Vice President at Intel Corporation. Ladies and gentlemen, Genevieve Bell.

### Scientific Advocate (SA)
Claim: Perhaps it's fitting that it falls to a woman and an Australian to rebut that particular moment. I find myself delightfully, at the end of this conversation, thinking about the proposition, is smart technology making us dumb? I think it's probably ironic that we started this debate using a smart device to vote on that proposition, and that most of you in the room said you had smart technology on your persons, even though you've now disabled it for radio. When I was given the task of taking on this proposition, as someone who did debate in high school-- which is a long time ago-- I was struck by the impulse to want to deconstruct the question. It's an anthropological approach too, right? And ask "What is smart technology?" Echoing Andrew's concern of what on earth that might mean. What does “dumb” mean? Is smart/dumb the only binary pair that we could have, and is dumb necessarily, as an anthropologist, I might want to ask, a bad thing? I mean, clearly we're putting a set of cultural and moral values around dumbness that are interesting. Smart technology is now being described as romantic, Smart Technology is Making Us Dumb progressive, reactionary, a rectangle, and a gatekeeper, all of which is an interesting set of a baggage to put on a phone, the Internet, algorithms, the internet of things, and big data.

Nonetheless, we have done that. So, David said to me, "No, Genevieve, don't deconstruct the argument.” So I'm taking his advice. I am, however, going to want to suggest that smart technology has made us smart in some unexpected ways. It's made us more responsive. It's made us more engaged. And in the case of both Andrew and I, it's made us more enraged and I'm not necessarily convinced that's a bad thing. So, how might I go about proving that? Well, I think there's a couple of places you'd look to. And many of them are outside of this room, and Manhattan, and outside of the United States. Smart technology makes us smart and it makes us safer. If you were to look, in the last year, I can pull you examples from all over the world. In many African countries and on the Indian subcontinent, mobile phones and text messages are used by governments to send out health warnings and preventative health messages. When the Ebola outbreak was taking place, messages were sent on smartphones to tell people how to handle themselves, their communities, and the bodies that they were encountering. Hardly dumb, right? In Australia, where I come from, all the volunteer fire services, which is how we keep ourselves safe in the fire season, use a geo-located app service that sends out notifications to Australians to tell them there's a bush fire near them, to tell them what to do in a high-fire danger day, which isn't always obvious.

And how to think about being safer and ultimately smarter about how we inhabit a dangerous landscape. In the United States, you have the Amber alert, something I'm sure many of you hope to never see on your telephones. But when you do, you know what to do. It's about making a community and the kids in it hopefully safer and ultimately making all of us smarter about danger. And it will be hard to argue with what’s happened in Nepal over the last three and a half weeks as people have mobilized all sorts of technology to bring both relief and comfort to a community that was clearly struggling. In all of those cases, is smart technology making us dumber? I hardly think so. And if you were to move further out from that frame and think about cultural knowledge, we talked a lot about intelligence, we talked a lot about book learning. But let's think a little bit about cultural knowledge.

I'm the child of an anthropologist. I grew up with indigenous people in Australia. I spent a lot of time in indigenous communities, and it's been fascinating to watch over the last 20 years as Smart Technology is Making Us Dumb those communities have embraced new technologies to do old things. The Ngadjuri with whom my family have worked for the last 20 years, used the internet to tell their stories. They like the fact that newspapers are being archived because they can use the stories in those about their colonial contact and argue about how to regain their land. The Diri and the Kukuda are using IOT sensors to combine traditional knowledge about climate with state- based knowledge about climate change to think about how to occupy their land better. And the Anangu in central Australia have an electronic medical records system that is a marvel of the world and has changed the health outcomes in that community. Is smart tech, in those instances, making those communities dumber? I hardly think so. And is it about a vacuum and people just talking to each other? I don't think that's the right way to think about it, either. Moving closer to home, at Intel, we're deeply concerned about diversity in the tech community, about diversity in STEM education. And one of our challenges frequently is to convince young women and ethnic minorities that there's room for them inside the sciences.

And one of the ways you do that is by telling the stories of people who've been there before. Finding the stories of women pioneers and under-represented minorities who were pioneers used to be difficult. It's nice to be in New York for me. I get to go visit Judy Chicago's dinner table at the Brooklyn Museum, and I think about how hard it was for her to reclaim all of those women's names and how much easier it is to do it today. My Twitter feed just recently brought me the name of Sharla Boheim who actually was the original lead name on pocket-- packet simulation technology. You don't need to know what it is, but it's the foundation of the internet. And she was involved. Until quite recently, people didn't know that. So is using smart technology to tell our stories and tell them widely and bring more people into the conversation making us dumb? I certainly hope not, because it's something I participate in regularly. And almost last but by no means least, let's tackle the notion of community and citizenship. Andrew brought it up. Let's take it on a little bit more seriously. What have we used smart technology for from the last 18 months to think about notions of citizenship beyond the United States and within it?

Were the students who were protesting at Mong Kok in Hong Kong say that smart technology was making them dumb? I don't think so. Would-- and I'm never going to get this man's name right, so I apologize in advance-- but would Feidin Santana think that he was doing something dumb when he took out his camera phone and recorded a policeman shooting someone in South Carolina? And we watched the video rocket around America and drive yet a further conversation about race and violence, and what it means to be a citizen? We can dismiss hashtag activism-- such a great phrase-- as being a sort of a fleeting thing, right? Whether it's #blacklivesmatter, #notallmen, #SOSblackAustralia from my hometown. But truthfully the use of technology to propel conversations about citizenship is hardly new. A photograph made a huge difference in how we talked about the Vietnam War. The radio and vinyl records, which Smart Technology is Making Us Dumb are making a comeback, I'll have you know, helped distribute the word of Martin Luther King. And the suffragettes really liked a good typewriter.

So is smart technology in those cases making us dumb? I don't think so. Does it mean we still have a lot of work to do as citizens? Absolutely. And lest I end on a depressing note, because I realize being told you have more work is depressing, let me just reflect briefly on something else. Smart technology is also in our everyday lives. And some of those things we may not think about as making us smart, but they're certainly changing, I would argue, for the better personhood. Here's my last example: Online dating, because you should end on a good note. When I was in India doing fieldwork many years ago, a place that had been embracing this technology for a long time, a woman said to me, "Getting a husband is just a database problem." And she said the matrimonial time-- matrimonial classified section of the Times of India changed everything for us because the database got bigger. So, let us imagine, from changing ideas of citizenship and safety, to ideas of romance to ideas of what it means to be in the world, it's really hard, I imagine, for any of us to sit in this room and to agree to the proposition that smart technology is making us dumb. So along with David, I think you should emphatically vote against it. Thank you.

## Round 2

### Moderator
Claim: Thank you, Genevieve Bell. And that is our motion: Smart technology is making us dumb. And that concludes round one of this Intelligence Squared U.S. debate. Now we move on to round two. And round two is where the debaters address one another directly and take questions from me and from you and our live audience here in New York. The motion is this: Smart technology is making us dumb. We have two debaters argue strenuously for the motion. They have made the argument that the new technology-- and we all know what we're talking about because it's in our pockets-- is creating a new environment of constant distraction and perpetual interruption which leads to a kind of cognitive overload, which ultimately diminishes attentiveness, and as a result, accumulation and use of knowledge suffers. They also make the case that smart technology creates a false ideal of intimacy which in itself is actually devoid of communication, and in that sense, harmful to the culture overall.

Smart Technology is Making Us Dumb The team arguing against the motion, Genevieve Bell and David Weinberger, argue that thanks to smart technology, we are living in a renaissance of knowledge, that being smart means being able to understand the world better, to be better at our work than ever before. They hail the fact that the gatekeepers of knowledge are on the run and possibly in some cases dead. And they talked about, in general, the expansion of cultural knowledge, particularly in communities who previously didn't have ways to connect or had a voice, and that the technology gives them those voices. So I hear-- we've had many, many layers of this argument already brought out, both in terms of putting this in a hardware/software term, but we've also looked at the impact of the technology both on the individual and then on the culture. So I think we need to take some of those in turn. And I want to start more with the argument that was made about the impacts on the individual and his ability to gather and use knowledge.

And it sounds to me-- I want to take this to David Weinberger. You have celebrated the vast expansion of the amount of information out there. But I-- it seems to me that your opponents are saying that information is not knowledge, and that there's an important distinction. I want to see if you take that point or would refute it:

### Scientific Advocate (SA)
Claim: Well, on the one hand, I am not happy with the metaphorical use-- and yes, I am goading you, I think, Nick-- the metaphorical use of information, knowledge, and wisdom. This is a pyramid that was constructed that was-- somebody came up with, Russell Ackoff, I think, in the 1990s. And it's become canon that I think that it is not-- it's a nice metaphor, but it's actually a wrong metaphor. The idea is, it's a pyramid, right? Many of you have seen this. Businesses put up, like every hour that diagram is drawn on some business law somewhere. Data information knowledge, wisdom. It's a pyramid because the idea is that knowledge is a matter-- we think knowledge is a matter of filtering out information.

So we start with broad-based data. That gets filtered out. What's worthy information is-- in data becomes information and so on up the path. And certainly wisdom does not work that way. Wisdom doesn't make sense in that if you think about it for a moment. And I also don't think knowledge works that way either. Knowledge is not a filtering of information. In fact, let me-- the information itself is very suspect.

### Moderator
Claim: --take it to your opponent that he actually refutes-- he refutes the assertion that knowledge and information are different, which is-- on which your argument hinges. But just having a bunch of stuff is not such a great advantage.

### Conspiracy Advocate (CA)
Claim: Smart Technology is Making Us Dumb I fundamentally disagree that the concepts of information, knowledge and wisdom are mere metaphors that were invented in the 1990s. That's insane. This is-- but this is fundamental to our understanding of what it means to be a thoughtful, you know, intelligent person, is the ability to gather lots of information, to be aware of things going on.

But then the crucial part is stepping back from the flow, taking that information and creating personal knowledge in your own mind. So there is a fundamental distinction between grabbing stuff online, between checking your Twitter feed or your Facebook notifications, and actually raising that up through connections, through contacts, through cultural knowledge.

### Moderator
Claim: You do not dispute your opponent's, Nick, that there is, at minimum, a whole lot more information available to individuals than there used to be.

### Conspiracy Advocate (CA)
Claim: Absolutely, there's a whole lot more information.

### Moderator
Claim: The question is whether it's meaningful.

### Conspiracy Advocate (CA)
Claim: The question is, how do we think?

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: Again, so it would be insane to say that we invented knowledge in the 1990s, somewhere The diagram in which we think that this is how the filtration process works I think is fundamentally misleading, that knowledge is not a filtering of information.

It's a social process-- sorry, the epistemological chaos that-- it is somewhat chaotic. It's a social process in which we engage with one another. We-- knowledge is based in large part upon social-- relationships and makes social relationships. The computer based model of the brain that you and most of our culture accepts I think is highly suspect. And if we look past going-- you know, scanning down your Facebook feed to see what's new and think about the times in which we actually do form knowledge, this new ecosystem, which I totally agree with you, we now have, is in fact spectacularly good for the formation of knowledge.

### Moderator
Claim: Smart Technology is Making Us Dumb Let's bring in Andrew Carr Do you want to respond to any of that?

### Conspiracy Advocate (CA)
Claim: Well, I don't even like this word, "information." I would prefer to use the word, "data."

### Moderator
Claim: I'm sorry. I mispronounced your name. It's Keen.

### Conspiracy Advocate (CA)
Claim: Keen, okay.

### Moderator
Claim: Yeah, because I've got the team of Keen and Carr.

### Conspiracy Advocate (CA)
Claim: That's a lot of data or information.

### Moderator
Claim: Yeah. It's-- the alliteration just throws me.

### Conspiracy Advocate (CA)
Claim: Yeah, I'm always known as Andrew Carr on Wikipedia. I think that what we have in our age of the smart machine, of smart technology is an avalanche of data. And I tend to think that we even have to distinguish data from information. And I certainly-- you know, I bow down to Nick in this area from a scientific and an epistemological point of view. But this overpowering nature of data is troubling in all sorts of ways. And perhaps most troubling of all-- Nick pointed to this-- was while we're all drowning in data, most of it extremely irrelevant at best-- inane, vulgar-- a tiny handful of Silicon Valley companies, most notably Google and Facebook, are making fortunes out of that data, not because it's correct, not because it has any value to civilization, not because it's solving problems in Africa, but because they're selling advertising around it.

Smart Technology is Making Us DumbSo there is a double vulgarity here, and I would much rather talk about a big data economy than an information economy.

### Moderator
Claim: Let me bring it to Genevieve Bell. And your opponent just said that-- that we are drowning in data, which would appear to try to set on its heels your argument that the plethora of stuff that we now have is in itself a good thing, because it's too much.

### Scientific Advocate (SA)
Claim: Well, I mean, I would make the argument that some of that data has been extraordinary in what it has revealed. I mean, you know, let's think about Snowden and Chelsea Manning. Let's think about the Sony leaks. I mean, you know, whether we can argue about the legality of those, but the data that they generated revealed things about the contours of the world writ large and the world writ small, and made clear all manner of things that we might want as citizens, as human beings, as women to argue about.

### Moderator
Claim: But what's the--

### Conspiracy Advocate (CA)
Claim: But the data they generated was data about the incredible surveillance apparatus that is built around smart technology deployed by the government.

### Scientific Advocate (SA)
Claim: Oh indeed. Oh indeed. We're not having a debate about the morality of surveillance. We are having a debate about whether smart technology makes us dumb. And I think, you know, the argument there is not about surveillance, but about, "Does the prevalence of data always mean we are drowning?"

### Moderator
Claim: Nick Carr, David Weinberger said that skimming is good, and he said we do it naturally. We go into libraries and we skim and we select very quickly, and so he-- a direct challenge to your argument that this-- that this distraction that you talked about that the Internet represents is so problematic.

Smart Technology is Making Us Dumb

### Conspiracy Advocate (CA)
Claim: We read in different ways, and they're all valuable. On way of reading is skimming. If you open a magazine or newspaper, you do a lot of skimming. But then, particularly when you have a book or a news-- printed newspaper or something in front of you, you also-- when something interests you, you move to a much deeper form of reading where you're not skimming.

You're actually reading. You're going line by line. And what research into how people read when they're looking at their phones or their computer shows is that skimming becomes the default, the dominant form of reading. And, in fact, you-- if you look at the research, the researchers talk about the F pattern by which they mean that people-- when they-- when people read on a computer screen, they go across the first couple of lines of text all the way, and then their eyes drift down the margin a little bit. And then they go about halfway across the text, and then their eyes just drift down the rest of the margin, so it forms this F pattern. And then you click, and you go somewhere else. So skimming is fine in context. Better and more important is actually reading deeply, whether it's fiction or nonfiction or anything. That's when you get deeply engaged. That's when you learn stuff, and that's the kind of reading that we're losing, thanks to our smart technologies.

### Moderator
Claim: And the evidence that we're losing it is what? Because your opponents were talking about an enormous amount of reading they were talking about, an ability actually to process, even if it's Game of Thrones, very complex plots, that, in fact, the mind isn't dying because the argument is--

### Conspiracy Advocate (CA)
Claim: I don't think we're arguing that the mind is dying. And, fortunately, we used to be-- you know, used to get involved in "War and Peace.” And now we get involved in "Game of Thrones.” And that's all fine. And that's all good. The question is, on balance, is this making us dumber or smarter? And I think there is, at this point, a lot of research. There's a great study that came out of Stanford, where the researchers got two groups of people. One group spends a lot of time online, a lot of time multi-tasking. One group didn't. They gave them six basic, fundamental tests of cognitive function. The heavy multi-taskers did worse on all six tests. And one of the most revealing tests was how well people are able to distinguish important information from trivia. And on that test, the heavy multi-taskers, heavy users of smart technology, did very poorly.

Smart Technology is Making Us Dumb And what the researchers theorized is that what happens is we train ourselves not to pay attention to what's important, but simply to pay attention to what's new. So, when your phone goes off, when it buzzes, whatever, it can be the most trivial thing in the world, but that's what grabs your--

### Moderator
Claim: Okay.

### Conspiracy Advocate (CA)
Claim: --attention.

### Moderator
Claim: But let me--

### Conspiracy Advocate (CA)
Claim: And we begin to lose that fundamental ability to even think about what we should be thinking about.

### Moderator
Claim: Okay. So, Genevieve Bell, you're approaching, as we know, as an anthropologist. And we want to come to that part of the discussion shortly. But the description that Nicholas gives, from the sort of lab-- the bench science on this, do you find it concerning? Do you-- first of all, do you dispute it or concede it? And in either case, do you find it concerning?

### Scientific Advocate (SA)
Claim: I'm not sure I'm willing to dispute it, but I'm willing to suggest that, you know, we're at a very-- it may not feel like it to many of us in this room-- Nick obviously the exception, having only had a smartphone for six months. This technology is still relatively new. It doesn't always feel that way, but a lot of this technology has been in mainstream adoption in the United States for less than a decade.

And I think, you know, one of the things that's very clear is that the first studies that were done about the impact of the Internet on our sociality, on our personalities, have long since been eclipsed by I'm thinking about that Sara Kiesler did at CMU, some of the other pieces of work, where some of the earlier assessments we made about how technology would affect people have now been proven, when you have more data, to be very different. And then I think the second question is, I am also interested in what those studies look like beyond the United States, and about what it means to not keep reducing smart technology down to Facebook, Google, Twitter, and a phone, when in fact, we know that the technologies that are in people's worlds that are smart are far beyond that. And the impact of those, I think, is much more complex.

Smart Technology is Making Us Dumb

### Moderator
Claim: Andrew Keen? Do you want to respond to that point? Because again, you're more on the cultural topic, but I'm--

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: --interested to see how you would process that.

### Conspiracy Advocate (CA)
Claim: I'm very suspicious of Genevieve's sort of argument about the non-Western world.

We always hear this about these new technologies. We always hear, "Well, this is going to change everything. This is going to empower aboriginal people. This is going to solve poverty. This is going to allow people to develop their economies.” And as we know, from the way in which they-- when it comes to politics, this technology was, as Genevieve says, is empowering, is liberating. But look at the Arab Spring. The Arab Spring was embraced by the digital utopians, because it was supposedly throwing off autocracy. It was supposedly doing away with the totalitarianism in the Middle East. But what we've seen after the collapse of the Arab Spring is more anarchy. And what we see with this technology is its failure to actually create coherent political movements because of the death of distance, because of this intimacy and personalization.

We saw the same, indeed, with the Occupy movement in the United States. It's like a firework. It explodes. And when you look up in the sky, it's wonderful for about 10 seconds. And then it goes away. There's no consequence. There's no depth. The very depth that Nick talks about in epistemological terms is also missing in social and political terms. So I think we have to be extremely careful to say, "Well, all this technology is going to change everything for the next 2 or 3 billion people who are about to experience this technology."

### Conspiracy Advocate (CA)
Claim: I'm particularly wary and troubled by that.

### Moderator
Claim: Genevieve Bell.

Smart Technology is Making Us Dumb

### Scientific Advocate (SA)
Claim: Well, as you full well know, Andrew-- as am I. And I was very careful not to say that. I'm not talking about the liberation--

### Conspiracy Advocate (CA)
Claim: Well, you did talk about aboriginals.

### Scientific Advocate (SA)
Claim: I talked about aborigines. I didn't say it was liberating them. I said the technology was being used to do things that made people's communities function in ways that they liked. I was arguing that it wasn't making them dumb. I want to be really clear here, right? This is not a cyber-utopian argument.

This is an argument that says there are things that technology can do that don't necessarily have to be about liberating everyone or changing everything for it not to be making us stupid. That it's completely possible to imagine a world in which people use technology to enhance their daily practices, to support traditional culture, to find ways to marry traditional culture and science that doesn't necessarily have to be-- what was your phrase? Oh, liberating the next 3 billion people.

### Moderator
Claim: David Weinberger, I-- do you want to respond to that, Andrew? Go ahead.

### Moderator
Claim: Not like he might want to.

### Conspiracy Advocate (CA)
Claim: I've never wanted to respond to anything, but you're

### Scientific Advocate (SA)
Claim: Oh, just twist his arm.

### Conspiracy Advocate (CA)
Claim: At what point-- I mean, maybe we're – we can gang up on our moderator here collectively.

Smart Technology is Making Us Dumb

We still need to come up with a definition of smart technology, because at what point is a tap smart technology? My assumption in this debate-- and I think although the discourse around it, is that the smart technology of network society, it's digital technology. And in that sense, you know, David's arguments about the web I think were flatware

So I do think we have to be careful because, after all, everything is technology. You know, this pen is technology. The-- a water pipe is technology, a bathroom is technology. I'm not arguing against those things.

### Scientific Advocate (SA)
Claim: Well, and as far as I know, bathrooms are not yet causing epistemological chaos, but we could get there.

### Conspiracy Advocate (CA)
Claim: You haven’t been in mine.

### Moderator
Claim: David Weinberger, I--

### Scientific Advocate (SA)
Claim: So far.

David?

### Moderator
Claim: David, I want to--

I want to bring this back to a high level, high plane. Your opponents mentioned Arab Spring as being something of a catastrophe of smart technology, by which I think what they're really saying is that at the time, back in 2011, that it was hailed as a-- as a moment of triumph for Smart Technology is Making Us Dumb smart technology bringing together people forcing political action, ultimately leading to their liberation and freedom, or at least the impulse in that direction.

And now it doesn't look so good. I want to sort of get your reaction to that. Does Arab Spring represent the failure of the promise, or does the Arab Spring reveal the false promise of smart technology?

### Scientific Advocate (SA)
Claim: I'm not sure who made the promises. I'm also not entirely sure what this has to do with being dumb. But-- or smart.

### Moderator
Claim: Well, I think it does in a sense that we're making broader claims about the-- about whether cultures are getting-- are being raised up.

### Scientific Advocate (SA)
Claim: Okay. So--

I do think there's some disagreement on the panel about what we're talking about in terms of culture. Andrew. So-- I’m not sure what promise was made. I don't know who makes promises and so forth. But the internet proved itself not only to be a superb tool for organizing, for organizing people without a leader, which is a pretty remarkable thing. This was a leaderless organization.

It also, I noticed, from talking with people from Tunisia, they credit, at least in part, the internet with giving them the idea of freedom, the sense that they can have a voice. They should have a voice. They are-- it is their right as citizens because they can do it on the net. Why can't they do it in public for their government? And I will use the word; that is empowering. And so they use the internet in a complex environment. They organize, they, in some senses, in some places, they won, and then larger forces came. It turns out that what we now know is that the internet is really great at leaderless organization, but doesn't necessarily always lead to the next stage of governing. So that--

### Moderator
Claim: Nicholas Carr. Nick Carr.

Smart Technology is Making Us Dumb

### Conspiracy Advocate (CA)
Claim: I think the internet is a communication platform. And you can communicate good stuff, and you can communicate bad stuff. You can communicate healthcare information, as Genevieve said, or you can be ISIS and send out YouTube videos of beheadings as a recruitment tool.

You can-- you can organize antigovernment protests or you can be the government using the technology to track those protesters and throwing-- throw them in jail. So I don't think you can-- I don't think you can leap to the assumption that even as a basic communication platform this is something that is naturally or inclined to be a good thing that raises people up and lets them think deeper thoughts. I think it can do both things, as all communication platforms do. And I think we really have to-- have to look at what-- how the technology influences what we do with the communications, how it influences our relationship to our thinking and to one another. And there, I think the picture is much darker.

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: So, yes, internet is just a communication platform, but it's not just a communication platform. It has particular, as they say, affordances, things that it's good at. And so if you're on the internet, you are very likely going to learn some things beyond that you can communicate.

You will learn that you can talk. You can speak. The entire world can listen. This is so different than it was 20 years ago. Anybody anywhere can talk and the entire world can listen. They may not, but they can. It is an environment where you can speak without permission, and it's an environment that is linked. Links are like the new punctuation. They're-- instead of putting a full stop or a half stop, you put a connection. This type of new punctuation is transformative in our idea of how things go together and our agency in doing so. So I don't think it's just a communication platform, and I think that you can generally learn some things just by using the internet. It does help shape some of those ideas.

### Moderator
Claim: Andrew Keen, go ahead.

### Conspiracy Advocate (CA)
Claim: I think, again, we have to be very, very careful here, David. You said the internet allows people to talk as if somehow in the pre-internet age, before computers, people couldn't talk.

Smart Technology is Making Us Dumb It's that kind of argument which I think puts the digital camp in trouble, because the reality is, is that we always talked. The digital platform certainly does enable us to talk. It certainly enables us to get a global audience. But the reality, of course-- and McLuhan came out with this in his ironically termed "Global Village," is the ironic nature of the internet is it's not global. The ironic nature of the internet, okay, the wires are-- everywhere you go, it's the same-- it's the same technology and everyone's on the same platform. But the reality is study after study has shown-- as shown in an excellent book called "The Filter Bubble," the reality is that we're talking to fewer and fewer people. So if anything, I'm not going to-- I'm not going to fall into your dystopian/ Utopian trap. But if anything, we're talking less now than we were before the invention of the internet.

### Moderator
Claim: David Weinberg.

### Scientific Advocate (SA)
Claim: So, Andrew, you have to hear the complete sentence. What I said is it enables us to talk, and the entire world to listen. And that is new. And as I said, not everybody in the world will-- let me--

### Conspiracy Advocate (CA)
Claim: not listening. That's the point. I mean, you could argue, if I shout loud enough, the entire world could hear.

### Scientific Advocate (SA)
Claim: Then you should have listened to the second sentence after that, in which I said, it doesn't mean that anybody is listening. So yes, filter bubble--

### Conspiracy Advocate (CA)
Claim: It also doesn't--

### Moderator
Claim: Wait, guys. Wait, wait. Nick, Nick, Nick, let him make his point. I'm going to moderate now. Let him make his point, and then we'll come back to you because you're kind of doing the thing that you're saying people do on the internet right now. But much higher value.

Smart Technology is Making Us Dumb

### Scientific Advocate (SA)
Claim: we hear filter bubble is a serious issue to worry about, needs to be addressed somehow. And, yes, Andrew, of course, not everybody hears what you're saying.

But compared to the prior media regime, the ability for-- which was basically, if you wanted people to hear you, you put it-- you wrote a letter to the editor, and you're lucky if it got printed. And if it did, it went to your community. The ability for people to talk and to say uninteresting-- things that are interesting to them, but maybe not interesting to you-- and that matters. The ability of people to talk and address the world is new, and it is-- it is transformative.

### Moderator
Claim: Okay. I want to get a response from this side, but Genevieve, we haven't heard from you in a while. And for that reason alone, I want to hear from you. But let's go back to Nick to respond.

### Scientific Advocate (SA)
Claim: Wait. How does that work?

### Moderator
Claim: Sorry?

### Scientific Advocate (SA)
Claim: I said, "How does that work?"

### Moderator
Claim: Well, I want to--

It worked like this: I want you to talk soon.

### Scientific Advocate (SA)
Claim: Oh, right, not now.

### Moderator
Claim: Smart Technology is Making Us Dumb But I just wanted to have-- they were-- I asked them to wait, so I'm fulfilling my pledge to them to talk.

### Conspiracy Advocate (CA)
Claim: I'll be brief. Genevieve talked about, you know, that the internet may be making us dumb or that smart technology may be making us dumb now, or at least what's the evidence suggests but at some future, it'll make us smart. David talks about the fact that we-- that anybody can communicate anything to anyone else now.

But what he doesn't talk about is what actually people use the internet for, for communicating. We're not all broadcasting these deep thoughts. We're sending out links to silly videos. We're going-- spending huge amounts of time on Facebook. We're spending lots of time on Twitter, sending Snapchats. We have to-- in order to answer the question before us, we have to look at how this technology has actually evolved, how people are actually using it now, not some Utopian dream of how it can be used, and how that reflects on the depth of the thought it is inspiring in us.

### Moderator
Claim: Genevieve Bell, I think it's just been handed to you.

### Scientific Advocate (SA)
Claim: I think it has. And I absolutely agree with you, Nick. And I think the phrase that is a dead giveaway to me is, it's not like they're saying anything interesting, which you muttered before he cut you off earlier.

The notion that anything interesting is telling, I said in my opening remarks that one of the challenges I have here is, what is dumb and what is lying underneath that judgment? And I think sometimes using dumb is a way of talking about some other things. It's-- buried in that is notions about what is appropriate discourse, what is sufficiently merit-worthy, what is-- and, you know, this is a place where, truthfully, you know, although David and I both fundamentally and violently disagree that smart devices are making us dumb, we do come at this from two very different positions. And mine is very much about saying, "Listen, there are lots of things that people do with technology in this current moment that may not rise to the bar of tenured faculty and book writers.” That doesn't necessarily mean it's dumb. Is everyone who's on Facebook dumb? That makes everyone in this room dumb-- is-- I'm willing to bet, and if not you, then your children. Smart Technology is Making Us Dumb And while you may say many things about your children, you are not yet willing to imagine they are dumb. Does it mean that every single one of us who uses GPS because we're directionally challenged is an idiot?

Does it mean the fact that I like Microsoft to spellcheck me make me dumb? I don't think so. So there's sort of something in there about what is the judgment lurking beneath "dumb" that requires just a little bit of scrutiny.

### Moderator
Claim: I'm going to audience questions now. And right-- sir, if you-- I'm looking right now-- if you could stand up, our mike's going to come down on your right hand side. And, again, if you can just hold it this close to your mouth so we can hear you, and tell us your name, and tell us your question.

### Moderator
Claim: Sure, my name is Rahul. And my question is really about the kind of things that Genevieve was talking about. If we agree that the more data points we have makes us-- allows us to have smarter decisions, regardless of how banal or mundane those decisions are, because the Internet and smartphones give us more data points, doesn't that necessarily make us smarter in the decisions we're making, even if it's about knowing more about cute cats, but we're smarter about knowing about cute cats?

### Conspiracy Advocate (CA)
Claim: I will give that point to you.

### Moderator
Claim: Nick Carr.

### Moderator
Claim: Yeah.

### Conspiracy Advocate (CA)
Claim: I think actually in theory that should be how things work, but as we've talked about with filter bubbles that actually what happens is people tend to go out and don't expose themselves to lots of different points of view and don't gather lots of different data points. We tend to go out, and we read and look at those kind of points of view that reinforce our own biases. So Smart Technology is Making Us Dumb often it's not-- the dream was that we'd use the Internet to challenge ourselves. In fact, what most people do is they go out and find stuff that confirms their existing biases, and that makes those biases even stronger.

### Conspiracy Advocate (CA)
Claim: And let me just jump on your question in terms of--

### Moderator
Claim: Andrew Keen.

### Conspiracy Advocate (CA)
Claim: --this data points, this idea that knowledge is simply join the dots or join the data dots. It's more complex than that. As Nick is saying, what we're losing is the subtlety, the depth, the sophistication of thought. In an odd way perhaps we're becoming like our machines. But that in an odd way as well makes us dumber than we once were.

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: Oh, so much to respond to.

### Moderator
Claim: I'm going to give you 30 seconds because we want to go on to other questions.

### Scientific Advocate (SA)
Claim: Okay. I shouldn't have said that. Dang it.

### Moderator
Claim: Yeah, yeah, you shouldn't have. Yeah.

### Scientific Advocate (SA)
Claim: So, to Nick's point that we're-- we use the net to talk about things that aren't interesting, I think it's actually an argument against language itself, because most of what we use language for is to talk about things that are not broadly interesting. We seek out sites that we agree with in part because we fall prey to this filter bubble and confirmation bias thing, but also because when we want to-- that's how understanding works. When we want to understand something, we go-- to understand it is to fit it into our context. That's maybe a bug in how understanding works, but it is how understanding works. So it actually makes sense when you have a question Smart Technology is Making Us Dumb to go to a site where your fundamental principles and context are shared so you can make sense of what they're saying. That's just how understanding works.

### Moderator
Claim: Fifty-five seconds. Sir, right down front, here. The mike is coming.

### Moderator
Claim: Hi, my name is Robert Klein We can talk about the technology, the Internet, and the search engines, but what about the devices themselves? I see a whole young generation of my grandchildren and their peers growing up with their-- and using their thumbs instead of their brains. And almost-- it's like a pacifier for young children. And so how can that possibly really produce young adults or teenagers who are smarter? I mean, how can it do anything but hold back the brain from achieving its full potential?

### Moderator
Claim: Let me take it to Nick Carr first.

### Conspiracy Advocate (CA)
Claim: Sure. I think they're-- I think the negative effects influence people of all ages, 80-year-olds as well as 10-year-olds. But I do think it's particularly dangerous for young children whose-- we know their brains are in the process of being formed.

And we also know that the best thing you can do for a child is to give them lots of different experiences, interacting with the world in lots of different ways, playing with clay, doing-- you know, interacting with people face-to-face. And what we're doing often with a-- with even ever younger children is putting more and more of their attention on screens. And we're seeing this in schools, we're seeing it out of schools. And I think it's hard to conclude, from what we know about child development, that kind of giving this more and more constrained way of interacting with the world is going to produce broader-minded, more curious children. I think it's going to have the opposite effect.

### Moderator
Claim: Let me take the question to the other side. Now, you're allowed to applaud. It's – If David or Genevieve would like to take that?

### Scientific Advocate (SA)
Claim: Yeah. I mean, I think-- Smart Technology is Making Us Dumb

### Moderator
Claim: Genevieve--

### Scientific Advocate (SA)
Claim: --there are a couple of things that run through that, right? Is we have a persistent anxiety about the impact of new technologies on our children. This one has a particular kind of visceral-ness to it. I'm willing to bet many of your parents worried about the impact of radio, rock and roll, television on all of us. The jury is in some ways still out on rock and roll, obviously, but not the rest. there's something about why it is that we worry about technology and children in particular. And I think, you know, there are reasons to suggest-- and Nick's right on this-- that a diversity of experiences is a good thing. The challenge, however, here, is also beyond the kind of notion that every child is born with a smart device in one hand, and only a thumb in the other. The reality is that in lots of places in the world, kids are not using new technology. In lots of places in the world, there are cultures about how technology is introduced into children that suggests that, you know, you may be disadvantaged because there are other places-- if that's your fear-- that this is not happening. But I think it's a hard one to argue, right, is to say, "Is, you know, technology pernicious and bad for children?" Well, it's an argument that's been rehearsed for nearly 200 years. And I think all of you are living proof in the room that rock and roll didn't rot your brains.

### Moderator
Claim: Well, maybe we would all be a lot smarter if that rock and roll thing hadn't happened.

### Scientific Advocate (SA)
Claim: Well, you know-- fair point. We could always go look for some countries that didn't have it and see what the comparative state is.

### Moderator
Claim: Ma'am, down here? The mike is to your left. Yeah. Do-- would you mind standing up?

### Moderator
Claim: Smart Technology is Making Us Dumb Oh, sure.

### Moderator
Claim: Thanks.

### Moderator
Claim: I was just wondering if the answer would be different for the sciences and math versus-- I mean, we've been talking about-- a lot about reading, and on the Internet, and things like that. And then you were talking about the particle collider. And so, I wonder if it would be two different-- are there-- do you have two different answers for the different disciplines?

### Conspiracy Advocate (CA)
Claim: No. I don't. I mean, I think deep thinking is deep thinking, whether you apply it to a poem or to a scientific problem. I do think-- I mean, and that's not to say there aren't good things about being able to exchange information very quickly. I think science advances a lot-- in many cases, by being able to exchange information quickly.

So that's a good thing about the Internet. But you come back to the point that we are having more and more trouble screening out distractions and interruptions, and really thinking deeply about something, which means concentrating our focus and concentrating our mind. And that's every bit as important to scientific discovery as it is to the humanities, right?

### Conspiracy Advocate (CA)
Claim: And I think it's important to add that both science--

### Moderator
Claim: Andrew Keen.

### Conspiracy Advocate (CA)
Claim: --and the humanities are victims of this technology. So, supporters of the smart technology often point to Wikipedia and say, "Well, Wikipedia is the example of how smart technology works.” But all the research on Wikipedia indicates that the content there isn't very reliable. So, for example, when it comes to the medical information on Wikipedia, a board of doctors who researched this found that nine out of 10 articles on Wikipedia about medical were inaccurate, which is obviously particularly troubling.

So, I think we have to be careful to believe that somehow, smart technology generates reliable, scientific information, but not information about the humanities. I think it's--

### Scientific Advocate (SA)
Claim: Smart Technology is Making Us Dumb Listen--

### Conspiracy Advocate (CA)
Claim: --unreliable in both sense.

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: So, if I understand your question correctly, if we look into the sciences, we see that smart technology has enabled a rapid advance of those sciences. What we're doing now would be absolutely impossible without the Internet. And not simply because of the rapid communication. It's really important-- but also because it has enabled-- things have grown up that enabled sophisticated collaboration. Management of gigantic multinational projects. It's enabled a type of iterative knowledge as well, in which ideas are put forward, and then iterated on in public. And this is actually a pretty new form of knowledge. It can be done at scale. The Internet is enabling open access, which is the movement that-- the idea that scientific research and research in the humanities, academic research should be available for free to anybody online.

This is peer-reviewed, but not put it into academic journals that can charge 20 or $25,000 for a subscription, which is driving our libraries into great despair. And so, this ecosystem that Nick refers to, which I think is the right word, is in fact one that is extremely-- is enabling science to proceed, and research in general can proceed at tremendous pace and enabling it to get deeper and deeper and more and more complex. I just don't know the people, Nick, who don't think deeply, who don't have a moment to think, who are distracted by their thumbs, that they don't-- who? I don't meet them. I see so much more deep thinking out in the world than I--

### Moderator
Claim: Maybe we should ask for a show of hands for--

### Scientific Advocate (SA)
Claim: So two

### Moderator
Claim: Let me just say this. I want to remind you that we are in the question-and-answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator, and we have four debaters, two teams of two, arguing it out over this motion: Smart technology is making us dumb.

Smart Technology is Making Us DumbSir. Folks, if you're upstairs raising your hands, I have to say I can't see you, so if you have a question, you might want to come downstairs.

### Moderator
Claim: I would like to readdress-- and perhaps this is exceeding the scope of the argument about smart technology, the word they came up with. Well, what about artificial intelligence? Now Siri is this automated discussion Google robot. But, you know, I don't want to exceed the scope of the debate, but can we address artificial intelligence and how that might--

### Moderator
Claim: I will let you address artificial intelligence if you can really nail a question that--

### Moderator
Claim: Right.

### Moderator
Claim: Think about it. I'll come back to you.

### Moderator
Claim: Okay.

### Moderator
Claim: But seriously, it might be a great question.

### Moderator
Claim: proposition. I didn't really have a--

### Moderator
Claim: Okay. You're done? You're-- so you got your 15 seconds in, huh?

### Moderator
Claim: Hi. My name's Stacy.

I wanted to address how parents use apps and smart devices to help make their children smarter. I know that my sister and my mom often will look to apps to fill in the gaps that they have in their knowledge. Is that making us smarter or not?

### Moderator
Claim: Smart Technology is Making Us Dumb That sort of gets to the heart of the question, at least whether, in fact, these devices are extensions of our brains that support us or whether they are just things that are turning our brains into hard drives. I like the question. I want to take it to Nick Carr first.

### Conspiracy Advocate (CA)
Claim: I think there's no question that if you need to get an answer to a well-defined question, that there's nothing so good as Google or Tweeting it out there or whatever. And again, that's one of the good things about the technology. But deep thought in the-- and I'm back to this again. Deep intelligence isn't about getting precise answers to well-defined questions. It's being able to know, what are the big questions you should ask?

How do you fit this information together to form conceptual knowledge, to get big-picture knowledge? And if you spend all your time Googling and grabbing information, you might think you're smart. In fact, there was a very interesting study that came out just a couple of months ago that-- that showed that people tend to think they're smarter because they're Googling all the time, and they confuse what's on Google with what's in their own brains. And as one of the researchers said, we have this weird-- we're in this weird time where we seem to be getting dumber, but we are thinking that we're smarter. And that's kind of the illusion that this-- being wrapped in this information often provides. But, you know, we have to make that distinction between getting quick answers from Wikipedia maybe, or from Google or whatever, and being smarter. And I don't think they're the same thing.

### Moderator
Claim: Genevieve or David.

### Scientific Advocate (SA)
Claim: So, listen, I mean, Nick, I think it's interesting, right. You’ll concede to the notion that a well- formed question is an appropriate way to engage with a piece of technology.

I'd sort of suggest that being able to form a well-formed question is an act of intelligence, right, being able to work out what the information is you want to extract and find the app that does it suggests a level of engagement with the world that's not about dumbness. I mean, I think it's coming back to this for me, right, is how are you framing "dumb" and it's opposition and what that means, right. If you're a new mom trying to work out, is this not sleeping thing a good thing or a bad thing, and when do a worry? Those are questions that technology may be able to save you quicker than calling your own parent because she's in a different country. Is that about making you more dumb? I don't think so. So there's something for me again about how we are framing the notion of dumbness and its opposition that I keep coming back to, right.

### Moderator
Claim: Smart Technology is Making Us Dumb David, hold up one second. I want another response to come from the other side. Nick.

### Conspiracy Advocate (CA)
Claim: Let's look at the question of how well we-- how well formed our questions are. There's an interesting interview just recently with a top search engineer at Google. And he was going through how much better the search engine has gotten in anticipating what we need and stuff.

And the interviewer said, "So I assume that as the-- as Google search engine has gotten smarter, people's questions have also gotten smarter.” And he said-- he laughed and said, "No, it's exactly the opposite. People get lazier and lazier.” And this shows how we become dependent on the technology to do our thinking for us. And as a result, we get lazy, we fall victim to what scientists call automation complacency. You just simply think, let the machine do it for us. So even the formation of questions, we seem to be getting worse and worse as the searching gets better and better.

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: So--

As I understand it, Nick, what's actually going on with the searches is that they've gotten much longer. People actually type, "What is--" you know, the whole question with the question mark at the end, because that now works. Whereas before, the well-- forming a question well with Google meant figuring out what were the terms that Google wanted that would give you back the right results. It wasn't about good question forming, it was about being-- it was Google knowledge, you know, knowing how Google worked.

But I think that your comments about people Googling and they think that they're smart is that you're actually, I think, repeating Socrates' mistake which is, you know, really good company to be in. But in the Phaedrus I'm sure you know this is in the Phaedrus Socrates makes a terrible mistake, doesn't make a lot-- a terrible mistake. He's wondering about the smart tech of his time, which was writing things down. It was literacy. And he said, "This is terrible because our memory will fail. We'll get much worse at remembering things.” And he was absolutely right about that, because if anybody here would like to stand up and recite "The Illiad" by heart, please do so and show me wrong. But generally, our memory has gotten much smaller than it - - than it was. So he was right about that, but he was wrong about the effect of literacy. The Smart Technology is Making Us Dumb effect of literacy has in fact made our memory a thousand times better. We know so-- we remember so much more as a species.

### Moderator
Claim: Andrew Keen.

### Conspiracy Advocate (CA)
Claim: But that wasn’t Nick’s point. I think just to speak-- no, but you're the one who brought up Socrates, right? And so I can bring him up too.

### Scientific Advocate (SA)
Claim: I was making a point, though, so--

### Conspiracy Advocate (CA)
Claim: Well, no, but you brought Socrates up, so I'm going to-- I'm going to – I'm going to bring him up too. So what was-- Socrates is great, his contribution. Nick was just saying that while the problems with Google or our search-centric culture is people are increasingly lazy. And what they're really lazy about is asking questions. What we're having is the automation of the act of asking a question. And that is one of the consequences or casualties of this digital revolution. And, of course, Socrates' greatest-- one of his greatest contributions to our culture was in the art of asking the question. That was the whole point of his philosophy, was it was about asking questions.

That's what knowledge was, asking questions. And as Nick has made it clear, we have forgotten, or we are forgetting how to ask questions, and that's extremely troubling.

### Moderator
Claim: David Weinberger.

### Scientific Advocate (SA)
Claim: So the other criticism-- the other criticism or fear that Socrates had in that dialogue about writing was that written stuff is never as good as in person, face to face, because the written thing will not respond to you. You can't ask it a question. And the internet is not a series of answers. It's a series of conversations of various forms. And now we are able to engage in conversations about any topic, whether it's about epistemological chaos, or it's about whether Smart Technology is Making Us Dumb a Mini Cooper is any good in the winter in Boston. And we can talk about other people, and we can get answers. This is a far more interactive and responsive medium than we've had before, except in person conversation.

### Moderator
Claim: I think we're going to have time for one more question. I'm just curious myself, as this debate has proceeded before you, has anybody been multitasking in any form? Yeah? Some hands have gone up.

### Moderator
Claim: They all have.

### Moderator
Claim: You missed an amazing debate.

Right there.

### Moderator
Claim: Hi. My name's Devina I have a question about Cuba. I was there a little over a year ago, and--

### Moderator
Claim: I just want to warn you, this has to really zoom in very quickly.

### Moderator
Claim: Wait. The question is this: The Cubans, for the last over 50 years have not had access to almost any technology, and they've been living in a way where they are-- the fiber optic cables are built around Cuba. They're not-- they're not-- and when I was there, we were in a lot of bars and--

### Moderator
Claim: Okay, I--

### Moderator
Claim: But there wasn't wise-- there wasn't this wise thought And I'm wondering what-- are you disappointed with humans, or do you think that in the absence of technology people are just sitting around and like thinking about what's the meaning of life or-- you know, they want technology. Like, they're talking about so-- Smart Technology is Making Us Dumb

### Moderator
Claim: Okay, that is a great question. That's really good. Actually was great. I'll take it to Nick Carr.

### Conspiracy Advocate (CA)
Claim: There is-- I'm not-- I'm certainly not arguing against technology.

Technology is books, technology are the good things we can do with computers, the way computers can help us do things. What I'm arguing about is how we think today, thanks to our dependency on our smartphones and our computers and our dependency on social media, and looking at the evidence. And the evidence is-- and you can certainly understand why people who are cut out from the technology would want in, but that doesn't change the fact of how we actually use the technology and how we behave with it, and how it influences our thinking. And the studies and the research and the science points to the fact that we are, in fact, turning into scatterbrains. And, you know, it may well be that Cuba will get all of this technology, and they'll enjoy many benefits from it, but they'll probably have this same debate there in 10 years or 15 years or whatever, because they'll realize that there's a lot that's lost as well as what's gained.

### Moderator
Claim: Okay, let me-- again, I like the question a lot. Let me bring it to Genevieve Bell.

### Scientific Advocate (SA)
Claim: Well, there's something kind of extraordinary in the notion that it's good for people to want in but only if they want in on your terms. I mean, it's sort of something you have to think about what--

### Conspiracy Advocate (CA)
Claim: I don’t think I said that.

### Moderator
Claim: Yeah, actually he didn't really say that.

### Scientific Advocate (SA)
Claim: --no, but there's sort of that-- well, no, I know, but it was close. Smart Technology is Making Us Dumb They could want the technology, but they shouldn't want it compulsively. I mean, I think there's sort of something interesting lurking underneath with that.

### Moderator
Claim: No, he didn't say that, either.

### Scientific Advocate (SA)
Claim: Really?

### Moderator
Claim: He said that, "Of course they want the-- of course they want it," but maybe the same thing's going to happen there that he feels has happened here.

### Scientific Advocate (SA)
Claim: Which is about-- what was the phrase you used-- if I'm going to attempt to get it right now-- it's "compulsive," right, that the compulsiveness of the technology--

### Moderator
Claim: Compulsive obsessive--

### Scientific Advocate (SA)
Claim: --nature--

### Moderator
Claim: --gathering of information.

### Scientific Advocate (SA)
Claim: --of our relationship to a particular set of technology is preventing kind of these deeper thoughts. I guess the question is-- and I would had to use Cuba as a kind of, you know, example, as a kind of laboratory experiment-- but if you were, what is the-- kind of the vision you then have about what the right use of it is? What's the right use of technology if the one we have now isn't it?

### Conspiracy Advocate (CA)
Claim: We can use technology in all sorts of ways, and there's nothing wrong with going on Facebook to see what your friends are up to, to arrange doing things. My vision, my point would be that actually what we've done is created this technological environment, both because of the interests of companies like Google and Facebook and Intel, to get us to be constantly interacting with our computer screens, constantly distracted and interrupted, and also because Smart Technology is Making Us Dumb we have inside our brains this primitive desire, well-documented, to want to know everything that's going on around us, probably because it helped save your life, you know, eons ago.

But we combine this commercial desire to keep people distracted with our own kind of proclivity to want to be distracted. And what that does is it makes it harder and harder for us to do something that's always been hard, which is to concentrate and be attentive and think deeply.

### Moderator
Claim: David, do you want to respond?

### Scientific Advocate (SA)
Claim: So you say, Nick, that-- I still don't know the answer to the question, though. I mean, you're not against technology, it's just what happens when you use technology. We seem to get--

### Conspiracy Advocate (CA)
Claim: Well, that's what we're debating.

### Scientific Advocate (SA)
Claim: --no, I-- I'm seriously curious, Nick, what you would recommend to Cuba as a policy, trying to avoid these terrible effects and only get the good uses that you have specified-- what you would recommend to Cuba as a company-- as a-- excuse me, as a country for a policy or to any user in the room, what it is that we should be doing in order to get the benefits of this computer based tech but not fall victim to the danger of being unable to think thoughts again.

### Conspiracy Advocate (CA)
Claim: Well, I'd be worried about putting it into the hands of Cuba's government or any government determining how we use technology or how we use information.

So I would-- okay, push that to the side. I would say that what we-- everything we know about it is that we should use it less--

### Moderator
Claim: That concludes--

### Conspiracy Advocate (CA)
Claim: --and what you use it for.

Smart Technology is Making Us Dumb

## Round 3

### Moderator
Claim: --that concludes round two of this Intelligence Squared U.S. Debate, where our motion is, "Smart Technology is Making Us Dumb.” Thank you for that Cuba question. That was-- thank you for persisting because it really got to an interesting place. So now we move on to round three. Round three are closing statements by each debater in turn. They will be two minutes each. Remember how you voted before the arguments began because as soon as this is concluded we're going to have you vote again, and then we'll have the results of your choice of-- your decision on which side was most persuasive. So round three, closing statements, first here summarizing his position in support of the motion, "Smart Technology is Making Us Dumb," here is Andrew Keen, author of, "The Internet is Not the Answer."

### Conspiracy Advocate (CA)
Claim: Well, you can't have a debate like this without again ending with Socrates and Plato, since we're supposed to be talking about dumbness and intelligence. You remember, or most of you should remember, in Plato's "Republic," Socrates' definition of intelligence was bound up in his notion of the cave and of being able to distinguish illusion from truth. And his argument in the "Republic" was that we were mostly looking at shadows in his cave. And going from Socrates and Plato back to David, let me quote him. He said, "The Internet is giving us the idea of freedom.” Let me repeat that. The Internet is giving us the idea of freedom. And I agree with him. It is giving us the idea of freedom. And he says that's empowering.

But look at our world. We're not empowered. It is, of course, the classic manifestation, perhaps in digital terms, of Plato or Socrates's cave, where we think we're empowered. We think, by making statements about politics, or economics, or supposedly bringing down some powerful figure, we think we're free. We think we're empowered. But this is the ultimate-- to borrow another philosophical term-- this is the ultimate manifestation of false consciousness. We're living in a world where we think we're empowered. We're living in the world where the idea of freedom has essentially been digitalized, and commodified, and sold to us-- or perhaps not sold because it's a supposedly free economy. But the truth is, in this world, we are more and more-- I don’t know about the word dumb.

Smart Technology is Making Us DumbWe are less and less aware of our reality. We think we're empowered. We think we're free. And--

### Moderator
Claim: Andrew Keen, I'm sorry.

### Conspiracy Advocate (CA)
Claim: --actually, we’re living in the cave.

### Moderator
Claim: Your time is up. Thank you very much. Andrew Keen. The motion, Smart Technology is Making Us Dumb. And here to summarize his position against this motion, David Weinberger, senior researcher at Harvard's Berkman Center for Internet and Society.

### Scientific Advocate (SA)
Claim: Well, thank you. This has been really-- has been great. But I listened to your arguments, and I come back to the fact that, even if you're right about everything you said, I think it's undeniable that this is the greatest time in human history to be wanting to know. There is no better time. The access to information has never been this free. Everybody-- you don't have to be at a major university to get access to a wide range. The ability to engage-- not just read, and not to-- not even just to explore, to follow your interests where they go, by following links, and finding people who know things that you don't, and being guided to sources that you care about, that you didn't know existed, the discovery of knowledge and information in the world.

We've never had an opportunity like this. We have never had it. And the ability to participate in the creation of knowledge, whether this is by asking questions-- dumb questions, smart questions-- by posing wrong ideas and bad ideas and finding how the world reacts, by participating in a more genuine way and learning from people, by lurking on lists and seeing what people are saying-- where lurking means watching but not talking; it's not the bad lurking. We've never had to take a-- course at a major university for free, to read open access journals, where most of the best physics in the world, the best math in the world is being done. To think that this is not the Smart Technology is Making Us Dumb greatest age to be-- to want to know things strikes me as crazy, as crazy. No matter what facts you point at, and brain chemistry, et cetera-- all I-- well, none of which I deny.

Nevertheless, if the question is, is smart technology making us dumb, I think, just looking at what is there should tell us no. This is the smartest age we've ever had.

### Moderator
Claim: Thank you, David Weinberger. And the motion is Smart Technology is Making Us Dumb. And here to summarize his position in support of the motion, Nick Carr. Author of "The Glass Cage: Automation and Us."

### Conspiracy Advocate (CA)
Claim: Unfortunately, David, the science happens to be against you here. But we've been speaking mainly about communications and information. And I think that's a very important part of-- about smart technology, but it's not everything. What we're seeing now is we're relying on software, relying on algorithms to do more and more things. Not just to gather information, but if you're a pilot, you use them to fly.

If you're a doctor, you use them for diagnosis. If you're just an average person, you turn on Google Maps to get around. And we want to believe that this-- by handing over tasks to our computers, we'll be raised up. We'll-- our own talents will get sharper and better. But even here, the research points to something very different happening. There was a fascinating study done in the Netherlands, a series of experiments, where people were given increasingly smart software to do difficult tasks. And what the researchers found is that as the software got smarter, the people got dumber. They got lazier. They began to become reliant on the software itself. They weren't practicing their own talents. And we can see this as well in all of those examples I talked about. David mentioned, well, aren't pilots-- shouldn't pilots have the smartest technology possible? Actually, if you look at airline safety research, and if you look at the recent proclamations from the FAA, they're saying that over automation is actually making pilots less capable.

And we have to remove some of the dependency on computers. You see this as well with accountants who become overly dependent on their software and lose the sharpness of their thinking. You see it with doctors who become dependent on the templates that they go through when you're in the examination room. I talked about how the Google person saw this Smart Technology is Making Us Dumb with search as well. Another Google top engineer put the-- put the problem very bluntly in an article. He wrote, "Sharp tools, dull minds."

### Moderator
Claim: Nick Carr, I'm sorry, your time is up. Thank you very much. Our motion is "Smart technology is making us dumb.” And here to summarize her position against this motion, Genevieve Bell, vice president of the corporate strategy at Intel.

### Scientific Advocate (SA)
Claim: So the proposition, "Smart technology is making us dumb," it's clearly one that seduces many of you in this room.

I watch you applaud, I watch you nod, and I know that there's an echo in it. There's something in it that always appeals. We say the same thing about many technologies over the last 200 years. And I want to make us think for just a moment here about what is that seduction? What is the anxiety that is appealed to when you applaud the notion that this technology is making us dumb? Because at beginning of this debate, most of you raised your hands that you had smart technology in your lives. Those of you who don't own it know people who do and live in worlds that are augmented by it. When you ask if anyone in the room was willing to admit to feeling dumber about it, there were only two of you who actually raised your hand. That makes me suspect that the number of you in the room who feel it, it's why you applaud, but you wouldn't say you did feel dumber because of it. My suspicion is that threading through all of that is a very human set of preoccupations and anxieties, an anxiety about what technology means for us, what it means for our humanity, our bodies, our competency, what it means to have new technologies in some ways threaten some of those things.

But the reality is also, despite Nick's, in some ways, admiral notion that we should just use it less, that there is more and more technology in our lives, technology that we rely on, technology that some of us love, technology that many of us find valuable and useful and instructive, that helps shape our exercise, our financial futures, that we use for banking and travel and leisure activities. And there's something in all of this about why it is that despite all of that, we like to imagine we are more dumb. I find it hard to imagine, sitting in a room full of New Yorkers that you secretly in your heart of hearts believe you are dumb.

Smart Technology is Making Us Dumb I may be foreign to this country, but I'm not foreign to the idea of what New York stands for. Likewise to a radio listening audience who will feel the same thing. So it strikes me that it's very hard to imagine that smart technology is really making all of us dumb.

### Moderator
Claim: Thank you, Genevieve Bell. And that concludes our closing statements. And now it's time to learn which side you feel has argued the best here. We're going to ask you to go again to the key pads at your seats and vote a second time after hearing the arguments. Again, the motion is this: Smart technology is making us dumb. Press number one if you agree with this motion now. Press number two if you disagree with this motion now, or press number three if you became or remain undecided. And we'll have the results in about two minutes. Okay. I want to get your attention back, please. May I have your attention?

May I have your attention, please? Hello! Hello. Thank you. Thanks I wanted your attention while the-- while the results are being tabulated because I really wanted to say a couple of things about-- first of all about the audience questions tonight which were terrific. And it's not always true. They're all-- they all really moved this debate to great places, so thank you, everybody, who asked a question. And I also want to commend the debaters. They obviously feel very passionately about this. But there was a good deal of intellectual honesty and respect on both sides. And they just made it darn interesting for all of us. So thank you for what you brought. I also want to thank the generous donors who make these debates possible. The ticket prices do not come anywhere close to covering the cost of putting on these debates.

We are a nonprofit, and so we would really encourage you to visit our website, iq2us.org to make a donation to keep this going and help us to grow to even more debates in the future. And speaking of more debates in the future, our next one is going to be here at the Kaufman Center on May 26th. The motion is "Obama's Iran Deal is Good for America.” Among our Smart Technology is Making Us Dumb debaters, we're going to have a former special assistant to the president and White House coordinater for the Middle East, who just stepped down from the administration. Next month, we're going to be in Philadelphia again at the National Constitution Center where we have been staging a series of debates that take an absolutely constitutional approach-- issues to a very constitutional framework. And in this case, we're looking at the issue of whether same-sex couples have the right to marry. So on June 2nd, the motion will be "The equal protection clause does not require states to license same-sex marriages.”For the full list of our debates and to purchase tickets you can go to-- again, to our website. And finally, I mentioned this before, but I just want to mention it again, that this evening will live on infinitely and digitally through that-- that place they've all been talking about here tonight. And it-- and you can download all of our debates, including this one, through the Apple and Android mobile stores where we have a really lovely-- a lovely app. All of our debates, in both video and audio, are available there. And you can learn about upcoming debates and buy tickets. And it's a smart app, I need to point out. And you can watch the live stream on iq2us.org, et cetera. So, I have the final results now. It's all in. Let's remind you that the motion was "Smart tech--" that the motion is, "Smart technology is making us dumb.” And again, it's the difference between the two votes, before and after, that determine our winner.

Let's look at the first vote. Smart technology is making us dumb. 37 percent agreed, 33 percent were against, and 30 percent were undecided. Kind of a three-way split. Let's take a look at the second vote. Again, we're looking for the difference. The second vote, the team arguing for the motion, their second vote was 47 percent, from 37 to 47 percent. They picked up 10 percentage points. That is the number to beat. Let's see the team against the motion. Their first vote was 33 percent. Their second was 43 percent. They also pulled in 10 percent. It is an Intelligence Squared first. It is a tie. Congratulations to both teams, all four of our debaters. Thank you from me, John Donvan and Intelligence Squared U.S. We'll see you next time.
