# Debate Transcript

Topic: When It Comes To Politics, The Internet Is Closing Our Minds
Motion: When It Comes To Politics, The Internet Is Closing Our Minds

Debate ID: internet-politics


## Round 1

### Moderator
Claim: And now I'd like to introduce the chairman of Intelligence Squared, Mr. Robert Rosenkranz.

### Moderator
Claim: Thank you and welcome. Well, I don't mean to be a name dropper, but last week I posed our resolution to two of my dinner partners, Rupert Murdoch and George W. Bush. They both had strong views, and both were against the motion. Murdoch was vehement that FOX News is not polarizing, but presents-- but presents a more balanced view than the other networks and attracts an audience that is 40 percent Democrat, which I thought was an interesting statistic. And President Bush argued that in most of the world, the internet has opened minds to the way of life in the liberal democracies and has been a hugely constructive force for change.

He acknowledged the extreme polarization of American politics, but blamed it on the class warfare rhetoric of his successor. Whenever one thinks of their points, they do illuminate some of the subtleties in the language of our resolution. Murdoch correctly grasped that it does not posit that the internet is the sole or even the primary driver of the narrow ideologies that seem to dominate politics. Rather, he understood the internet as part of a broader trend toward a highly fragmented media. And President Bush, by taking the resolution in a global context, prompts me to clarify that what we expect to talk about tonight is American politics. Why might be the internet be closing our minds? The first reason is that the internet makes it very easy to tailor the information we get to conform to a preconceived world view.

We can choose news aggregators on the left or on the right, not to mention highly ideological bloggers and live our lives without encountering any contrary opinion. In a great little essay called, "Why Groups Go to Extremes," Cass Sunstein, the Obama administration's regulatory czar, demonstrated empirically that discussing issues with like-minded folks tends to make positions more extreme. In addition to self selection, the internet makes it easy for websites to, "personalize our offerings." It seems innocuous, even helpful when Netflix tells us that the viewers who enjoyed movie A also enjoyed movie B. But if you Google federal deficit or Medicare reform, is it healthy for your search to come up differently than mine based on what Google has been able to infer about our political leanings?

Those against the motion will argue that the internet is a vast information utility which facilitates search, learning and communications. Personalization may be a blessing, simply helping us make the choices we want to make. We can turn personal filters on or off, so there's no real danger here. And little hard evidence that Google has helped us erect mental fortresses through which contrary ideas are not allowed to penetrate. Indeed, the filters from the pre-internet era, three like-minded networks and a handful of local newspapers, were arguably less hospitable to views outside American census than the open marketplace and information and ideas we have today. To illuminate the complexities here, we have four distinguished experts, and it's now my privilege to turn the evening over to them and to our moderator, John Donvan.

### Moderator
Claim: Thank you, Robert. Thank you. And I would just like to invite one more round of applause for the benefactor of this series, Robert Rosenkranz. Yes or no to this statement: "When it comes to politics, the internet is closing our minds." The state of the online debate, that is what we're debating here tonight. Welcome from Intelligence Squared U.S. I'm John Donvan. We have four superbly qualified debaters, two against two. And what we're touching on here-- well, it starts with this, a sampling of this, and see if it's familiar. This is a recent exchange among Wall Street Journal readers who were posting to each other about health care or actually posting at each other. Glen, the liberal, just had his argument attacked by David, the conservative. Glen gets mad. “One wonders how you can even press the keys on the keyboard. Please just go away."David responds, "Now I know you're a liberal because liberals are rude and will not listen to any reason." A guy named Kevin joins in the attack, and he tells Glen to read up on economics and civics. Glen tells Kevin, "Put this in your pipe and smoke it, you pseudo intellectual rube." From nowhere, a guy named Mark weighs in. He tells Glen that he is "intellectually challenged” and advises him that he needs to “get some lithium." When it comes to politics, the internet is closing our minds. Is that what we just heard, our minds closing out there, or is it a great thing that these guys are actually out there engaging with each other at all? Our debate goes in three rounds, then the audience votes to choose the winner. Only one side wins. On the side for our motion, when it comes to politics, the internet is changing our minds, Eli Pariser, a board member and former executive director of MoveOn.org. His partner is Siva Vaidhyanathan, professor and chair of the Department of Media Studies at the University of Virginia. against the motion that when it comes to politics, the internet is changing our minds, Evgeny Morozov, a Schwartz fellow at the New America Foundation and author of "The Net Delusion." And his partner, Jacob Weisberg, chairman and editor in chief of the Slate Group. Our motion is, "When it comes to politics, the Internet is closing our minds." Let's meet our debaters now and welcome first Eli Pariser. And Eli, at the age of 20, you joined MoveOn.org to direct its foreign policy campaigns. And then a couple of years later, you became its executive director. You have been an online organizer all of your adult life. But now you are warning about the dangers of the internet. So what changed, you or the internet?

### Conspiracy Advocate (CA)
Claim: The internet changed more than I did.

### Moderator
Claim: All right. We'll see when you-- when you get up there, we're going to see what you mean by that. Your debating partner, let's welcome Siva Vaidhyanathan. you are a professor and Department of Media Studies chair at the University of Virginia. You're also author of this book, "The Googlization of Everything and Why We Should Worry." This is actually your second debate with us. And the first time you were debating for the motion, "Google violates its don't be evil motto," and you won. Do you still think-- do you still think Google is evil?

### Conspiracy Advocate (CA)
Claim: Well, I never thought Google was evil, but I did think that was an impossible standard for any company to hold, so it was actually not that hard to win. I think the really interesting question is, does Google think I'm evil.

### Moderator
Claim: Thank you. Our motion is, "When it comes to politics, the Internet is closing our minds." Let's meet the team arguing against. First, Evgeny Morozov. You're a visiting fellow at Stanford University, a Schwartz fellow at the New America Foundation. You wrote a book also, "The Net Delusion: The Dark Side of Internet Freedom." You have said-- this was in a TED talk, that when the internet reaches a remote Russian village, people are not going to be sitting there watching reports from Human Rights Watch; they're going to be watching pornography, Sex and the City or maybe funny videos of cats. So how worried are you about these cat videos?

### Scientific Advocate (SA)
Claim: Well, cats, I think are the new opium of the masses. And the the have figured it out, and they exploit perfectly a little thought control.

### Moderator
Claim: Thank you. And let's meet your debating partner, Jacob Weisberg. Jacob, you are chairman and editor in chief of the Slate Group. Now, you wrote for print, for everybody in the old days, the New Republic, New York Magazine, Financial Times among other places. But in 1996, you joined a new online magazine called Slate as its chief political correspondent. That was very early in the game. So what did you know back then?

### Scientific Advocate (SA)
Claim: Well, John, I was an early visionary. No, actually, I got very lucky when my friend, Michael Kinsley decided to found Slate, and it seemed like a fun thing to do. And it turns out it's impossible to go back.

The internet spoils you as a writer because of the freedom you have and the speed.

### Moderator
Claim: All right. Thank you, Jacob Weisberg. Our four debaters, ladies and gentlemen. Now, in this debate, you, our audience, are our judges. By the time the debate has ended, we're going to have asked you to vote two times, once before the debate and once again after the debate on the language motion and on your position on it both before and after. And what we want to ask you to do now is go to the key pads at your seat. On the right hand side, you'll see a keypad. And we'll ask you to vote your sentiment on this motion as you're coming off the street. Our motion is, "When it comes to politics, the Internet is closing our minds." If you agree with it, push number one. If you disagree, push number two. If you're undecided, push number three. And you can ignore the other keys. And if you want to correct your entry, just correct it, and the system will register your last vote. So that's locked out now.

Again, at the end of the debate, we're going to ask you to vote on the quality of the arguments that were presented here tonight, and the team that has the greatest differential between this opening vote and the closing vote will be declared by you, our audience, their winners. So we go in three rounds. The first round is seven minutes, each, uninterrupted by each speaker in turn. So on to round one, opening statements from each of our debaters, and going up first for our motion, which is, "When it comes to politics, the Internet is closing our minds," Eli Pariser. He's a MoveOn.org board member, CEO of Upworthy.com, and author of, "The Filter Bubble, What the Internet is Hiding from You." That book was the inspiration for our having this debate tonight. Ladies and gentlemen, Eli Pariser.

### Conspiracy Advocate (CA)
Claim: Good evening, everyone. I find myself arguing that the Internet is closing our minds with a bit of regret. This isn't the place that I would want to be, and actually as of a few years ago I would have been arguing the other side, but I've come to believe that the-- well, the Internet is incredibly good at getting groups of likeminded people to get together, think together, work together.

But it's actually quite bad at bridging between groups of different people, and that the view that the Internet is exposing us to all sorts of new ways of thinking and new ideas is kind of a dated view, that the Internet's changing, and that there are a few big companies that would like us to hold onto that idea that the Internet is still this kind of open place. So the core of my argument is this, attention is the most valuable commodity out there right now. If you command attention, then you can direct it towards products or services and you can make a lot of money, and that's why all of the big companies on the Internet are trying to figure out what the best strategy is for gathering as much of it as possible. And most of them are focused on the same strategy which is gathering as much data about us as they can and then using that data to give us what they think, what they predict, based on their-- this data and their algorithms, we're going to be interested in.

Relevance is the big watchword here. So, you know, if you talk to these companies, if you look at what they're saying, it's very clear that this is a big part of the business plan. Eric Schmidt says, "Very soon it will be nearly impossible to see something that has not in some way been tailored to you." Sheryl Sandberg of Facebook, says, "Within the next few years, it'll be anachronistic to visit a website that hasn't been customized to your personal interests in some way." And Facebook is becoming this growing source of how people get their news and how people get their information. So why are they doing this? Well, I think Evgeny actually put it really well. Why does Facebook employ filters? The more they know about us, the more they can make in advertising revenues. And the thing is that these companies aren't blind to the psychology of all this. They've read all of the studies that show that when you present people with information that confirms what they already believed was true, you can actually see these little bursts of pleasure happening in people's brains.

And conversely, when people are presented with information that challenges what they believed, they get cranky. That's just the way we're wired. And so if you're a company that's trying to meet stockholder demands and you have this power to present people with information that tends to validate them, why wouldn't you? As a result of this kind of personalization and self selection, we're more likely to see things we agree with and less likely to see things we disagree with. Now, to be clear, I'm not arguing that all personalization is bad. Personalization certainly can have benefits. I'm a Netflix user. But the question is, what are the driving motives behind the kind of personalization that most people use, and what are the effects of that personalization? And I'll argue that because of the motives of these companies, those filters that they're building are going to tend to surround us with information that's agreeable to us and not with information that's uncomfortable.

So a few examples of what this looks like in practice, it looks like one person googling Egypt and seeing lots of information about the Arab Spring and another person googling Egypt at the same time and seeing nothing about the Arab Spring. This actually happened, I've got the screenshots on my website. And, you know, I could run through a number of other anecdotes, but actually there's been a study-- the only peer reviewed study I'm aware of on the Google search results and the effects of personalization there-- that shows that 60 percent of the search results on a given front page are usually personalized. Either they're in a different order or they're actually, you know, totally different results based on who Google thinks you are and what it thinks you'll be interested in. So what I think we have to begin to do is to tease apart what the Internet actually does from what we wish it would do or what it possibly could do. And in particular we have to tease apart what's possible to access versus what people do access. For example, now that the-- it's easy now to access the front page of Le Monde or Die Zeit, as it is, in fact to access the New York Times.

So you would think, given this vast increase in accessibility of foreign policy, information, of what’s going on in other countries, that people would know more about what’s going on there. In fact that’s not true. According to a Pew study from 2007, people actually were more informed on foreign policy matters before the internet than in 2007. So when Jacob says you can find more sources than ever, it’s kind of beside the point. What’s relevant is that people come into daily contact more frequently, is whether people come into daily contact with more different sources and more particular, different ideological ones. I agree here again with Evgeny who says the regular folk don’t read sites like Global Voices, an aggregator of the most interesting blog posts from all over the world. Instead they are more likely to use the internet to rediscover their own culture and dare we say it, their own national bigotry. So to summarize, big companies are rapidly working to personalize your version of the web.

They want to show you what they think you’re going to be interested in. And this isn't passive. This isn’t me turning on Fox News or me turning on-- or picking up a copy of the Nation. This is embedded in an increasing number of websites. Yahoo News in 2007, was a gateway for 80 million people that looked the same. But now, Yahoo runs 13 million different variations of Yahoo News front page every day. And they’re different for each person. It’s hard to even see. We don’t know how tailored our view of the web is because you have to sit down next to someone else and look at the differences. So the object of this personalization is to get us to click more. It’s to get us to like more. And importantly, it’s to get us to click on ads. And there’s little benefit in that world to presenting us with information that makes us uncomfortable, that challenges our views, or that makes us think differently. I don’t think that this has caused the extreme political polarization that we’re seeing right now. But I think it can’t help but exacerbate it.

Google says that it’s trying to provide relevance. But what is the most relevant search result when you’re a 9/11 conspiracy theorist googling 9/11? Is it the conspiracy links that Google’s algorithm would tend to promote or is it the Popular Mechanics article that would debunk that stuff? I asked Google this question and they didn’t really have a clear answer. So it’s with regret that I think the Internet is not living up to its potential. The way that most people actually use the thing isn’t to broaden their political perspectives. In fact the path that we generally travel on online will tend to mirror our political views. Thank you.

### Moderator
Claim: Thank you Eli Pariser. Our motion is "When it comes to politics, the internet is closing our minds." And here to speak against the motion, Jacob Weisberg. He is a pioneer in online journalism. Jacob is editor in chief of the Slate Group, the internet based arm of the Washington Post Company.

### Scientific Advocate (SA)
Claim: Thank you John. Eli, you can’t have Evgeny. He’s committed to me till at least 8:15. Look, I’ll concede that the internet narrowing our political perspectives is an interesting theoretical problem. People do have a tendency to prefer listening to what they already agree with. And the internet makes it easier in theory for people to live in a solid cystic bubble, where they mostly interact with people who have similar views. But is that a phenomenon that’s getting worse? And if it is getting worse, is it getting worse because of the internet? Eli, and I think Siva, is going to argue that because, they think that because Google and Facebook are bad for us, it must be. But their skepticism about these tools we use every day is kind of the mirror opposite of the cyber utopians who think that new technology only brings us good things. There are a lot of interesting theoretical problems from the Malthusian food scarcity to the Y2K bug, that are just never born out in practice.

The Atlantic Magazine gets a cover out of this every month right? Is Google making you stupid? Is Facebook making you lonely? That’s actually the cover this month. Is Twitter destroying your attention span? But cyber realists like Evgeny and me try to look at questions like this in a more empirical way. So what’s the evidence for tonight’s proposition, the internet is narrowing our views. I won’t say there’s none, but I will say it’s laughably weak. And there’s some really good evidence that the web’s doing the opposite of what our opponents claim, that it’s exposing us to a broader range of perspectives and making us less parochial in our outlook. And it’s on that empirical basis and on the basis of your own experience of not becoming more narrow, that you should vote against tonight’s motion. There’s of course some studies about this. There was one a few years ago that showed left and right wing bloggers don’t just talk to their own side.

They respond to each other and link to each other a lot, and it’s not all the kind of exchange John cited at the beginning. There's a Pew study from last year that show-- this is a quote, "No evidence that social network users, including those who use Facebook, were any more likely to cocoon themselves in social networks of like minded and similar people as some have feared." There's another new Pew study that says that people's social network friendships tend to cross political boundaries. The biggest study which involved 250 million Facebook users, yes, it was sponsored by Facebook, but it was a good study, showed convincingly that most people share links from people they aren't close to. That is, we do reach outside of our personal circles for news. So Eli said at the beginning of his very interesting book that he published last year, that "Google was tailoring search results to our politics." He said that on the basis of one anecdote from a friend I don't think he named. He had a similar anecdote tonight about Egypt. Allow me to be skeptical.

You can get-- you can do a funky search that gives you weird results at any time of the day for a variety of reasons. But I did a test on this where I asked friends of mine, different parts of the country, different political views, different worlds, to search some parallel, very political loaded terms like "climate change." And basically, they got exactly the same thing. And I don't think that there is more than anecdotes to support what Eli is talking about. I've looked at the studies. Now, since Eli wrote his book, Google has changed, and it now includes results from your social network and search returns. So if you're spending all your time on Google Plus, and you're the only people in your circle or Bill O'Reilly and Rush Limbaugh, you may in fact see some ideological bias in the returns. But Google added social searching in a way that actually specifically addresses Eli's problem. He had a lot of influence on this. You can turn customization off by pressing the prominent button that says, "Hide personal results." And you can toggle back and forth if you're curious about the difference.

On Facebook, it's just as easy to turn off customization. You change the sort option on your top stories to most recent. In other words, the filtering they do, these giant sites, is completely transparent and optional. I leave customization on most of the time because a social filter doesn't actually trap you in your own bubble. And take music just as an example I think we can all relate to. The reason I use Spotify, which is a social music service, is that I'm a little bored with the music I already know, and I want to be exposed to stuff I don't know, which I get through my Facebook friends. So back at the level of theory, could an algorithm personalize the news to figure your-- your political perspective? I think it's much harder to do that than it seems. News organizations are really trying to do that. They actually haven't been very successful, which is why, when you go to newyorktimes.com, and I go, we get the same home page. Of course, you can get narrow minded, politically filtered news, but you don't need the internet to do that.

You can go to Rush Limbaugh and the radio or FOX or MSNBC on TV. Now, it is worth noting that we did used to have the kind of constricting filter bubble Eli's worried about. And that was the mainstream media before the internet. When I was a kid in the '70s, you found out about the world through TV networks, a couple of news magazines, local newspapers. There weren't any national ones. And it was a very limited range of viewpoints and voices. And if you want to create that kind of filter bubble, all you have to do is remove technologies before television, before radio, before newspapers. So personally, I get a lot of my news these days through a tool called Twitter. I use it as a filter for stories that are relevant to me. And what it does is the opposite of narrowing my perspective. Thanks to Twitter, I'm regularly getting news from global sources as well as American ones. I tune into a lot of really interesting Arab voices during the Arab Spring. I followed China in part through an English translation of Tweets from Ai Weiwei the Chinese artist who's become one of the most important dissidents in the world today.

And those filters broaden my perspective. Twitter is a serendipity engine. Finally, I don't think you need to look at all these studies or understand algorithms to make up your mind about tonight's motion. All you have to do is ask yourself a pretty simple question: Has the web narrowed my mind? Has it made me less tolerant of people I disagree with and less interested in what they have today to say? Or has it exposed me to a broader range of voices, sources and ideas than we all used to get when we relied on a consensus oriented mainstream media for all our information? Unless you're convinced that the web makes you narrower, you should vote against tonight's motion.

### Moderator
Claim: Thank you, Jacob Weisberg. A reminder of what's going on. We are halfway through the opening round of this Intelligence Squared U.S. debate. I'm John Donvan. We have four debaters, two teams of two fighting it out over this motion, "When it comes to politics, the internet is closing our minds."We have heard the first opening statements, and now onto the third. Debating for the motion, the author of "The Googlization of Everything and Why We Should Worry," chair of the University of Virginia's Department of Media Studies. He's been called "Google's gadfly," Siva Vaidhyanathan.

### Conspiracy Advocate (CA)
Claim: Thank you. So the internet has so narrowed my mind that I didn't hear a word Jacob said. So in these brief comments, I will explain what Eli and I mean by the internet as invoked in the resolution and what we mean by politics. And I'm going to convince you to support the resolution. First, try to remember 1999, the days of AOL, the days of Prodigy, the apex of our long national nightmare of peace and prosperity. In 1999, Thomas Friedman wrote these words: "the internet is going to be like a huge vise. It's going to keep tightening and tightening that system”--meaning the system of globalization-- "around everyone in ways that will only make the world smaller, smaller and faster and faster."Well, Thomas Friedman could not have been more wrong. He's been exactly that wrong many times, but never more wrong. Now, in 2012, it's clear that there is no such thing as "The Internet,” capital T, capital I as Friedman and others so often described in the 1990s. There is no equalizing force, great democratizing force, there is no global network of networks that unites us all and gives us all equal voice to interact with each other across borders and across classes, for that matter. In fact, the alleged network of networks is, in 2012, balkanized, nationalized, compromised, anesthetized, supervised, circumcised and hypnotized. It's far from global, and it's getting less so every day. The online experience of a person sitting in Turkey is so different from the online experience of someone sitting in India and so different from the online experience of someone sitting in Iran or someone sitting in China.

And all of those are even more different from the experiences of people in Brazil, in Russia or the United States. And we're talking about more than censorship, although, in many of those countries, online censorship is a serious and crippling issue. We're also talking about platforms, the platforms that people use, the platforms that governments will let people use. The rise of kill switches is something we have to take into account as well. Kill switches that we saw a year ago in Egypt to wipe out internet communication in an instant, we've seen experiments in kill switches in China in early 2012, and we've seen people like Senator Lieberman even propose them in the United States. Internet technologies amplify so much of what we already are and what we already want. And the fact is, we're pretty provincial animals. So add the internet to it, we just double down.

We get more provincial. Platforms matter, defaults matter, and policies matter. So here in 2012, or now in 2012, we are not all holding virtual hands with our Facebook friends across the globe singing, "We are the world." There is no coordinated global movement for justice. There's no sophisticated online debate about our collective human state or even our basic human needs. The dominant powers governing our digital experiences, the state, for instance, in China, or corporations in Brazil or the United States are not interested in such matters. They are not interested in us being political. Sometimes these powers actively restrict us, like in China. More often than not, these powers seduce us into shallow consumption, consumptive behaviors like shopping or giggling at cats or clicking on cows. Not that there's anything wrong with clicking on virtual cows, but it ain't political.

Our minds are closing because our attentions are distracted, fractured and segregated into niches and nations. But all hope is not lost. There is nothing about the nature of the internet that prevents us from being political, richly political. Many of us actually are, I would suspect that most of us in the audience have done a pretty good job of avoiding these traps. We're pretty elite. We're pretty aware. And we're pretty connected. And we route around a lot of these problems. We're also hungry for information. If you weren't hungry, you wouldn't be here. So many of us, despite what Facebook does with thoughts, despite what the Iranian government does in Iran, have managed to be richly political. But we do know that the internet by itself does not topple dictators, does not undermine newspapers. It's just not that simple. If we recognized the biases inherent in many of the platforms of our media systems, we can correct, we can adjust, we can invest, we can invent, we can resist, persist, and thrive.

We could build platforms that enhance Republican deliberation and extend cosmopolitan perspectives. We just haven't done that yet. We've been really busy clicking on cows. But all that takes work. It takes real human work in addition to invention and imagination, real human effort. But the first step to recognizing that-- I'm sorry-- the first step to realizing that is to recognize what's happening. When it comes to politics, the Internet, most importantly how we experience the Internet is closing our minds one cow click at a time. Please vote for the motion. Thanks.

### Moderator
Claim: Thank you. Our motion is, "When it comes to politics, the Internet is closing our minds." And our final debater against the motion, he comes from the former Soviet Republic of Belarus, something that has shaped his interest in the Internet's role in politics, he is a Schwartz Fellow at the New American Foundation, and author of the book, "The Net Delusion," Evgeny Morozov.

### Scientific Advocate (SA)
Claim: Thank you. Well, I'm glad that Siva has chosen to debate with Thomas Friedman rather than with us, but I'd like to begin with a few lessons from history. First, technology always plays the scapegoat whenever it comes to debates about the closing of the American mind. Remember Allan Bloom and his bestselling book, "The Closing of the American Mind," in the '80s? Well, let me remind you, Bloom has actually argued that the closing of the American mind occurs because of CD players and headphones. And he actually argued that those might incite teenagers to kill their parents. We know what the late Allan Bloom would have made of the iPad, why his reactionary torch is now being carried by the liberal crowd from MoveOn is beyond me. The second lesson from history is that concerns about online polarization are as old as the As early as 1995, the Nation Magazine carried an article by Andrew Shapiro, which argued, and I quote, "Cyberspace is shaping out to be more like suburbia than cy-Berkeley, where you interact only with people of your choosing and with information tailored to your desires." That was 1995. Six years later, Cass Sunstein argued that, "The Internet is serving as a breeding ground for extremism because likeminded people are deliberating with one another without hearing contrary views," end of quote. So enter Eli Pariser. In one respect, he follows in the tradition of Shapiro and Sunstein. All of them present virtually no evidence that such online segregation is taking place. But they're also different.

Where Shapiro and Sunstein worried that we, the users, might choose the easy way out and simply award our comfortable viewpoints, but Pariser argues that filters and algorithms are doing this for us. It's a very important difference. Shapiro and Sunstein blame the filter bubble on us, the users. But Pariser blames it on the companies. Now, who doesn't like such an exciting conspiracy theory? After all, it's always good to find someone else to blame but us. I think this is a fairytale for many of the reasons that Jacob has outlined, but let me also provoke and give you three examples of how filters naturally enhance our political culture. So let's take Twitter. Many people think that Twitter, unlike Google and Facebook, does not engage in customizing and filtering. That is actually not true. Twitter does hide certain types of messages. Thus, if you follow me but you don't follow Siva, and I send Siva a public tweet, you will not see that tweet. Just think about it, you choose to follow me and you probably expect to get all of my messages, but you're actually not seeing my tweet to Siva.

And, mind you, Twitter made that filtering decision on your behalf. Is it paternalistic? Sure. Are these types of paternalism justified? Well, take my case. I follow more than 2,000 people on Twitter, and I'm very happy with the breadth of news I get. But if I have to read every single conversation that these 2,000 people have with thousands of people that they know but I don't know, I will have never managed to follow 2,000 people. At best, I would follow 100. This is the beauty of it, Twitter's filter allows me to access more, not less useful information. Now, let's take Facebook. It has 800 million users. Some of them are heavy users, they have 5,000 friends and spend hours on it every day. Others open it every few weeks and only have a few dozen friends. So Facebook has built this very collaborative differentiation. If you are a heavy user, it presents you all updates from your friends in the chronological order.

That’s the most recent updates from all your friends come first. However, if you only use it occasionally, they will show you only the most interesting updates. The assumption there is that if you have been away for three weeks and you only have 30 minutes to catch up, why go through thousands of messages in chronological order? To Facebook and to me, this seems like a reasonable assumption. That’s why relevance rather than recency is the default filter for the occasional users. If you want to see all the recent messages, all you have to do, as Jacob said, is just click a button called most recent. Sure we can have a broad philosophical debate on whether social networking is good or evil, but as long as we accept that social networking is a legitimate activity, we should also accept that filters make it better. Now let’s tackle the elephant in the room, which is Google. Suppose I’m so keen on conspiracy theories that my blackboard is larger than Glenn Beck’s.

So I believe that 9/11 was an inside job. I believe that Obama is a Kenya-born Muslim, that climate change is a non-issue manufactured by the lamestream media, that the government is hiding the truth about the UFOs and so on. In other words, I’m exactly the kind of guy that Eli is worried about. Furthermore, suppose that I became all of that before the filter bubble set in. In the great age of unfiltered viewpoints that we used to call the era of cable television. So now comes the filter bubble and Google starts personalizing my search results. Instead of seeing generic search results say about 9/11, actually see that some search results have already been endorsed or liked by my friends. In turn, when my friends use Google, they see the links that I visited and I liked as well. Now this is the new mutual exposure, why is it a good thing? Well if you think that all my friends are nut cases like me, then we do have a problem, because exposure all of us may end up becoming even more paranoid.

But let’s leave Charlie Manson and the Unibomber aside for a moment. I don’t think they’re representative of most internet users and their friends. The way Google and Facebook map out our social connections, they try to be very comprehensive. We see links from people we went to school with, our colleagues, our relatives, and so forth. It’s quite likely that many of these people will have radically different positions on 9/11, climate change, Obama’s birthplace, and UFOs. So my point is this, that a link to the report of 9/11 commission that has been endorsed by someone from my social circle, is more trustworthy than a generic Google link that has not passed through a similar social filter. In other words, it’s a possibility that people would now be paying more attention or at least more respect to positions they would otherwise find crazy and conspiratorial, only because their friends are known to endorse those positions.

So, to conclude, there are many good concerns about the future of the Internet. That of privacy ranks very high on my personal list, but the filter bubble is not one of them. It’s okay to hate Google and Facebook, but we should hate them for the right reasons. Thank you.

## Round 2

### Moderator
Claim: Thank you Evgeny Morozov. And that concludes round one of this Intelligence Squared US debate, where the motion being argued is, "When it comes to politics, the internet is closing our minds." Keep in mind how you voted at the beginning of the evening, because we’re going to ask you to vote again at the end and the team that has moved its numbers the most will be declared our winner. Now we go on to round two. Round two is where the debaters address each other directly and also answer questions from you in the audience and from me. We have two teams of two, who are arguing over this motion, "When it comes to politics, the internet is closing our minds." The side arguing for the motion, Eli Pariser and Siva Vaidhyanathan. They’re arguing that the internet is actually several internets, that they put up walls between the lands that are occupied by people of differing opinions, between nations as much as between liberals and conservatives.

And that especially with customization, designed to give us what we want, that the internet is getting worse at bringing together people who are not like minded. The team arguing against the motion, Jacob Weisberg and Evgeny Morozov, they’re saying sure, maybe these bad things could happen someday but there’s not much evidence that they are happening a lot yet right now. And besides a tool that can and does connect strangers globally around the world by definition, almost, is a good thing. And that customization, perhaps helps to organize the way that we think. So I want to put a question to the side that is arguing against the motion, that when it comes to politics, the internet is closing our minds. Jacob Weisberg, you said as your sort of slam dunk point to the audience, you have to decide whether you think the audience is closing your mind.

But if the other guys are right, they won’t know whether the audience is closing their minds because if their minds are being closed, part of having their minds closed is not knowing that their minds are being closed. I mean, but they're saying that it's an insidious thing, that it's a stealth thing, particularly with the customization, that it happens in a way that it comes to you-- you go through this process unawares. Can you take that on?

### Scientific Advocate (SA)
Claim: Well, this is the minds in a vat--

### Moderator
Claim: Are you-- I'm sorry.

### Scientific Advocate (SA)
Claim: This is the minds in a vat argument in philosophy, that if we were not actually embodied, but have our minds in vats being manipulated by space aliens, we have no way to know. I'm not sure I can answer that. But I do think-- Siva made this point that, well, for those of us in this room, this really isn't a problem. I mean, we're media savvy. We're educated. We're sophisticated. It's a bit-- it's a problem for the hoi polloi out there, the unwashed masses who, you know, are just getting spoon fed whatever they get fed. I find that argument condescending. I mean, we live in a democracy, and it seems to me that we're all responsible for the information we receive.

And not everybody engages as deeply in different subjects. But the difference with the internet is we can measure it. You know, we never knew who read the stories in the B section of the New York Times about Albany and the state legislature. On the internet, you know how many people click on them, but that doesn't mean--

### Moderator
Claim: It’s about 11, I think.

### Scientific Advocate (SA)
Claim: Yeah, exactly. But how many people actually read to the end or even the beginning of the story before we had the internet?

### Moderator
Claim: Well, Siva, take on, number one, Jacob's point that you're, I think, suggesting a little bit of snobbery here, that you're saying, we all can keep up with things, but that there's a great unwashed public out there that can be deceived by the power of these algorithms that are telling them what needs to show up in their searches.

### Conspiracy Advocate (CA)
Claim: I merely meant that Jacob's test, whether it works for you, wasn't a good enough test, largely because you are just you, and you are not we. You are not a greater sample, right?

So if we're going to be empirical, let's be good about the social science we deploy. That is the worst possible empirical test, what happens to you. It's almost laughable in its suggestion. So that can't possibly be the test when you address this question.

### Moderator
Claim: But wasn't your partner using the "that's what happened to me when I typed in Egypt"?

### Conspiracy Advocate (CA)
Claim: Let's talk a little bit about the studies about--

### Moderator
Claim: Eli Pariser.

### Conspiracy Advocate (CA)
Claim: --because I think it's worth digging into this a little bit. There is one-- first off, the reason that it's so hard to study this stuff is because the easiest way to study it is to get inside the black box of these companies. And these companies don't have any interest in letting people go in and prove that these companies are doing bad things. But it's very hard to look at from the outside, which is why there's just not many studies that haven't been, as Jacob said, you know, funded by Facebook, funded by Microsoft, funded by the companies themselves.

The one clear study on Google personalization that has been peer reviewed is a study by a guy named Martin Feuz. And it's pretty clear. The methodology is good. He looked at how a search history affects the personalization you get. And it's very clear, again, 60 percent of the search results on the first page are different for most-- for people who have a long web history in Google. But actually, the study that's the most interesting here is the Gentzkow study that Jacob was referring to. This is a study that was sort of initially described as a study that showed that people are linking to each other and that the internet isn't as polarizing as we thought. And the interesting thing is that if you dig into that study, it actually arguably shows the exact opposite. What they did was they created an isolation index for each different kind of medium. And so the isolation index for cable news that that study used was about 3.3. On the internet, the internet had a 7-- an isolation index of 7.

And so it's twice as polarizing as polarized as cable news. Now, what's more interesting is that this was-- the study was done before the personalized internet. So the main thing that that study was looking at was the fact that a lot of people, their online serving patterns lead them to Yahoo! and then from Yahoo! out to a whole bunch of ideologically diverse links. But Yahoo!'s changed since 2007, since that study was written. And so now, Yahoo! looks at your history on what links you've clicked at in the past and sends different people out in different directions.

### Moderator
Claim: Let me let the other side come in and take on--

### Conspiracy Advocate (CA)
Claim: One more though.

### Moderator
Claim: Okay, go ahead.

### Conspiracy Advocate (CA)
Claim: Which is that the other thing that's changed since that study was done is the rise of social media as one of the primary ways that people get information. And they did this isolation index calculation on people's sets of friends as well. So cable news is 3.3.

The internet in 2007 in the Yahoo! era was 7. And people's groups of friends was 30. Now, that 30 has become embedded in every experience that we have on the internet now. So you know, I think actually if you look into the studies that have been done--

### Moderator
Claim: Okay, let's let--

### Conspiracy Advocate (CA)
Claim: --it's quite clear--

### Moderator
Claim: Let's let Jacob Weisberg

### Scientific Advocate (SA)
Claim: I read the same study. It was a little baffling, but it said the polarization index for newspapers was 10. So the old media is well beyond the mean. I think you need to take all of that with a grain of salt. I mean--

### Conspiracy Advocate (CA)
Claim: But you cited it. I mean, this is the study that you were citing.

### Scientific Advocate (SA)
Claim: Right, exactly. And it doesn't show that the internet is the most polarizing thing. But there-- I looked at about half a dozen studies for this. And I would have to say, just trying to be as objective as possible, that the preponderance, the studies I didn't cite, say that there's not clear evidence this is happening. There's no evidence it's getting worse. And I--

### Conspiracy Advocate (CA)
Claim: What do you think of the Feuz study? Because we Tweeted about this.

### Scientific Advocate (SA)
Claim: I don't think it showed what you're saying it showed.

### Moderator
Claim: Let's bring Evgeny in and--

### Scientific Advocate (SA)
Claim: No, I just think, it's fine if we're talking about studies that no one but a few people in this audience have read, so they all sound But I think you also have to keep in mind that a lot depends on what kind of information you're trying to access online. If you're searching for a piece on Manhattan and I'm searching it from my mobile phone, then Google knows where I am, I would actually want 99 percent of the searches also to be personalized, probably not 60. Sixty is not high enough, in part because it's very obvious that what I want to do is to order a pizza. Right? So then if I am searching for political information, right, maybe the ratio should be 10 percent or 5 percent or zero. So to say that there is 60 percent of information that's personalized doesn't say much because it all depends on what it is that's being personalized. Another point is that, again, take something like YouTube. So if you don't sign in to YouTube, YouTube will show you at the very front page videos that are most popular with the rest of the crowd. You see all those fascinating cat videos. You will see all those videos from MTV. You will see whatever is now popular in the online world.

They will all be displayed to you, and you will see them there prominently. If I sign in with my Google account, with my search history, instead of cat videos, I'll see links to new exciting videos about history, about culture, about theater. Why? Because Google and YouTube know that those are the kind of videos that I like to watch. So if Google can show me more videos about history than videos about cats, I can't really see how the internet is closing our minds.

### Moderator
Claim: All right. Siva, are you arguing that the internet is closing our minds for your response.

### Conspiracy Advocate (CA)
Claim: Thank you, Evgeny, for making two of my points. Number one-- that the notion of personalization, either through Facebook or another social network or through Google is actually tremendously helpful to us for shopping. It's not so good for learning. When you want to learn--

### Scientific Advocate (SA)
Claim: About cats.

### Conspiracy Advocate (CA)
Claim: When you want to learn about anything complex, the worst thing you can do is subject yourself to a social filter.

The best thing you can do--

### Scientific Advocate (SA)
Claim: You need better friends.

### Conspiracy Advocate (CA)
Claim: --is to challenge yourself-- the best thing-- you're the person I retweet the most. The best thing you can do, you need to get out of the bubble. The best thing you can do is seek sources of expertise, seek sources that have-- that are particularly good at researching particular areas. Use online sources that are focused in particular areas like health, like science, right? That means call your librarian. That means talk to an expert. And that means go beyond asking a small set of people what the best way to explore a particular issue is. But for pizza, not a bad idea. And we can talk later, because I'll tell you if you're still interested.

### Scientific Advocate (SA)
Claim: integrate 2,000 people that are following Twitter, one of whom is you, why not integrate those sources in my search results? Why shouldn't I be able to see the searches of those highlights if no one is concerned about privacy? Don't you think the links you share or click on are not smart or interesting for me?

### Conspiracy Advocate (CA)
Claim: They are for you. That's why you're my buddy, right? But that doesn't mean necessarily that what I'm doing is enhancing anybody else's--

### Scientific Advocate (SA)
Claim: Why didn't you trust me to choose my friends and sources?

### Moderator
Claim: Eli Pariser, I--

### Scientific Advocate (SA)
Claim: You want to choose them for me?

### Moderator
Claim: We also think your opponents who are arguing against the closing of American's minds through the internet have also made the argument that this personalization and customization, the filtering helps you think. It helps you organize. It cuts away the chafe. It brings things down to a manageable amount of material. And I can see the appeal to that argument. So take that on, Eli Pariser.

### Conspiracy Advocate (CA)
Claim: Well, you don't hear me arguing that all personalization is bad or all filtering is bad. That's kind of a nonsensical argument. As everyone has said, filtering has been around as long as there's information to filter. But the question is, what are the filters-- what are the lenses through which we're looking at the world now doing for most people who are looking at the world through those lenses?

And I think we're talking a lot here about Twitter, but it's important to remember that Twitter-- actually it's hard to remember in a group of New Yorkers-- Twitter is a fringe phenomenon on the Internet relative to Google or Facebook. Twitter has a tiny, tiny user base compared to these other-- sorry?

### Scientific Advocate (SA)
Claim: Only 200 million.

### Conspiracy Advocate (CA)
Claim: Well, the-- but the actual-- the actual user-- you know, the active users, if you look at active users on Twitter, it's actually much smaller, it's about 25 million people, which is a lot of people, but not compared to Facebook, not compared to Google. And so we have to look at sort of how most people are using this stuff.

### Moderator
Claim: Yes, Jacob Weisberg.

### Scientific Advocate (SA)
Claim: I want to ask Eli one other question, I mean, since we're dealing with the interesting implications of this thing that I don't think is happening, how do you want to-- what kind of regulation do you want to deal with this problem?

Do you want to say that Google and Facebook aren't allowed to filter in certain ways, or do you want them to become this sort of paternalistic gatekeepers that say, "If you're searching for Lady Gaga video, you also have to have a little bit of this interesting study from the nonpartisan Congressional Budget Office.” Right?

### Conspiracy Advocate (CA)
Claim: I'm not suggesting that we replace the old media paternalism with new paternalism. I'm suggesting that, if we built these tools toward the purpose of helping people get good information, including a diversity of perspective, we could do that in a way that would draw on the Internet strength. So I'll give you one example, Facebook, the main way that you propagate information across Facebook is with the Like button. The Like button has a very particular valence. It's easy to click Like on, "I baked a cake," it's hard to click Like on, "Massacre in Darfur continues for 11th year." And so certain kinds of information propagate very readily.

Other kinds of information don't propagate at all. Now, without instituting any kind of objective paternalism, this is more important than that, you could put an Important button on Facebook that'll allow people to elevate the topics that they believed were important as well as the topics that they think are fun and interesting and that they'd like their friends to see. So there are ways of doing this that are Internety, that don't require, you know, someone in a room making these value judgments but that actually lead toward filtering, that helps us seek--

### Scientific Advocate (SA)
Claim: That still doesn't solve the filtering problem, come on, we'll still be as close minded if you buy into a paradigm with the Important button, it's just that now in addition to being close minded, three people in the audience will care about Darfur.

### Conspiracy Advocate (CA)
Claim: Well, it's better than none, but I think the interesting thing here that I kind of want to get to is-- I wanted to ask you about this, Evgeny, because you wrote a Slate piece recently in which closed with a call that was actually kind of more paternalistic than where I would go.

### Scientific Advocate (SA)
Claim: True.

### Conspiracy Advocate (CA)
Claim: You know, it closes by saying, "It's not unreasonable to think that the denialists of global warning or benefits of vaccination are online friends with other denialists.

As such, finding information that contradicts one's views would be even harder. This is a reason for Google to atone for its sins and ensure that the subject dominated by pseudoscience and conspiracy theories are given a socially responsible curated treatment." So can you talk about-- I was just curious about that because I can't make it square with your position.

### Moderator
Claim: Evgeny Morozov.

### Scientific Advocate (SA)
Claim: No, I think it's very easy to make it square. I mean, first of all, public health, particularly vaccination, I think it's different from political information. Political information is contentious by default. Vaccination related decisions are far more contentious because public health and often national security is at stake, so there is a difference there, first of all.

### Conspiracy Advocate (CA)
Claim: So you think--

### Scientific Advocate (SA)
Claim: Second of all--

### Conspiracy Advocate (CA)
Claim: --global warming isn't political?

### Scientific Advocate (SA)
Claim: --second of all, it is less political than public health.

### Conspiracy Advocate (CA)
Claim: Really?

### Scientific Advocate (SA)
Claim: Well, I mean, look, is anyone going to shut down the school or public square because of global warming tomorrow?

They will if there is an outbreak of an epidemic or some contagious disease. Again, you have to understand that this is a very particular context in which I think warning people about certain types of websites, which has nothing to do with socialization, has everything to do with certain publishers publishing deliberately misleading information about vaccination, for example, or about the risks of flu vaccines or any other sort of vaccine, and I think it would not be a bad idea for Google to show that there are sites which have actually been approved through peer review and through normal scientific practice and-- to show that, "Hey, you actually have sites which you can trust." I don't think it has much to do with filtering or the social layer.

### Conspiracy Advocate (CA)
Claim: But when you say it's not unreasonable for denialists to be online friends with other denialists and as such finding information that contradicts one's views--

### Scientific Advocate (SA)
Claim: We have freedom of association so it’s not unreasonable--

### Moderator
Claim: But let me bring in Siva, yeah.

### Conspiracy Advocate (CA)
Claim: Well, I would go to a less paternalistic position.

I don't think we should be in the business of telling Google what to do or telling Facebook what to do. I think we should be in the business of building new platforms, new tools, new ways of relating to each other. And having these conversations, I think everybody should read books about the subject, which is a pretty good way. And then adjust your own behavior and have those ideas echo through your social networks, that perhaps it’s a good idea to break out of the filter bubble.

### Moderator
Claim: Let me ask the side that’s arguing that when it comes to politics, the internet is closing our minds. For some concrete examples of this phenomenon that concerns you, actually having caused harm to the body politic, because there’s a little bit of an assumption, and maybe you’re not making this point, but there’s a little bit of this assumption that all do need to be talking to each other and that there’s a middle that we’ll all reach in some kumbaya moment. But in fact, what’s wrong with having people entrenched in their own camps, angry at each other? As long as the political spectrum is covered overall, what’s wrong with that? And what examples of harm can you talk about that have been caused by that.

### Conspiracy Advocate (CA)
Claim: Just a little story, when I was on the book tour for my book, I was on a radio show in St. Louis. And the host decided to make this big spectacle of having people Google Barack Obama and call-in and read their search results. It was a really boring radio hour. And the first person called in, the second person called in and they interviewed everybody and had people kind of do a read-off where they’re both reading it off at the same time and it was exactly the same. And I was thinking, this is the worse book promotion I’ve ever done. And then a third guy called in, and he said you know it’s the damndest thing, when I Google Barack Obama, the first thing that comes up is this link to this site about how he’s not a natural citizen. And the second link is also a link to a website about how he doesn’t have a birth certificate.

### Scientific Advocate (SA)
Claim: That was your publicist.

### Conspiracy Advocate (CA)
Claim: Oh, I was wondering about that.

But so, I think the danger here is that it’s not just that he was getting a view of the world that was really far off the average here. But he didn’t even know that that was the view that he was getting. He had no idea how tilted that view was. And that’s sort of the challenge. I just want to address one other point, which is that there seems to be this question about whether this is happening. And it’s really kind of funny to me, because if you talk to these companies and if you listen to what they’re saying, all of these companies are very clear that personalization is a big part of what they’re doing and what they're--

### Scientific Advocate (SA)
Claim: For pizza, weighted decisions. They are very clear. And they say we don’t want to do it for politics, we only want to do it for pizza.

### Conspiracy Advocate (CA)
Claim: Right, and the question is, can you trust them?

### Moderator
Claim: Let me-- Jacob, I think Eli left a pretty good image hanging out there, of these folks truly not knowing how much they don’t know and believing what they’re getting and not understanding how slanted it is.

That landed pretty well I think, so can you respond to that?

### Scientific Advocate (SA)
Claim: But a guy who called into a radio show? I know the plural of anecdote is data. But I mean, if this were really happening in the way you say it is, wouldn’t there be some kind of decent study that actually showed widely varying results? I mean as I say, I’ve tried to test this out as best I can. I’ve tried it myself on various browsers, signed in, signed out, Wikipedia always comes up first, sometimes it comes up second. Wikipedia’s vaccine entry is pretty good. I do not think there is actually the kind of variety you’re talking in searches done most of the time by most people.

### Moderator
Claim: Siva.

### Conspiracy Advocate (CA)
Claim: So, doing social science online is really hard because almost nothing is replicable. Right so almost any, even if you did a broader study than that, even if Eli did a broader study than that, the third person to do that study would not come up with the same results.

For the simple reason that both Facebook and Google are constantly changing their algorithms, constantly tweaking their algorithms for reasons we can’t possibly understand and are not allowed to understand. It’s also important to remember that there are so many variables in what you get. There are some searches that are more personalized than other searches. Again, for reasons that Google understands and we are not allowed to understand. There are some ways that you can generate different searches because there are certain keywords that matter more in certain geographic locations than others. So a search for S-O-X in Boston or Chicago will yield a particularly strong result and personalized in those areas where as S-O-X searched somewhere else in the world might yield gibberish because it doesn’t mean anything. So all of these variables, plus the big variable, whether or not you’re a Gmail user, whether or not you’re signed into YouTube, whether or not--

### Moderator
Claim: Are you agreeing with your opponent that you can’t make the case based

### Conspiracy Advocate (CA)
Claim: No, no, I’m, what I’m saying is that the empirical studies that have been done are limited in their utility.

What we do know is exactly what the companies say they do. And they say, and they've said to Eli on a number of occasions, that they personalize our results. And not that--

### Scientific Advocate (SA)
Claim: You have just disbanded the companies because I would actually prefer Google and Facebook to personalize my search results based on 500 factors rather than on just two factors.

### Conspiracy Advocate (CA)
Claim: I'm not interested in--

### Scientific Advocate (SA)
Claim: I don't want them to personalize my news or search results based on my sex and based on my race or based on how old they think I am. I would like them to take a broader view and incorporate 300 factors, 500 factors if it's necessary, rather than--

### Conspiracy Advocate (CA)
Claim: Okay, but you don't get to say--

### Scientific Advocate (SA)
Claim: me into a social group to which I don't want to be known. It's a good thing.

### Conspiracy Advocate (CA)
Claim: I'm not interested in attacking or defending the companies. I'm interested in explaining what's going on to the best of our ability. And we are feeling around in the dark because all of this is in a black box, private data, and yet so deeply important to our public lives--

### Scientific Advocate (SA)
Claim: That's how capitalism works. They have trade secrets. They will never disclose their algorithms--

### Conspiracy Advocate (CA)
Claim: I know.

### Scientific Advocate (SA)
Claim: --because if they do, you're going to suffer.

### Moderator
Claim: Jacob Weisberg.

### Conspiracy Advocate (CA)
Claim: I know. And that's the problem.

### Scientific Advocate (SA)
Claim: So why ask the impossible?

### Moderator
Claim: Jacob Weisberg.

### Scientific Advocate (SA)
Claim: I think there's another point here. We're talking mainly about Google and about Facebook that have these kinds of personalization you can turn off. Whether when they're turned on, they do what you say they're doing is a matter of some dispute. But most people don't get their news from Google search. And most people don't get their news from Facebook. They get their news from the news. Now, these are increasing sources of information of different kinds. But have you used Google news? It's not a great product, and it's not one of the top ways that people get their news. People still get their news both from traditional news sources and from big online sources like CNN, Yahoo! news--

### Conspiracy Advocate (CA)
Claim: Which is personalized.

### Scientific Advocate (SA)
Claim: Yahoo! news is the AP. If you go-- it's basically an AP news feed. There is a social feature, similar to Facebook and Google. You can turn off. You can have it personalized or not personalized if you prefer.

### Conspiracy Advocate (CA)
Claim: First of all, defaults matter. The fact that you have to know to turn it off to turn it off is a huge issue. There is a reason those social phenomena are on by default because it's in those company's interests to make sure that you do get personalized results.

### Scientific Advocate (SA)
Claim: But that's in our interest. I want it turned on.

### Conspiracy Advocate (CA)
Claim: But you might not realize that it's happening unless you happen to--

### Scientific Advocate (SA)
Claim: --personalized option. I mean, Siva, it's a chicken and egg problem. You will not realize that you can personalize them otherwise. And then I don't see this as an argument.

### Moderator
Claim: All right. I'd like to go to audience questions at this point. We're in the middle of round two. Our motion is, "When it comes to politics, the internet is closing our minds." Microphones will be brought forward if you raise your hand. Remember, about 30 seconds is what you'll get. You can state a quick premise, but please ask a question that keeps us on the topic of this motion, and we'll move along this debate. And I really do mean it to be a question, not a-- not a debating point. But we-- we did put out, on slate.com, who is our media partner, a request to them for questions from some of their subscribers.

And we also-- is Lenny Gengrinovich here? Did you show up? Yep, there he is. All right. So Lenny took the initiative of sending a question into us by email. So thank you for that. And I'm going to actually-- you can ask the question yourself. I just wanted you to actually make it drastically shorter.

### Moderator
Claim: Just one page.

### Moderator
Claim: And if you want, I can paraphrase it or-- I'll go ahead and paraphrase it for you. He basically makes this statement: The tiny minority of democratic citizens who are interested in political ideas and issues cannot have a discussion. They have freedom of speech, but there's nobody to speak to in the internet-- ersatz world of discussions which only hides the problem. Do you agree that our nation needs affirmative action for intelligent conversation? I'll put that to Siva first.

### Conspiracy Advocate (CA)
Claim: Most definitely, but we're doing it right now, right? It means that we have to have foundations like the foundation that supports this discussion.

It means that we have to have universities, and we have to have schools take these issues seriously. And make sure that we are all able to understand the environments in which we operate, that we have to understand the nature of these platforms and technologies. And when there is a suboptimal result, we have to know how to correct for it. And if we're not happy with it, to invent something new.

### Moderator
Claim: On this side, do you want to respond, or do you agree? Jacob Weisberg.

### Scientific Advocate (SA)
Claim: Well, I think, you know, the low quality of commenting is one of the big problems on the internet. It's one we've been very concerned with, particularly--

### Moderator
Claim: Jacob, can you just come in a little closer?

### Scientific Advocate (SA)
Claim: Oh, I'm sorry. We've been very concerned about-- at Slate over the years with improving it. The big breakthrough, I have to say, came from Facebook, through a technology-- an interface known as Facebook connect, which basically brought identity- based commenting to every website. And it means that because people are themselves when they comment, they're actually a lot more reasonable, not necessarily reasonable all the time, but they don't engage in quite the level of viciousness and ad homonym attacks and just soft point arguing they do when they're anonymous.

So I think partly this say problem I'm optimistic about improving through technology.

### Moderator
Claim: All right. Let's go out to the audience now. And right in the front row, right behind the clock. Again, if you can stand up and hold the mic close to your mouth. Tell us your name, please.

### Moderator
Claim: Hi. My name is Tal. And there's two main points in the premise tonight, one that our minds are being closed, at least more so than any other time. And two, that the internet is doing it. And I would like to ask the panel for the motion to address both of those issues.

### Moderator
Claim: I think they have. So unless you feel that you haven't covered that, I think that it's--

### Conspiracy Advocate (CA)
Claim: I would only qualify it by saying--

### Moderator
Claim: All right.

### Conspiracy Advocate (CA)
Claim: --it's not as simple as doing. It is that we are interacting with these platforms at such a high and intense level without realizing what's going on.

And that's what's happening. So it's amplifying what we were already willing to do, which is gather among ourselves and reward ourselves with positive affirmation. And that's really mostly what goes on on Facebook.

### Scientific Advocate (SA)
Claim: Siva, but first you argue to govern among themselves, but then you argue that the internet is getting balkanized, and we are all in our own little niches. I mean, how do you square it both of them.

### Conspiracy Advocate (CA)
Claim: Ourselves, that's one of the niches, right? And it's being balkanized nationally which then reduces the global political--

### Scientific Advocate (SA)
Claim: You aspire to this one global Utopia--

### Conspiracy Advocate (CA)
Claim: Very much.

### Scientific Advocate (SA)
Claim: --where people in China feel like people in India and Iran and elsewhere?

### Conspiracy Advocate (CA)
Claim: Yeah, that would be really nice.

### Moderator
Claim: Eli Pariser.

### Conspiracy Advocate (CA)
Claim: --is, you know, there's a great book called "the big sort" about how increasingly people live in communities that are like them, in homogenous communities. And one of the fascinating things about this book is that you have two things going on at the same time.

On the one hand, there is a broader set of types of communities than there was 30 years ago, right? That's undoubtedly true. On the other hand, for each individual person in that system, their neighborhood is more like people like them than it ever was in the past. And so you have local homogeneity and heterogeneity at the top level. And I think when people are trying to make the opposite argument, they point to, hey, look at the internet, there's all this different stuff out there. It's so heterogeneous. Everybody's talking. But actually, the question is, what are people's local neighborhoods like? And to the extent that we're now bringing those local neighborhoods with us online, what effect does that have in, you know, amplifying the homogeneity that increasingly surrounds us even when we're off line.

### Scientific Advocate (SA)
Claim: I would encourage you to look at the recent issue of American Journal of Political Science which actually debunks, the big sort bulk with a load of empirical data and shows that even in the off line world, that this has never held true.

### Moderator
Claim: Can you go up three steps, please, and turn right?

Ma'am? Yeah, you're rising-- on your other side, sorry. Just wait for the mic. Thanks.

### Moderator
Claim: My name is And I'm curious about either the growth of your audiences or the decrease of your audiences and the quality and the quantity of discourse that's been created over the past let's say three years.

### Moderator
Claim: So how would you relate that directly to the motion? Are you asking whether they're seeing a closing of the minds in the interaction with their readers?

### Moderator
Claim: In their own personal-- in their own personal writing and their own personal blogs and the information that they're providing--

### Moderator
Claim: Are they seeing minds closing?

### Moderator
Claim: Are they seeing minds closed?

### Moderator
Claim: Jacob Weisberg.

### Scientific Advocate (SA)
Claim: Well, I think I tried to answer-- I tried to speak to that in my introduction. No. I felt personally just the opposite.

I feel like I've never been in touch with a wider variety of viewpoints and people. And a lot of that is through social media, because people act as filters for you. When you find something that's somewhat interesting, whether they're a personal friend, whether they are someone in a field you're interested in, whether they're in another field or just someone you admire, they bring you a whole range of things, on Twitter, on Facebook. So no, my experience has been just the opposite.

### Moderator
Claim: Siva?

### Conspiracy Advocate (CA)
Claim: Well, I've written for Slate, so I've had a great experience. But I-- my experience is narrow. My experience is my own, and my experience is based on the particular subjects that I cover, which happen to plug right into these questions, for the same reason that this is not a representative audience of internet users, my readers are not a representative audience of internet users.

### Conspiracy Advocate (CA)
Claim: I just want to--

### Scientific Advocate (SA)
Claim: So I think that the fear that somehow diversity online is shrinking.

I think my own case disproves that. I mean, I have an unpronounceable name. I was born in the middle of nowhere in Belarus, and the only reason why I actually have the attention and the audience I have is mostly because of the Internet, because of the Twitter stream I run and because of active writing for online publications and doing a lot of online research in Google Scholar. So I would say that the fear that somehow it will become impossible for diverse voices from Iran or or elsewhere to get heard--

### Moderator
Claim: --direct interaction with the public has indicated to you that-- am I right, ma'am, you're talking about--

### Scientific Advocate (SA)
Claim: But, I mean, if I look at the public--

### Moderator
Claim: quality of discourse. I'm assuming that this debate is about whether discourse is closed, whether--

### Moderator
Claim: Okay.

### Scientific Advocate (SA)
Claim: My point of my own case shows that it's actually getting more diverse in terms of voices who never previously would have a chance to sit in an audience like this or participate in political debates but, you know, I participate in them.

### Moderator
Claim: Eli Pariser.

### Conspiracy Advocate (CA)
Claim: When I was at Move On, we tried a number of times to do these kinds of cross partisan conversations and have people sit down in a room together and talk.

And it is amazingly hard to do. And, you know, I think it's probably always been hard. I don't think that, that's a new phenomenon, but the degree to which people live in different universes of fact, not just different universes of opinion, in other words, the degree to which you can't even get to something to argue about because people won't even agree that, that's a thing, is, you know, really striking. And I can't help but wonder as Evgeny has, as have many of us, if the way that the Internet is structured isn't amplifying that and helping people who believe, you know, pretty in my opinion, you know, misinformation, like the Obama birth certificate stuff or that climate change is not something that's partly caused by people, is it amplified by that.

### Moderator
Claim: Siva.

### Conspiracy Advocate (CA)
Claim: I have a really quick answer. I misunderstood your question. I apologize.

Before five years ago, I didn't have such a thing as Facebook in which to engage in conversation with my friends. I ran two blogs. And both of them were maddening because every conversation I had was overwhelmed by harassing people, people who were merely there to disrupt the conversation, not there to engage in a reasonable and rational way. We call them trolls. And one of the reasons that I closed down my blogs is it was so maddening that--

### Moderator
Claim: As opposed to taking lithium.

### Conspiracy Advocate (CA)
Claim: Exactly, exactly. The quality of discourse in the comments plus the spam was just out of control. On Facebook it's a lot more comfortable, right? It's a lot more pleasant. It's because I never see people I disagree with. It's really lovely now.

### Moderator
Claim: I think I-- a lot of the questions that came in--

### Scientific Advocate (SA)
Claim: You follow me on Twitter, though.

### Moderator
Claim: --a lot of the questions that came in through Slate are similarly focused on this question of the impact on the quality of the American political discourse and they-- Levi Osborne in Warrensburg, Missouri, asks, "Is it so much the internet in itself that is closing our minds as it is the hyper partisanship of these commentators which so many people listen to?"And by, "commentators," he's talking also not just about people who are online, but people who are also in television who are blogging, and people in newspapers who are blogging, but he's talking about the blogging aspect of people with hyper partisan points of view, and-- Jacob Weisberg.

### Scientific Advocate (SA)
Claim: Well, I do think the phenomenon of increased polarization in Congress is pretty clearly documented at this point. That's happening, and I deplore it. I just don't think the Internet has anything to do with it. I think the big drivers of that are redistricting which put people in districts that tend to go one way or the other and fewer that swing back and forth. I think it's fundraising which means politicians spend all their time fundraising and actually don't have human relationships with each other very much.

I think hyper partisan media, of which Fox is probably the best example, have some impact on it. But members of Congress, these are-- if you want to look for a group of people who really aren't on the Internet very much, that's them. I mean, I don't think it's what's driving it.

### Moderator
Claim: Siva.

### Conspiracy Advocate (CA)
Claim: So part of the phenomenon of the punditocracy is indignation. That's the currency. And indignation is a subset of the attention economy. In order to appear on CNN at 2:00 in the afternoon, in order to appear on Fox News at 7:00 p.m., you have to say something that angers somebody, either directly in their face, "I'm angering you as someone who disagrees with me," or more likely you gather people on your side to be angry. And the notion that we are so addicted to something now we can measure, the click, the instant attention, the instant affirmation, just reinforces that, so it is a phenomenon that's actually moved from the blogosphere, and that's why we've seen so many people who got famous being bloggers now are appearing on CNN at 2 PM, now appearing on Fox at 7 PM.

Right, that’s what’s happening. It’s why MSNBC is filled with former bloggers. It is because they’re already adept at generating indignation towards one side or another.

### Moderator
Claim: And is this a mind closing exercise or this just meaningless entertainment?

### Conspiracy Advocate (CA)
Claim: I think the results are.

### Moderator
Claim: It does have an impact.

### Conspiracy Advocate (CA)
Claim: But mind closing, yes.

### Conspiracy Advocate (CA)
Claim: I think, just to take a step for the resolution.

### Moderator
Claim: Eli Pariser.

### Conspiracy Advocate (CA)
Claim: I don’t think anyone up here thinks that the primary thing driving American-- the very partisan spirit of American discourse is the internet. The question is, is the way that most people use the internet helping or hurting? That’s the question that you really have to answer. Is the way that people are using the internet helping or hurting in this? And I think, it’s hard to argue, most people’s social networks are homogenous, that’s just true. Most people do have social networks that are largely made up of people like them.

Now there are the outliers for sure. But if you’re getting more from people who you know, you’re getting more of your news from people who are like you.

### Moderator
Claim: Okay, let’s go back to questions. You’re wearing a lime green tie. You’re looking at your tie. Sorry, that was a terrible cue to give, you’ve got to look down.

### Moderator
Claim: My name is Andy, so I have a question about confirmation bias. This is-- I really don’t know the answer, which is, do you think now, or before the internet, it was harder to avoid, whatever your ideology, information that would challenge your belief, be it the nightly news or an encyclopedia or the newspaper, whereas now, you mentioned Wikipedia. But that might be, there might be an analogue to the encyclopedia of old, but now you could just go to Conservapedia and find out that wow, Paul Revere actually, the ride was consistent with what it was described as. And so it’s a lot easier to find that information that’s going to confirm your biases and that would contribute to the closing of the mind.

### Moderator
Claim: But Evgeny kind of addressed that point when he-- I think you said, Evgeny, earlier in your opening statements, that initially the theory was the internet gave us tools to do stuff that we were already doing. But the other side is arguing that without our knowing it now, the internet is making us do that and we’re unaware of it. So do you feel that your question was answered?

### Moderator
Claim: Well it was more the idea of seeking out information that is going to be feeding your own biases, whereas you’re not exposing yourself. You’re not going to be exposed as much as you would before to stuff.

### Moderator
Claim: But is it, how is it different from 30 years ago, that if you, you could go down to the library and take out all the crackpot books that you wanted to.

### Moderator
Claim: Well that’s the question.

### Moderator
Claim: Let’s let Jacob Weisburg take that one.

### Scientific Advocate (SA)
Claim: Daniel Patrick Moynihan used to always say, everyone’s entitled to their opinion but not their own facts. And I think we all agree that in a democracy, you need an informational common to some extent, where people are arguing about what they think about reality, not about reality itself.

But I think Wikipedia’s a pretty great information commons. And it is again, the first search return on almost everything, or at least one of the first few. And Wikipedia has its issues and its problems but overall, Wikipedia strives to be neutral ground on an informational level. That’s an anecdote, but I think it’s an important one. I think the internet cuts both ways and in some ways, it can cut in favor of confirmation biases that you’re talking about, and in some ways it can cut right against it.

### Scientific Advocate (SA)
Claim: I think we also--

### Moderator
Claim: Evgeny, let me let the other side come back to that, to Eli Pariser, is arguing the internet is closing our minds.

### Conspiracy Advocate (CA)
Claim: Well just to go from anecdote to the study. One of the findings of the Pew study was that the more personalized Google search results, the further down Wikipedia was in the search results. So if you have an empty search history, Wikipedia is the top result. But the larger your search history, the less Wikipedia comes up.

The more it’s replaced by-- so this was the best study that we have on Google personalization. And it suggests, I agree--

### Scientific Advocate (SA)
Claim: But do you see any logic, why would Google deliberately want to demote Wikipedia in search results?

### Conspiracy Advocate (CA)
Claim: Totally, I see the logic.

### Scientific Advocate (SA)
Claim: What’s the logic?

### Conspiracy Advocate (CA)
Claim: I just think-- the logic, they have the means and the motives to provide the links that people will click on the most. That’s not the means and the motive to provide the links that are the most useful to people.

### Moderator
Claim: Because of that burst of pleasure that you talked about in people’s brains.

But Evgeny, I just want to let him finish the point. Is it because of that burst of pleasure principle that you talked about, that in fact, they’ve actually studied it. And that we feel good and we stick around if we get results that we like.

### Conspiracy Advocate (CA)
Claim: Yeah I think that’s one of the--

### Moderator
Claim: You never got the chance to respond to that point.

### Scientific Advocate (SA)
Claim: Google places no ads on Wikipedia. Google doesn’t care what you click on; all they care is you stay on Google.

Right? They don’t really care whether you go to Wikipedia or Conservapedia or somewhere else. Right, and I think right now what Google actually wants to do is present the result right away without having to spend any time on it. So, yeah, I just don't see the logic on which you're basing that decision. But the response to the question you asked, I think you need-- we need to set realistic goals for ourselves. We are not going to dissuade people who deliberately decide to go to Conservapedia instead of Wikipedia. There is nothing policy-wide that we can do. If people already decided to seek those very biased views. There is little we can do. I think we need not be Utopian. We have to set realistic policy goals. And from a public policy perspective, to figure out what we can do, change design, regulate Google, ask them to do something. But to expect that Google suddenly can wave the magic wand and make sure that people stop going to FOX News.com or Conservapedia and start going to Wikipedia instead, I think it's an unrealistic goal that we shouldn't even set for ourselves.

### Moderator
Claim: Siva.

### Conspiracy Advocate (CA)
Claim: Again, thank you for making our point.

That's basically what we're saying, that Google is in the business of making sure that if you are looking for a conservative opinion about something, you're going to get more conservative opinions about things. I'm sorry. If you've expressed a desire to click on conservative things, you're going to get more conservative things.

### Scientific Advocate (SA)
Claim: It is--

### Conspiracy Advocate (CA)
Claim: And we don't expect Google not to magically--

### Moderator
Claim: Evgeny, hold, let him-- let Siva finish, and you can come back.

### Conspiracy Advocate (CA)
Claim: Don't expect Google to change magically. We don't ask Google to change magically. What we ask is--

### Scientific Advocate (SA)
Claim: It doesn't do anything, what you are saying.

### Conspiracy Advocate (CA)
Claim: What we ask is that we pay attention closely to what Google itself says about what it does as is well documented, and we pay attention to the totality of our information ecosystem and the strong role that Google plays in that.

### Moderator
Claim: Evgeny Morozov.

### Scientific Advocate (SA)
Claim: It's all fine if you're paying attention. I'm all for paying attention to Google. It's just that Google itself goes on the record saying that they do not want to personalize politics. All they want to do is personalize pizza.

I think from a business perspective, I see no reason why Google would want to serve you biased search results and show Conservapedia before Wikipedia.

If you can produce a study that will prove that--

### Conspiracy Advocate (CA)
Claim: It does so mathematically, not politically.

### Scientific Advocate (SA)
Claim: --it's a vast for Google.

### Conspiracy Advocate (CA)
Claim: It does so mathematically, not politically. It doesn't distinguish between a political site and a pizza site because it doesn't do that.

### Scientific Advocate (SA)
Claim: --search for GOP, it knows you're searching for GOP and not pizza. It doesn't--

### Conspiracy Advocate (CA)
Claim: It doesn't read what GOP is, it associates it with all the other GOP clicks. It doesn't flag it as political. It just associates it mathematically with all the other behavior going on on the web.

### Moderator
Claim: So GOP could be pepperoni as far as the algorithm is concerned.

### Conspiracy Advocate (CA)
Claim: Grand ol' pepperoni, yes.

### Moderator
Claim: All right. I want to remind you we're in the question and answer section of this Intelligence Squared U.S. debate. I'm John Donvan, your moderator. We have four debaters, two teams of two debating this motion: "When it comes to politics, the internet is closing our minds." And, sir, right in the center there. Yes. I'm sorry. I meant a few rows back. I'll try to come back to you. My apologies. That was an ambiguous signal. And I didn't mean you, either, but-- I'm-- you got the mic. You win.

### Moderator
Claim: Hi. My name is John. So I don't really hear anyone saying that information moving quickly and lots of information is closing our minds. I hear not the internet but internet companies or even personalization is closing our minds. So my question for the team arguing for the motion is, would something that wasn't corporate, like a public search engine alternative to Google that's nonprofit and not commercial solve some of the problems? And then my question for the against the motion team would be, would you be opposed to something like that as a policy decision because you love personalization so much?

### Moderator
Claim: And I'm assuming that this publicly-- this public service search engine would not be doing personalization.

### Moderator
Claim: Well, perhaps it-- I mean, there could be a social aspect like, town halls.

### Moderator
Claim: Okay. All right.

### Moderator
Claim: Sort of public spaces--

### Conspiracy Advocate (CA)
Claim: That's a really intriguing possibility of a public search facility or public search engine or some sort of non-corporate entity that would help us guide us in certain issues, right? That's a nice idea, and I think it's worth pursuing and experimenting. I'm not willing to predict the results. I think the important thing is that we try everything. The important thing is that we let a few things fail, and we try to learn from our mistakes. But we do so openly. We do so deliberately. And we don't sign away so many important things to a black box.

### Moderator
Claim: Jacob Weisberg, your point.

### Scientific Advocate (SA)
Claim: I was going to say that the Google skeptics-- have you tried Bing? There are alternative search engines. But I think-- I don't think it's something the government needs to do. I think the idea of a nonprofit search engine is not a bad one, but I don't think it would fail to do personalization because I think a search engine that wasn't capable of personalization would be tremendously ineffective and disappointing.

And nobody would use it. If it didn't know where you were, if it didn't gather any information about what kinds of things you were interested in. I do think--

### Conspiracy Advocate (CA)
Claim: I don't disagree. I was just talking about transparency.

### Moderator
Claim: I want to go to another question, but I want to-- I want to confess that I would love to hear a female voice or two more in the mix tonight. And I-- I may be-- suddenly every hand went down. All right. I tried. Sir. Oh, right here? I'm sorry. I didn't see you. Let the mic come. Stand up. Let us know your name and justify my choosing you.

### Moderator
Claim: Hi. I was recently reading an article by Ethan Zimmerman, I think it was.

### Moderator
Claim: Zuckerman.

### Moderator
Claim: Okay, I'm seeing nods, yes. And suppose you don't know. It's an article about a theory known as cute cat theory, which is basically they applied it to the Arab Spring and saying that all of these movements, people that might want to watch cute cat videos, that's the majority of the people on the internet.

That's what they use it for. There is a small majority who use it for internet activism. Now, a site like YouTube that uses the majority of people want to watch cute cat videos, but it also posts things like-- like--

### Moderator
Claim: I need you to target in on a question.

### Moderator
Claim: Okay. Anyway, as far as maybe you guys can explain the cute cat theory a little better than I can. But cute cat theory, I'm interested to know-- I think that the cute cat theory opens up the possibility for neighbors, when the websites get shut down to talk about political issues. So for those of you arguing against the motion, I would be interested to hear your thoughts.

### Moderator
Claim: For-- for the people who have to edit this for television--

### Moderator
Claim: Yes.

### Moderator
Claim: Could you just restate the question and--

### Moderator
Claim: I'm sorry.

### Moderator
Claim: No, no. I think this is actually a great question. And I like the idea that they'll tell you what cute cat theory is. But if you could ask them about cute cat theory.

### Moderator
Claim: No, yeah. I'm sorry. I'm a little nervous

### Moderator
Claim: Sure. Go ahead.

### Moderator
Claim: Okay. My question basically is about cute cat theory and whether those who watch cute cat videos, when a site like YouTube gets shut down, if they-- they're more likely to then go find out why YouTube got shut down, thus turning them into internet activists.

### Moderator
Claim: Okay. Eli Pariser, tell us what cute cat theory is and whether it's relevant.

### Conspiracy Advocate (CA)
Claim: I'm not-- I don't feel well versed in cute cat theory, unfortunately.

### Moderator
Claim: Who's good on the cats?

### Scientific Advocate (SA)
Claim: Siva actually got tenure for his work on cute cat theory.

### Conspiracy Advocate (CA)
Claim: If I understand the-- I think this is a question about whether people will rally to support these online media that they depend on when they're under threat.

### Scientific Advocate (SA)
Claim: So it basically throws my cats are the opiate of the masses theory.

You get home, you watch videos of cats. Internet gets shut down. You go and overthrow Mubarak. If you think it's a good theory, good luck.

### Conspiracy Advocate (CA)
Claim: We actually know that there-- it's really hard to watch YouTube in China right now. And for a while, it wasn't so hard. First of all, YouTube comes over really slowly in the people's republic because its servers are hosted in North America. Google knows not to put the servers in China. That would be bad news. During the Tibetan uprising three years ago, YouTube basically went dark. During the Olympics, it went dark. And it's been intermittent since. And nobody has banged on the doors of the Chinese government saying, "I want my YouTube." They're busy with their own video services. They're busy with their own business. They're busy clicking on their own issues, right? So it doesn't necessarily follow in that example. The other thing to remember, when talking about the Arab Spring, going to a different part of the world, is that only 30 percent of the Egyptian population was online at the time. And then 11 days into the protest, zero percent were.

SMS was a much more important media form for doing anything. And Al Jazeera was probably the most important media forum for informing people. So what happened in North Africa had very little to do with cats, cute or otherwise.

### Moderator
Claim: Okay. Ma'am, right down in the front. In the third row, sorry. Right behind you, sir.

### Moderator
Claim: You guys have talked a lot about--

### Moderator
Claim: Can you tell us your name, please?

### Moderator
Claim: Debbie. You guys talked a lot about personalization of the internet and why that's bad. But I'm asking those who are for the motion, what about people who go and seek out information in terms of wanting to comment on articles and videos that are against their own beliefs?

### Conspiracy Advocate (CA)
Claim: Yes--

### Moderator
Claim: Eli Pariser.

### Conspiracy Advocate (CA)
Claim: Again, it's not that it's impossible or even that hard to find information that you disagree with online. There's a great cartoon that someone's staying up late at night and person tries to get them to come to bed, and they say, but someone on the internet is wrong.

That's like the experience that a lot of us have a lot of the time, but the question is whether the daily routines that we move through online will tend to bring us into contact more with people who make us feel that way or more with people who actually validate who we feel. And as social networking becomes a bigger phenomenon, and I think in specific Facebook, let’s separate Facebook from Twitter, it's easier than ever to surround yourself with people who mostly agree with you, that's who your friends are. Now, just to address Twitter in particular, like I agree with these guys that Twitter is like a pretty good medium for filtering the Internet and I use it to-- I follow Karl Rove on Twitter and I get Karl Rove's tweets and it's great. And, you know, I also follow him on Facebook, and I never see his Facebook posts because Facebook actually does a lot more personalization than Twitter does.

Now, you know--

### Moderator
Claim: Is that a relief to you or--

### Conspiracy Advocate (CA)
Claim: Yes, it-- well, Twitter's a relief--

### Moderator
Claim: Do you want more Karl Rove?

### Conspiracy Advocate (CA)
Claim: Twitter's great, but Twitter's not how most people use the Internet.

### Moderator
Claim: No, no, I mean, the-- I mean, the lack of Karl Rove's presence in your Facebook feed, do you want more?

### Scientific Advocate (SA)
Claim: The fact that he writes boring messages on Facebook and Facebook doesn't find them interesting doesn't necessarily mean that personalization is so bad.

### Scientific Advocate (SA)
Claim: But there are a lot of caveats where you can say, "Oh, well, Twitter's great, but it doesn't count because it's not big enough." I mean, just to go back to the numbers a minute, Twitter claims either, their numbers, 200-- more than 200 million registered users, more than 100 million active users. Facebook claims 800 million registered users, 400 million active users. I actually think Facebook's definition of an active user is much more generous to itself than Twitter, so maybe it is four times users, but, I mean, it's not insignificant.

### Conspiracy Advocate (CA)
Claim: Americans spend seven hours a month on Facebook.

They spend minutes on Twitter, like that's just-- you know, if you look at the comScore numbers, if you look at-- I mean, it's just nowhere near as powerful a medium.

### Scientific Advocate (SA)
Claim: As I said, people who use Facebook frequently, all see all most recent messages. There is no personalization. If you use it not seven hours a day but just one day a month, then -there is personalization.

And then there is no justification for you to see every single Karl Rove message because you only have 30 minutes and you have 5,000 friends and you have one hour a month to spend on it. There is no way for you to do it except for personalization.

### Conspiracy Advocate (CA)
Claim: Right, no, I agree with that. I'm just saying that a fact of that personalization--

### Scientific Advocate (SA)
Claim: So for seven-- for people who spend seven hours on Facebook every day, there is no personalization.

### Conspiracy Advocate (CA)
Claim: No, that's not correct.

### Scientific Advocate (SA)
Claim: There is no personalization whatsoever.

### Conspiracy Advocate (CA)
Claim: --I went on EdgeRank and--

### Moderator
Claim: Evgeny's right about that.

### Conspiracy Advocate (CA)
Claim: No, it's not true. There's--

## Round 3

### Moderator
Claim: All right, we're at an impasse. And that ends round two of this Intelligence Squared U.S. debate-- where our motion is, "When it comes to politics, the Internet is closing our minds."And here's where we are, we are about to hear closing statements from each debater. They will be two minutes each. Remember how you voted before the debate because this is their last chance to persuade you that they've presented the better argument. And you'll be asked once again to vote and to pick the winner in just a few minutes. On to round three, closing statements from each debater in turn. Our motion is, "When it comes to politics, the internet is closing our minds." And here to summarize his position against the motion, Jacob Weisberg, chairman and editor in chief of the Slate Group.

### Scientific Advocate (SA)
Claim: I did like one suggestion Eli made which is that there should be buttons other than “like” on Facebook. There should be a, "I'm not buying it," button, and I would have been clicking that the whole time I was hearing this argument. The Internet doesn't change human nature, it just creates new opportunities for us. And if your view of human nature is that people are naturally inclined to be ignorant and bigoted and extreme, you're going to focus on the way the web lets them become even narrower and more close minded.

But if that's your view of things, your problem isn't with the web, it's with democracy, because people like that aren't going to do a very good job of governing themselves. If on the other hand you think people are capable of informing and governing themselves, you have to appreciate the way that the web, which is the greatest trove of open information that the world has ever known, empowers us and broadens our political perspective. Evgeny and I have talked about some of those ways tonight, and I think Siva and Eli have talked about a theoretical problem that just hasn't been supported by the evidence or borne out. Does anyone here actually think that our political system would be better off without the web's democratization of information and the multiplicity of voices, if Tim Berners-Lee had never invented the world wide web, do you think we'd be better off if the web or Google or Facebook and Twitter or blogs were somehow magically taken away or regulated in some paternalistic way?

And I want to ask you again to think about your personal experience because it may not be an academic study but collectively it's meaningful. Do you think the internet is making you more narrow or is it exposing you to ideas, people, and arguments, and points of view that you wouldn’t have access to without it? In closing I just want to say that the idea that you and I would be less narrow in our politics without the web, isn’t just wrong, it’s actually preposterous. And that’s why you have to vote against tonight’s motion.

### Moderator
Claim: Thank you Jacob Weisberg. Our motion is "When it comes to politics the internet is closing our minds" and here to summarize his position for the motion, Eli Pariser, MoveOn.org, board member and author of the Filter Bubble.

### Conspiracy Advocate (CA)
Claim: So I want to read you a quote from two Stanford researchers from 1997. They said, "We expect that advertising funded search engines will be inherently biased towards the advertisers and away from the needs of the consumers. We believe that the issue of advertising causes enough mixed incentives that it’s crucial to have a competitive search engine that is transparent and in the academic realm."Now, the two researchers were Sergey Brin and Larry Page, and this was just months before they launched Google as a for-profit entity. I think that version of them was right. I think that the companies that increasingly control where and how we put information online have mixed motives. And the motives that they use in creating these filters may not be, and in fact aren’t in our best interests. They’re more likely to surround us with voices that tell us that we’re great and we’re right and we’re good enough and strong enough. And they’re less likely to confront us with the places where we’re wrong. What’s been interesting for me since writing the book is that I’ve actually been invited to come talk with engineers at all of these companies, Amazon, Apple, Google, YouTube, and Facebook. I’ve had conversations with people in each of those places. And it’s sort of funny for me to hear people try to suggest that it isn’t a big part of what these companies are trying to do. The engineers know that it is.

They wrestle with it every day. They wrestle with the mixed motives, with these questions of how they should be building these platforms. And they know as one Netflix vice president told me, that they can easily end up trapping people in these bubbles where they tend to believe the same thing. So if you believe that the companies whose algorithms decide what we pay attention to, will tend to expose us to a broad diverse set of sources, you should vote with them. But if you agree with me that we should scrutinize that, and that these commercial interests will tend to use that power to placate people rather than exposing them to more broad senses of view, then you should vote that the internet has in fact, unfortunately, been closing our minds.

### Moderator
Claim: Thank you Eli Pariser. This is our motion. "When it comes to politics, the internet is closing our minds." And here to summarize his position against the motion, Evgeny Morozov, author of The Net Delusion, visiting scholar at Stanford and Schwartz Fellow at the New America Foundation.

### Scientific Advocate (SA)
Claim: Well I wish that Don Draper had a chance to respond to that 1997 paper from Google. Again, you may think that advertising is evil, but again, advertising is the kind of evil that’s also inevitable. So Eli has mostly avoided the what’s to be done question. In his book, he actually is much more I think straightforward. And he does want Google and Facebook to intervene and to expose us to more diverse information. More diverse information diet even, that you are normally up for. This second attempt is an utopian dream that is not realizable in practice. Do we really want Facebook and Google to start nudging us to pay more attention to Joseph Kony in Uganda when we are searching for information about our local city council? Okay, but then why pay more attention to Joseph Kony and say not climate change, or Syria? Who will adjudicate here? Do we really think that Silicon Valley is capable of this? Do we really think Silicon Valley should be in this business?

Again, you have to think about the proposed solution. Often they’re worse than the cure. Don’t forget, that in 1995, in that article in The Nation, Andrew Shapiro proposed that the government should re-nationalize the internet, to bring it back to avoid all that advertising evil that you’ve just alluded to. Cass Sunstein in his book, wanted to force, by government, bloggers to link to their ideological opponents. He wanted them, conservatives to link to liberals, and liberals to link to conservatives. All of those ideas now seem very ridiculous. And that’s what I think we will think about the idea that Google and Facebook should be in the business of actually preserving us and presenting us with a more diverse information diet. Information is not like food. Politics is not like food. Diversity here is a very political matter that will not be settled very easily. Ideological conflict here is inevitable and I think this is why you should vote against this proposition.

The sooner we do it, the sooner we can start attacking more important threats like privacy.

### Moderator
Claim: Thank you Evgeny Morozov. Our motion is "When it comes to politics, the internet is closing our minds." And here to summarize his position for the motion, Siva Vaidhyanathan, chair of the University of Virginia's department of media studies and author of the Googlization of everything.

### Conspiracy Advocate (CA)
Claim: Evgeny has just done a great job to convince me that there is no virtue in the arguments made by people who are not me and not Eli and not made during this debate. We have not advocated a government takeover of anything. We have not advocated any Cass Sunstein-type intervention. We merely want you to be aware of the problem and correct for it. Jacob said, what if we had a world without the web? What if we had the world without the web? We might get there. Let me tell you why, because Facebook and Google and Microsoft and Apple all wish to be the operating systems of our lives. They're explicit about this.

They don't just want to be on the web because the web is 20 years old, and it's actually kind of creaky. What they want to do is be there with you all the time in your glasses, in your pocket, in your purse and on your mind always. They want to be your personal assistant. There's quote after quote after quote from every CEO of every one of these companies that that's what they want. And it might make things really cool for us. But it's not going to make things rich and diverse. It's not going to be the wonderful conversation that we could have had on the web if we hadn't instigated these gated communities, these operating systems of our lives. We're on the way to having a Balkanized world and a Balkanized society because of these gated communities. The fact is, nothing is determined here. We can decide that we like what the web was supposed to be. We can opt out of certain of these practices. We should encourage diversity, encourage other platforms. We should encourage experimentation. We should recognize that Facebook and Google and Yahoo! and Bing and Apple and Microsoft are designed to gratify us immediately.

And that's great for pizza, but it's not for politics. Thank you very much. Please vote for the resolution.

### Moderator
Claim: Thank you. And that concludes our closing statements. And now it is time to learn which side you believe has argued best. We're going to ask you again to go to those key pads at your seat that will register your vote on which side you feel presented the stronger argument tonight. And we will get the readout pretty much immediately. Press one if you support the motion that when it comes to politics, the internet is closing our minds. Press number two if you are against this motion. And press number three if you remain or became undecided. And you can correct your vote if you think you pressed the wrong button, and it will be locked in right away. And we'll have the results in about 90 seconds. So first, I want to ask-- I want to ask for a round of applause for our debaters, for the quality of-- of the arguments that they brought here tonight.

It was witty, and it was informative, and it went places. Thank you very much to them. Thank you also to everyone in the audience who had the guts to stand up and ask a question and to all the people who I didn't get to answer-- to ask questions, I wasn't able to allow to ask questions, thank you, very much for your contribution to those as well. So going forward, I just want to let you know that our next debate is in May. It's our last debate of the season. And our motion comes down to three words, "Ban college football." And we had actually set this debate up quite a while back. It has-- it was not in relation to the Penn State scandal. It was actually motivated more by reporting that was done about the business side of college football and the sometimes harsh nature of the sport on the bodies of the athletes who play it. So our debaters will include somebody who wrote one of those articles, Malcolm Gladwell, who is author of "The Tipping Point," and "Blink," and he will be on the panel arguing for the motion.

And he wrote the piece in the New Yorker in which he compares college football to dog fighting. His partner will be Buzz Bissinger. He is the Pulitzer prize-winning journalist and author of Friday Night Lights. That served as the inspiration for a movie of the same name and a critically acclaimed television series also of the same name. Opposing them, we have a football player, Tim Green. He is the former Atlanta falcons NFL defensive end, and Syracuse University all American. He was inducted into the college football hall of fame in 2002. And his partner also debating against the motion, Jason Whitlock. He is Foxsports.com’s national columnist, and he's already as an offensive tackle at Ball State University. So that's our last debate. That's on May 17th. And we would love to see you there. Also we're trying something new tonight after the debate. Any of you want to join us, we are partnering with the New American Tavern to host a post debate reception that will be upstairs at Amity Hall.

That's a block away from here on Third Street between Thompson and Sullivan. Details are in the programs that you have. But our idea was that we noticed a lot of times people walk out of here still kind of energized and revisiting the issues and debating among yourselves. We wanted to give you a place to do it and get together. And to share your ideas across the partisan divide. So that'll be at Amity Hall, $5 beer and well drinks. And I will be there for a bit as well along with other members of the Intelligence Squared staff. And finally, you are encouraged to Tweet about this debate. Our Twitter handle is @IQ2US. And the hash tag is IQ2US. So we'll just wait about-- it's ready already. Thank you. All right. So the results are all in. Our motion is this: "When it comes to politics, the internet is closing our minds." You have heard the arguments for and against over the course of this debate. We ask you to vote before and again afterwards where you stand on this and how persuasive the teams were.

Here are the results. Before the debate, 28 percent voted for the motion. 37 percent against and 35 percent were undecided. After the debate, 53 percent are for the motion. That is up 25 percent. 36 percent are against it. That is down 1 percent. We have 11 percent undecided. The motion, when it comes to politics, the internet is closing our minds has carried. Our congratulations to that team. Thank you for me, John Donvan and Intelligence Squared U.S.
