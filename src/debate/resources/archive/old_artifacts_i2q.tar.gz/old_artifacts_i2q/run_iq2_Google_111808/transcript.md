# Debate Transcript

Topic: Google Violates its Don't Be Evil Motto
Motion: Google Violates its Don't Be Evil Motto

Debate ID: Google-111808


## Round 1

### Moderator
Claim: Hello, everyone. Welcome to our fourth Intelligence Squared US debate of the season, I’m John Donvan, your moderator, and I just want to give you a preliminary introduction. We’ll be doing a more formal introduction once the program begins… At this point our debaters and panelists are coming to the stage, I’d just like to welcome them with a round of applause. And I would further like to introduce the CEO of Intelligence Squared US, Mr. Robert Rosenkranz.

### Moderator
Claim: Greetings, welcome, thanks for being here. As is typical on these occasions I try to frame the evening’s debate. And when you think about Google, I mean here’s a company that was founded by two Stanford University graduate students just about 10 years ago. One of them was an immigrant to this country. They’ve created among them an enterprise that is basically the first place that almost everybody goes for information about anything, it’s an extraordinary achievement. They’ve completely revolutionized the advertising industry by enabling advertisers to very efficiently reach the individuals they want to reach that are interested in their products… and it’s the amounts— the sums that are paid by the advertisers that make these services possible for everybody else as well as having created enormous fortunes for the founders of the company and their shareholders.

They’ve created a unique corporate culture, a corporate culture that is highly entrepreneurial, very inventive, embraces change, I mean it’s an American dream kind of company. So, what’s the debate, where’s the other side of this equation. It comes in a number of categories, the first I would say is privacy. Google is so ubiquitous, if you put your telephone number in that little box, it comes up with your name and address. If you put your address in Google maps, it can show you a photograph of people going in and out of your building. If you’ve ever made a political contribution, it’s on Google. Virtually every detail of anything you’ve ever published, everything that’s ever been in print about you is part of a permanent record that can be accessed on Google.

So, this sense of pervasiveness, the sense that Google knows so much about all of us, is worrisome to people, and with good reason. And then there are other issues involving personal freedom and you see that mostly in China, at least in terms of the news, where Google has been cooperating with the Chinese government in censorship of the Internet and maybe in other ways that we don’t know about, so we think this is a motion where there’s a lot to be said on both sides, we have an outstanding panel, and it’s my pleasure to turn the evening over to John Donvan.

### Moderator
Claim: Thank you, Robert, may I invite one more round of applause for Mr. Rosenkranz. Ladies and gentlemen, welcome to an Intelligence Squared US, Oxford-style debating, live from the Caspary Auditorium at the Rockefeller University. The motion before us tonight is, “Google Violates it’s ‘Don’t Be Evil’ Motto.” We will be hearing from two teams of three panelists each in debate. This debate will take place in three parts. There will be opening statements, followed by a round of direct debate among the panelists and that will also include questions from you the audience, and then we will have a brief period of summing up by each of the debaters. In the opening round they are each given seven minutes, and we will have a warning sound for each panelist as they approach minute six…it will sound like this— Clear? And at seven minutes, if the speaker has not finished speaking, it will sound like this. And on, and on… and on it will go.

This is a contest, it’s a contest of wit and logic and ideas and persuasion, and you the audience are the prize in that contest, you are the judges and your votes will determine who is the winner of the evening, and to that end we’re asking all of you at this point, to express your point of view on the motion now, before having heard any of the actual debate and argument. You each have the keypad at your seat, if you agree with the motion that “Google Violates its ‘Don’t Do Evil’ Motto,” press button number 1, if you disagree press button number 2, and if you are undecided, press button number 3. I’ll be sharing those results in a short time after we hear the opening round completed. Is everybody— Anybody need more time? All right. Restating once again…this Intelligence Squared US debate, our fourth debate in the series, the premise is, the motion is that “Google Violates its ‘Don’t Do Evil’ Motto,” and you may have noticed that Google itself is not represented on our panel tonight, suffice to say that, the company was made aware of this debate, and was invited to participate. Now, let’s let the debating begin, we’re going first to argue for the motion, Randal Picker, a professor of commercial law at the University of Chicago Law School, and a senior fellow at the Computation Institute of the University of Chicago, ladies and gentlemen, Randal Picker.

### Conspiracy Advocate (CA)
Claim: Thank you very much. I want to thank Intelligence Squared and the Rosenkranz Foundation for organizing what I think will be a fun and lively evening. So, the resolution before us is that “Google Violates its ‘Don’t Do Evil’ Motto,” I think it’s important for us to frame that and understand what that means and what it doesn’t mean. The question isn’t whether Google is a great company. I think it is. I thought what Bob Rosenkranz said about it is exactly right, much to admire. The question isn’t whether Google does more good than evil. I think it does. That’s not the question either.

The question’s whether we can identify certain things which they do which we think are important to how Google operates, that are inconsistent with that motto. And I think we can. So we should start where that motto comes from. When Google was going to become a public company it filed its registration statement, if you haven’t read those, they’re remarkably dull. Not Google’s. Google opens with an owner’s manual for future Google shareholders. Page and Brin say, we’re not an ordinary company, we’re not gonna be an ordinary company. Get ready for the ride. Okay. Part of that is Google says, we’re gonna live by a motto, and that model is, is we’re not gonna be evil. Seemingly asking us to hold Google to a higher standard, they’re very clear. There’ll be times when they will sacrifice the short- run interests of Google for the public good. I don’t think what’s legal is the standard to evaluate for Google, Google asks us for something much more public-interested.

Google then compares itself to newspapers. Well that’s interesting, right, they seem to be on diverging paths but I think they thought there was some sense of a public trust associated with newspapers, and we should hold Google to that as well. That’s what we’re gonna try to do tonight. My piece of this is I’m going to focus on the heart of Google’s business which is their advertising model. And I’m going to focus on the recent deal that was proposed between Google and Yahoo, where Yahoo was going to out-source a large chunk of its search-ad business to Google. I should say I consulted in connection with the opposition, so you can discount what I say as you wish. I should say we won, that’s good news, because that deal has gone away, the Department of Justice suggested that they were going to challenge the deal in court…that was something clearly Google didn’t want so they backed away from it.

All right. Advertisers were opposed to the deal. Why were advertisers opposed. Advertisers believed that the deal and the core of the deal was if you think of search queries, there’s a lot of common queries, there’s a lot of unusual queries. The deal is going to out-source the long tail as it were, Chris Anderson’s term of queries, away from Yahoo to Google. Advertisers were upset about that. Why. Well, advertisers believed that prices were going to go up because of that. Google’s response to that was to say…we run auctions. We don’t set prices. Advertisers set prices. We’re just middlemen. That’s not right, and I think Google knows better. I should say, I’m a Google Ad Words advertiser, so if you’ve not looked at the system, the way it works, you can set an account up very easily, pay five dollars to do so… I’m advertising, I thought I should understand how Ad Words works, so I’m advertising a paper that I wrote on anti-trust and privacy and cloud computing. I’m not sure who the second click has been, um— Okay. But you see how that works. You can click, and go. But the nature of this is that you bid on keyword terms, if you win the auction your ads are supposed to show up. Now Google understands that how you design auctions matters, there’s a whole field of economics devoted to that. They gave William Vickery from Columbia a Nobel Prize for that. Google is designing its auctions in a way that takes advantage of its market power. Does that in three important ways. First, Google runs a system involving minimum bids. So cloud neutrality is one of the terms that I’m bidding on. You can run a search on cloud neutrality, I did yesterday.

I know my ad is out there. It didn’t show up, indeed no ads showed up, and indeed if you look at the statistics, 50 percent of the time when you run a search on Google, and they produce results, the organic search results, there are no ads next to it. Even though if you believe the comments, and as I say I’m one of these Ad Words ad—Ad Words advertisers, my ad is out there waiting to be served and even though the search that has been done, if they don’t run an ad it’s an opportunity to show an ad which is lost forever. So there was a chance for Google to get money there and yet they’re not doing it. Why, because if very few people are bidding then I ought to be able to buy it for a very low price and Google’s interest is not served by that.

Google wants to make sure that there’s a high enough minimum, they’ve been raising the minimums over time, such that Google meaningfully makes money on that. If you look at the blogs, people comment on this, they talk about bidding against the house, that’s what they have to do. And Google has changed the terms in which they do that. Okay? That’s an exercise in market power. I should say under current US anti-trust law one of the things I do for a living, I don’t think that’s illegal. Evil? Well, that’s the resolution for the house tonight. That’s one. Two. If you’re an auctioneer, the way you exercise market power, is you control the number of slots. Right, you don’t control prices, you control quantities. In Google’s case that means how many slots are available on the right-and side next to the organic search results. Google controls that. Now you might think in a competitive model that we’d have some relationship between the number of ads on Yahoo and the number of ads on Google.

Indeed the central premise of the Yahoo-Google deal was that Google does a better job of ad matching than Yahoo does. We should therefore expect Google to have more ads than Yahoo, just the opposite. Again, market power being exercised, not illegal, evil, you decide. Finally, third point. Google engages in a kind of bundling, so Google also organizes search for Ask and AOL. You can buy Google alone, you can’t buy Ask and AOL alone. They are bundled together with Google.

Right, advertisers would like to be able to advertise separately on those. Can’t do it, they won’t let you do that. Illegal under US law, EU law? Maybe, we’ll see. Right? Evil, mmm, I think you can conclude. Now, why should we care about this. The importance of advertising is the way that advertising supports paid content. Right? You should care a lot about the kind of content that’s out there, and to the extent that the middleman is making it more expensive for people to reach consumers, we’re going to have less content because producers are effectively going to get a lower chunk of the advertising dollars. I’ll stop there, thank you.

### Moderator
Claim: Thank you, Randy Picker. Our next speaker speaking against the motion in this US Intelligence Squared debate, Jim Harper, who…though arguing on this side is not somebody unconcerned about privacy, in fact when he was a consultant for the Department of Homeland Security he argued vociferously against the introduction of a national identity card on privacy grounds, as director of Information Policy Studios at the Cato Institute, he is our second speaker, speaking against the motion that “Google Violates its ‘Don’t Do Evil’ Motto.” Jim Harper.

### Scientific Advocate (SA)
Claim: Ladies and gentlemen, it takes a lawyer to know a lawyer. And as a lawyer I want to point out what my colleague just did at the beginning of his talk, he redefined the question. The question tonight is whether “Google Violates its ‘Don’t Do Evil’ Motto.” The question is whether Google is evil or not. And that’s what I want to talk to you about, and I want to urge you to vote no on the resolution. To find that Google is evil, you have to find that people who cut in line are evil. You have to find that, bruised apples are evil. You have to find that flat tires are evil. These things are not evil. Evil is Hitler. Evil is Stalin. Evil is Pol Pot. Evil is…Dr. Evil. That’s somewhat definitional. Google is not evil. Now you have to make some sense of the term to understand these concepts, now...perhaps that phrase was intended in a sort of, “Let’s not be a greasy corporation” sense. Even by that standard, Google is not evil, Google is great. Google brings information and empowerment to the masses in ways we couldn’t have imagined just a few years ago. Try it now. Think about how you would you have found out information just a few years ago. It’s a little hard to remember for oldsters like me, but it was very hard. Today it’s much easier. Now there are lots of complaints about Google. Holders of copyrights, say Google’s making use of my copyrights and my property and da- da. In fact Google’s making that material more available and more valuable for copyright holders. Holders of trademarks complain precisely because Google is using trademarks in an appropriate way, in Ad Sense, allowing providers to compare their products with other products, bringing consumers lower prices, better products… This is good, this is not evil.

Now surely Google should avoid censorship. And one of the toughest areas is the question of censorship. But the Chinese people are better off, with Google in China, slow-wokking their cooperation with the Chinese government, than having no Google in China, and leaving China to Baidu, and whatever local information sources are fully government-approved. On the question of privacy it’s true, that Gmail, Basic Search, Maps, Street View, all of these things, challenge privacy. All of these things are challenges to privacy, but no more than any other apps that are available similarly. This is not a case that Google is evil, perhaps it’s a case that the Internet is evil. But I don’t think anybody here thinks of the Internet as truly evil. Now, some say that Google’s monopoly on search, gives it so much power that this is inherently, somehow evil.

Well, Google has a sizable percentage of the search market. I think that’s an admission I can make. But Google is a big company, that’s part of an information big bang, that’s far bigger. Google cannot control us finding out about things. Google cannot prevent criticisms of Google being made. Google’s a big player, but the market is much, much bigger than Google. There’s a more concerning evil, that I want to point you to, and I know none of you indulge this. But some people, who have problems with the way products and services are delivered, do nothing but complain. That’s the evil of apathy. If my colleagues at the far end of the table wish to characterize Google as evil, they should foreswear the use of Google products, and find the other products, which there are, and use those instead. Google’s not evil. In fact… Google’s not evil, Google’s Evel Knievel. Google’s high-flying…Google makes some mistakes. But Google is an American success story. Let me urge you once again, to vote no on the proposition. Thank you.

### Moderator
Claim: Thank you, Jim Harper. Arguing next for the motion, Harry Lewis, a professor of computer science in the School of Engineering and Applied Sciences at Harvard University, who has something to disclose… Though he’s arguing this side of the motion, his daughter is actually a Google employee. Harry Lewis.

### Conspiracy Advocate (CA)
Claim: Thank you. Thank you all for being here tonight, what a great audience, I have a very simple way of stating my case for the motion. And it’s a conclusion that’s based on some facts, facts are good, so here are a few facts. If you Google “Tibetan independence,” you’ll get back pointers to some sites, that advocate the freedom of Tibet from Chinese rule. Tibet.org, Friends of Tibet.org, sites associated with the Dalai Lama, and others. You’ll also get back some sites, that advocate against the freedom of Tibet from Chinese rule. That’s if you go home tonight, and use the version of Google that you have available to you in this country. But if you do it inside China, you won’t get references to Tibet.org, or Friends of Tibet.org, except perhaps, for references, to sites explaining that those are illegal and banned organizations. Or Epic Times, Epic Times is a Chinese newspaper, an uncensored Chinese newspaper. You can find it on the Internet, just Google Epic Times. But try to do that in China, and you will not find your way to Epic Times. Same thing with human rights if you Google that, or various spiritual practices. The world looks very different through the window that Google provides, in China, than through the window on the world that you have available to yourselves here. In fact, it’s not the picture window on the world, it’s a distorted lens that has been built, custom-built by Google to Chinese specifications.

Now how did that happen. Google is the company, whose mission is to organize the world’s information, and to make it universally accessible and useful. How did it come to be in the business of creating the distorting lens, rather than the picture window on the world. Well, in 2004, Google was entering the international market, it wanted to be the number-one search engine in the world, it started to do business in China. And the Chinese said, we don’t want you to show our citizens the world as it really is, with all of its complexities, and its contradictions, and its inconsistent sources of information. We want the Chinese citizens to know the world the way we want them to know the world. And, Google said, okay, we’ll give them that world instead of the world as it really is.

Their choice was, to accept the Chinese ultimatum, or to go home. They could’ve gone home, they didn’t, they stayed, and built the engine as the Chinese wanted it. Now it’s a wonderful product. I agree with everything that’s been said about what a wonderful product it is and what a wonderful company it is. But here it’s been turned from a wonderful product, that we know, into an instrument of thought control. Now some may weakly claim that it’s doing more good than harm… that the Chinese people are better off getting partial information via the Google search window than getting no information at all. That’s nonsense, there are other search warrants, through which you can get the censored truth, if that’s what you want people to provide. Google didn’t choose the lesser of two evils when faced with the Chinese ultimatum; it chose the more profitable of the two evils.

And for that reason, you should vote for the proposition, that Google is violating its “Don’t be evil” motto. They had a simple choice that was put before them. I stopped a street vendor here in New York last week, who was selling Tibetan jewelry, he’s a Tibetan. And I said, I’m gonna debate this issue. What do you think the answer is, I don’t have to explain it to him, he knew exactly that Google works differently inside China, than it does here. And here is what he said—he said, Google had a choice between morality and money, and it chose money. That’s why Google is violating its ‘Don’t be evil’ motto. It’s a company that does many good works. It’s true that Google as a whole is not evil, I’ll grant that, but that’s not the question before us. If the question before us was, Google is evil, that’s what the question would be.

That isn’t the question, the question is, does it violate what it claims not to do—not being evil. A good indicator that you’re doing something wrong is that the Congress hauls your executives, in front of them, and yells at you. And Congress has gotten into the habit of doing this several times. Most recently in May. Senator Richard Durbin confronted Google executives on this censorship question, and said, “When you’re asked to be complicit in restricting the flow of information, aren’t your hands a little dirty at the end of the day if you participate in that.” There is legislation under consideration, to prohibit exactly what Google is doing. Now to be sure, Google is in the business to make money, if it doesn’t sell advertising anywhere, then it’s not going to make money, but it’s making plenty of money. And it would have been such a statement, to the international world about the importance of, of information freedom.

My friends, you are here tonight, because you value the robust debate of conflicting ideas. You value facts, you believe the truth is revealed, through this kind of debate and conflict. You should—you must vote for this proposition, if you support the idea that creating censorship tools is a form of evil. Finally, just let me close with one analogy. Suppose Google were not a search engine company, but a pharmaceutical company. And it was told by the Chinese government that it could sell aspirin in China, only if it also made certain forms of brainwashing drugs and thought control medications. And that was the condition on which it could sell aspirin in China. No responsible American company would make that deal with the Chinese authorities, and that is exactly what Google is doing in the digital realm. So, please vote for the motion, “Google Violates its ‘Don’t Do Evil’ Motto”, because they do. Thank you.

Uh, not my daughter—

### Moderator
Claim: But not your daughter.

### Conspiracy Advocate (CA)
Claim: Uh, not my daughter—

### Moderator
Claim: No, okay. Just a reminder as we’re now halfway through our opening statements, I’m John Donvan, your host and moderator, and this Intelligence Squared US debate, we’re halfway through opening statements. You have heard from three panelists, and we’re moving on to our next three. And speaking next against the motion that “Google Violates its ‘Don’t Do Evil’ Motto,” Esther Dyson, who also has some things to disclose but having met her earlier, I know she’ll do it far better than I will. I’ll only share the fact that among all of your other activities as an investor in various Internet enterprises, you’re also currently, frequently visiting Russia because you are in training to be a cosmonaut.

### Scientific Advocate (SA)
Claim: Yes. Uh— So I was going to start by saying that I actually spend a fair amount of time with things I consider evil. And I mean that quite seriously, the old Soviet system, which, you still see some vestiges of, in Star City where I’m training. I travel a lot, I’ve seen many ways to be evil, I’ve examined governments, I’ve talked to people who… I’m on the board of the National Endowment for Democracy, and we give grants to dissidents, so, that informs my thinking, as does the fact that I was chairman of ICANN, which is the organization that sets policy for the Internet. We made a lot of mistakes, I don’t think we were evil but we probably came a lot closer to it than Google ever did, or will. But finally in terms of the disclosures you probably want to know, I’m on the board of 23andMe which was founded, cofounded by Sergey Brin’s wife.

I’m on the board of WPP Group, which calls Google its frenemy, or its froe. They’re a large advertising conglomerate. And finally, I’m on the board of Yandex, which competes with Google in Russia where, Yandex has 60 percent market share and Google has approximately 20. So I kind of come at this from many different points of view. And, I believe that Google does not violate it’s “Don’t be evil” motto because I’ve seen it up close, I’ve also seen it from outside, I’ve seen it as a competitor, I’ve seen how they try to do things. And I am very glad to hear all this discussion of China because I’m going to blow it to bits in a few moments. But first I want to go through the few…the couple of arguments I wanted to talk about.

The challenge of power, is great. The great virtue of the Internet is that it erodes power, it sucks power out of the center, and takes it to the periphery, it erodes the power of institutions over people, while giving to individuals the power to run their own lives. Google is part of that. It’s one of these things that shines light on everything, it enables people to find stuff out, it enables them to question what their governments are doing, and it’s absolutely wonderful. That doesn’t mean that power cannot be abused. The abuse of power is absolutely evil. Google to some extent understands this very well, that’s why they bothered to have this motto in the first place, they understand the danger of concentration of power, and they understand how important it is not to be evil, that’s why they have shareholder agreements that give them more power so that they don’t need to cater only to money-hungry investors but can also do what they think is right. There are three people who set policies there, it’s the two founders and Eric Schmidt. And they watch one another, they’re very careful not to abuse this “Don’t be evil” thing.

Now, the power that Google has is primarily a good power though it could be used to do evil, it’s not like atom bombs. It’s not like guns…or even cigarettes, which when used correctly are destructive. The power of transparency, the power of knowledge, is fundamentally good, even though it can on occasion be used for bad. And so Google’s trust is to ensure that that power is used for good as much as possible. I have seen what they’re doing in China. And ladies and gentlemen, the reason they’re not violating their “Don’t be evil” policy is because they’re in there, and they’re engaged. Yes, they could abdicate, they could say we’re not gonna bother to go into China. But every time some Chinese person uses Google, and doesn’t get what he wants, he may notice, he may not even notice the absence, but he does know that he can go find out all the negative information on George Bush he wants.

And at some point, he or she says, well, gee. If I can get—or whatever the Chinese version is—if I can get this bad information about George Bush why can’t I find out more about what’s going on in my own country. Google by its very presence and its operation, even if it’s incomplete, creates increasing expectations for transparency, it starts people answering questions. It gets them to expect to be able to find out stuff. And it knows that by doing that, people are going to start asking more questions. So I think Google was doing the right thing, by going into China. I don’t think they’re making that much money there, if they are that’s fine too. But the point of it is, they are engaging. I know another example, in which they’re getting engaged. They have a service, you’ve probably encountered it, where if you go to a website—if you get a search result that indicates a website that may have some malware on it, they warn you off.

This is very expensive for them to do. They need to detect the sites with malware, they need to inform them that there’s malware. They have a dispute-resolution process, they’re not perfect, but again, they’re engaging where they didn’t need to. They could easily have just passed the query through. But they’re trying to make the world a better place, by doing something that requires them to make judgments. Sometimes they may incorrectly flag a site as having malware, sometimes, somebody has malware unintentionally, they need to deal with it. So the point here again is that rather than just being apathetic, as Jim said, they’re engaging, and trying to make the world a better place. So I believe, that they do not violate their motto and I think you should vote against the proposition. Thank you.

### Moderator
Claim: Thank you, Esther Dyson. Our next speaker runs a blog, the name of which will tell you a great deal. It is…Googlization of Everything.com. Siva Vaidhyanathan is Associate Professor of Media Studies and Law at the University of Virginia, and he is also turning his blog ultimately into a book, the kind of book that depends on paper and dead trees…I assume. Siva, the floor is yours.

### Conspiracy Advocate (CA)
Claim: Thank you very much. To my distinguished opponents, I see your Dr. Evil and your Dr. Pol Pot, and I raise you a pope and a poet. Specifically, Pope Gregory the Great, and the great poet Dante Alighieri. Because after all, one of the things we have to figure out here, is what do we mean by evil. Well Google encourages us to think algorithmically, after all it’s built everything that it has on algorithms. One of the simplest forms of algorithms, the if-then statement, or if you prefer, the checklist, Dante offers us such a checklist in The Divine Comedy. I know you know it, I know you know it with me, so say it along with me, the seven deadly sins, luxuria, gula, avaritia, acedia, ira, invidia, and superbia, right? Well, okay, you didn’t say it along with me. To walk through, I can show you that Google has at times committed every single one of these seven deadly sins. The first, luxuria, which translates as extravagance or lust. I spent a bit of time on the Google campus out in California…they get massages. Right, the people who work there get massages. That is, that is corporeal lust of the highest order. Or at least for a bunch of geeks about the best they’re gonna do. Um… Number two, gula or gluttony, the other thing about the Google campus is they get incredible food, all they can eat all day, no matter what they want, there is so much food that they never need to say no, that is the very definition of gluttony. Number three. Avaritia, greed. We’ve already heard from Randy about the greed embodied in the Google-Yahoo advertising deal…that is one of many examples of Google overreaching to corner a market, or completely undermine a market, in an effort to maximize its returns. Number four, acedia, sloth. Now I could talk about how lazy and self-satisfied Google was in its effort to roll out an on- line video service. The early days of Google Video were very much a matter of figuring they owned the video realm and they weren’t actually gonna do anything new or fantastic until these whippersnappers at YouTube came across with their Flash video platform, and basically ran around them to the point where they ended up having to buy that company just to keep pace.

But there’s actually a better example of sloth and that is Google itself, its very nature, its very model of advertising is based on free-riding. Google makes money off of our work. We blog, we put our skate—our cats on skateboards and record them for videos. We do all of this work, and then Google harvests our work, runs all of this content through this computers, spits it back out at us, with almost no actual value added and what we end up getting is a tremendous amount of money, based on free- riding, the very definition of sloth. Wrath, ira, wrath. There are a number of high-profile cases of people who have been involved with Google through their Ad Sense program, through which they’ve agreed to place ads on their own blogs. I think Jeff is one of these people but not one who has suffered the wrath of Google. Many of these people have found their accounts shut down, their revenues stopped, for reasons that can never be explained, but they did something to violate Google’s policies. But they get no feedback and no response, and no justice.

And then there are hundreds of small companies all around America, that have found their ranks decimated, their Google ranks decline significantly, because again, they tried to optimize their results, they were just doing what a company should do, trying to get more attention for themselves. And Google’s algorithms, its faceless, soulless algorithms came at them with wrath, another of the seven deadly sins. Invidia, envy. Google has over the last few years engaged in a series of efforts to try to muscle in on the markets of other successful companies, Microsoft being the most prominent.

Google has recently tried to push its suite of services that directly compete with Microsoft Office. Of course they have at various times threatened to muscle out eBay, muscle out PayPal, muscle out Amazon, in various ways. Number seven, the one I want to talk about the most, superbia, pride, or hubris. Now, let me remind you of the actual motto of the company, it’s not “Do no evil” or “Don’t be evil,” it’s actually, “To organize the world’s information to make it universally accessible.” What could be more hubristic than that. What could be more prideful than that. General Motors doesn’t say we’re gonna organize all the places in the country and make them universally accessible. General Motors says we’re gonna try to sell cars. Not that that’s the best example to use this week, I understand. Nonetheless, no company besides Google would ever come up with a motto or a mission statement like that, but let me tell you something that Sergey Brin, one of the founders of Google said a number of years ago, during an interview when someone asked him, what would the perfect search engine be like.

And he said, without missing a beat, it would be like the mind of God. Ladies and gentlemen, that’s more than hubris, that’s blasphemy. Now the particular kind of hubris that energizes Google is of course, a sense of techno-fundamentalism. The notion that you can always invent something, to solve the problem that the last invention created. And that faith in technology, that technology can cover all of our sins and all of our faults and fix all of our problems, is again the ultimate hubris, it’s the hubris expressed in the myth of Pandora for instance, the myth of having too much knowledge. There are so many examples in human history in which techno- fundamentalism has led to great suffering. Not that Google is about to lead us to great suffering, but they’re still committing the sin of hubris.

Now hubris is actually the most serious of the seven deadly sins. As Dante explains to us, it was the sin that Lucifer committed. Lucifer was a good guy. Lucifer fell, because he thought he could be as effective as God, as good as God, and thus, he became Satan. The very notion of the “Don’t be evil” motto, is itself hubristic, is itself, evil, because it is itself a violation of the seven deadly sins. One real-world example, let me finish with very quickly, Google Book Search. Google has been trying to scan in 36 million books from libraries around the world, in an effort to essentially corner the market on digital book access, for a number of years. Early on, four years ago when it started this project or got public with this project, it claimed that everything was cool as far as copyright was concerned. In other words, copyright only applies to mere mortals, not to superhuman supercompanies like Google. Well, it turns out Google wasn’t right about that, last month Google ended up having to settle, and wrote a check for $125 million to publishers and authors because it turns out, they weren’t quite as on the ball about copyright as they thought. Thank you very much.

That’s blasphemy!

### Moderator
Claim: Thank you, Siva Vaidhyanathan. Our final speaker against the motion, Jeff Jarvis, has had a foot in what we call the legacy media as a cofounding editor of Entertainment Weekly magazine, he was also a TV critic for TV Guide and for People. But of late he has been very much of the blogosphere with a blog called Buzz Machine.com and he also teaches interactive journalism at the City University of New York’s Graduate School of Journalism. Jeff Jarvis.

### Scientific Advocate (SA)
Claim: And I guess in both full disclosure and a plug I should say I have a book coming out called, What Would Google Do?

### Conspiracy Advocate (CA)
Claim: That’s blasphemy!

### Scientific Advocate (SA)
Claim: You're just jealous. Massage would feel good right now, wouldn't it? We should remember where this pledge came from. The chiefs of Google have said that the real purpose of the “Don’t Be Evil” pledge is to give employees the license to remind their bosses of this in meetings. So, a geek can stand there and say, is that evil? The kind of thing a geek would say. And it’s, it’s useful. Imagine, ladies and gentleman, if we had that phrase, “don’t be evil,” chiseled over every door on Wall Street. Would we not have a better world today? In this poisoned process that led to the financial crisis, if just one, or two, or five, or ten people had said, Hmm… taking poison mortgages, or giving them, is that evil? Creating poison assets and selling them, is that evil? So, I think it’s important to just recognize that the rule itself is good. The fact that Google asks it is good. And we should wish that it shouldn't be special subject of a debate that a company promises not to be evil. The fact that it’s special is, itself, a virtue. So, I would like to match the seven deadly sins with eight, I’ll beat you, virtues of Google. And let’s remember that virtue does leaven evil. We all mess up, right? So virtue matters. So number one, Google has opened up, as my colleagues have said, the world’s knowledge to the world, or stipulate China, most of the world’s knowledge to most of the world. And that’s important. It has changed our very view of facts and knowledge and accuracy. No longer do we end an argument saying, I don’t know. We go to Google. Google will tell us. And it will tell us that in a blink of an eye. Now, in fact, I went to Google, and I asked Google how fast does an eye blink. And it told me in point three seconds that an eye blinks in point three seconds. Your life is richer now because of Google. Number two, Google respects the wisdom of the crowd. We are too often not respected. There’s a snobbishness about my old colleagues in big old media. Google doesn't have that. Google learns what it learns because it trusts us. Isn't that nice? Shouldn't companies do that? Shouldn't politicians do that? Wouldn't trust matter? Google in its very essence trusts us. Number three, Google takes the wisdom of the crowd, it knows we have wisdom, and it gives it back to us. It gives us our own knowledge. Look at the Google flu trends search. It lets us know how often we search for a flu, and how the flu trend is coming. That is our knowledge, not Google’s. Google shares our own knowledge with us, it gives it back, it does add value, if not flaming cat videos, to our own wisdom. Google connects people. This is so important. We often are accused on line of being anti-social. I think we’ve become hyper-social. I think we’re more connected. I met Esther and Siva because of Google, because of searches. I looked at Google, and there’s Siva on the other side. And so I think the importance of Google connecting people cannot be underestimated. Our children today connect in ways across cultures we don’t even know, yes sometimes it makes us nervous, but I think that it can only be good. Admit it, how many of you have searched Google for an old girlfriend or boyfriend? Aw, come on, you liars. Now, part of the problem is, I can say this because I have gray hair, that probably, the probability of finding someone is inversely proportional to your age. But young people will stay connected to their friends for the rest of their lives. Imagine the impact that will have on friendship and society, and Google is the mechanism that makes that happen. Five, Google creates platforms, it is a platform that enables us to create. A recent poll said eighty percent of Americans think they have a book in them. We should be glad that most don’t come out. But we have seen in Google that it is an age of creation, and Google creates the platforms, the tools to let us create, the means to let us pay for that. I think that’s very, very important. Six, Google does have ads. Last year I made a big four thousand, five hundred dollars on Google ads. I shouldn't quit the day job, I know. But, if you want to compare, my dear colleagues on the other side, the view of Google toward its advertising structure, compare it to a monopoly newspaper, which set the price, which set its own rules, which allowed you to only do so many things with their space, well, no, we can do what we want with our ads. We can start whole businesses with it. We can create movements with it. We can be found with it. That’s important. And I believe that Google ads will help support the future even of news. Seven, Google.org, the foundation started by Google, is supported by one percent of the equity, and one percent of the profits of the company. And it is trying to solve, with hubris, the problem of energy and global warming in one fell swoop. But I’ve learned that they're doing it in a unique techno-smart way, the way engineers do. Engineers solve problems. We have a problem, they're looking for the solution. Politicians are trying to get us on energy with regulation and taxes and prohibitions and slaps on the wrist. Google is giving this investment, and innovation, and invention. And if it can solve the problem of power cheaper than coal, then we don’t have to save anymore, we can use as much as we want. Google understands abundance. Finally, eight, Google has a new model on how to treat employees. We get, they get, massages. Finally, I want to say that Google teaches us to understand our new world in new ways. And if we are too critical of Google I think we give up that opportunity to see this new world and understand it through the lens of Google. In this new economy, I don’t think companies will be built anymore by huge capital, making huge acquisitions, they will be built, as Google has, through networks and platforms. We have a lot to learn from Google. As we try to understand this new world of links and connectedness and platforms and networks and generosity and speed, we would do well to ask ourselves, “what would Google do?” Google is not evil. In the examples it gives, and in the fact that it vows not to be evil, Google is a model to us all. Our world is better off because we have Google. So please, have a moment of decency, and vote against the motion.

## Round 2

### Moderator
Claim: Thank you Jeff Jarvis. That concludes our opening round, and in a minute or two I'm going to turn to you and ask whoever is there seething to respond to something that you’ve just heard that outrages you to do so. And we will also shortly be turning to questions from the audience. But I want to restate our motion that “Google Violates Its ‘Don’t Be Evil’ Motto” And as you know when you came in this evening, we asked you to vote for your opinion on this motion. And we have the numbers now, which I'm about to reveal, numbers which will appear on Google in perpetuity from this moment forward. Before the debate, twenty- one percent of you agreed with the motion, thirty-one percent of you were against the motion, and forty-eight percent of you were undecided. And that forty-eight percent is very valuable, it’s one of the largest undecided votes we’ve seen so far this season, maybe the largest. And again, reminding you that this is a contest for changing minds, so that forty-eight percent is a very, very large pie, to cut up, and we will be asking you to vote a little bit later on again in the evening. But first I want to turn to you, and I’ll count to three to see if a hand goes up, if anybody… Oh, OK. Harry Lewis, for the motion.

### Conspiracy Advocate (CA)
Claim: I’d just like to point out that our opposition tried both tactics to persuade you to vote against the motion. They said that evil means Hitler, Pol Pot, and the worst gulags of the Soviet Union. And they’ve also said, they mean by evil something that’s a much higher standard. Now, I would like to think, and I would like to ask the opposition if they don’t think that when Google made their motion, made their motto, “don’t be evil,” that they were not holding them to the standard that they shouldn't be as evil as Pol Pot, Hitler, and the worst of the Soviet Union, and if anything better than that, they would get a pass on the “don’t be evil” motto.

### Moderator
Claim: Jim, Jim Harper? Jim Harper, take that one. Jim Harper speaking for the motion.

### Scientific Advocate (SA)
Claim: Now, the question is as to the motto, and I would, I spoke to both versions, the actual, genuine meaning of the word evil, but what they may have meant, which is the sort of corporate greed kind of thing. Greed, which as Siva pointed out, drives them, wrongly apparently, to compete with eBay and Microsoft and Amazon, that's not an indictment of a company to say that they're competing with others, trying to serve consumers better than with whom they, than with whom they compete. By any standard Google is not violating the “don’t be evil” policy that they put forward.

### Moderator
Claim: Jim, your teammate, Esther Dyson.

### Scientific Advocate (SA)
Claim: Yeah, the purpose of this motto is that these guys are smart, and they are aware of the possibility of evil, they're aware that their extraordinary success and their extraordinary ability to collect information gives them a lot of power, and they do not want to abuse it. The other thing I’d like to point out is that Google, using Google is voluntary. Pol Pot, all these dictators, they were not voluntary. Google, whether it wanted to be evil or not, is constrained by the forces of competition, and it’s well aware of that. It has to earn your favor. It discloses to you what it does with your information. You can go and search your web history. So there, they're using their power to do good and to make the world more transparent.

### Moderator
Claim: Siva, you want to jump in?

### Conspiracy Advocate (CA)
Claim: Yeah, Jim, you’ve fallen into my trap.

### Moderator
Claim: So, can you get close to your mic a little bit?

### Conspiracy Advocate (CA)
Claim: Of course. So, you’ve fallen into my trap by citing the fact that every company should be expected to compete, and should, in fact, probably be extravagant, be gluttonous, be greedy, be slothful, be wrathful, and be envious, and of course, hubristic. Every company should, because that’s what companies should do, they should compete, they should win, they should crush…

### Scientific Advocate (SA)
Claim: No, they should win, they should not crush—

### Moderator
Claim: Siva, you’ve fallen into your own bog—

### Conspiracy Advocate (CA)
Claim: And by that, by that I say, it is for the companies to violate the seven deadly sins, and not to pretend they don’t, and it is for popes and poets to warn us against it.

### Moderator
Claim: Randy Picker for, let me bring in Randy Picker for the motion.

### Conspiracy Advocate (CA)
Claim: I hate to be a textualist, but I brought the registration statement with me, right, let’s see what it says. Don’t be evil. We believe strongly that in the long term we will be better served as shareholders and in all other ways by a company that does good things for the world, even if we forgo some short term gains. The question is, when does Google, faced with a conflict between what’s good for the world sacrifice its own interests. I don’t think it’s doing that.

### Moderator
Claim: Jeff Jarvis?

### Scientific Advocate (SA)
Claim: Let’s look at Yahoo, may it rest in peace.

### Moderator
Claim: Yes.

### Scientific Advocate (SA)
Claim: Shall we have a moment of silence for Jerry Yang, dearly departed.

### Moderator
Claim: Not good radio. Continue.

### Scientific Advocate (SA)
Claim: Yes. Yahoo was the last old structure, the last old media company. Google is a new company. Eric Schmidt was asked recently by Jim Kramer how much they could make by putting ads on their home page. Some untold billions of dollars, he said. They chose not to do that. Is that good versus evil? I actually argue it is, because Google recognizes that it’s not an end, like Yahoo. It’s not an old media company, it’s a new media company that gets us to what we want to get to. That itself is a virtue. I think the problem we’re having here is defining the fall from grace. And if we all define it the way that you are trying to hold Google, then we’re all going to hell, because—

### Moderator
Claim: This has been a very theological evening so far.

### Scientific Advocate (SA)
Claim: That word evil does it.

### Scientific Advocate (SA)
Claim: WWGD. Um… And so I think that Google recognizes that life is a beta. Google puts out products and says, they're not done yet. They are wrong, they're incomplete, please help us fix them. Google is not trying to say that they are ultimately absolutely virtuous. If we all tried to define ourselves that way, we’d be doomed.

### Moderator
Claim: Siva?

### Conspiracy Advocate (CA)
Claim: So, Jeff has compared Google to Wall Street firms and said, wouldn't it be great if Wall Street firms had that motto chiseled in their buildings. He’s compared Google to newspapers that have local monopolies, and pointed out that newspapers, of course, fix prices on advertising. And now he’s compared Google to Yahoo. None of that matters. It does not matter that any other company behaves badly, or behaves in an evil way, because none of those companies ever were foolish enough to chisel such a motto into their buildings or their financial filing statements. Now that, the fact is—

### Moderator
Claim: Should they have? Should they have?

### Conspiracy Advocate (CA)
Claim: …that Google has set its own standard, and has not met its own standard.

### Scientific Advocate (SA)
Claim: It has set its own standard, and I believe it has met it. It has aspired to do good. It has, as I said, engaged in an evil world to make it better. To me that’s the opposite of evil.

### Moderator
Claim: Harry Lewis, do you think Google actually meant it when it said that it wanted to commit no evil, or was that the most cynical declaration of all time?

### Conspiracy Advocate (CA)
Claim: It was an aspirational statement—

### Moderator
Claim: They meant it?

### Conspiracy Advocate (CA)
Claim: …and just as many of us make promises that we have to acknowledge we are unable to keep, Google has been unable, virtuously and continuously, to keep its aspirational promise. I think it’s a good thing that Google made that aspirational promise. The question is whether it ever violates it, and the answer is plainly that it does.

### Moderator
Claim: Esther, you were talking about China. Harry says going to China, and essentially he’s saying collaborating with the regime, and I choose all of those words because that’s exactly what his point was, was an act of evil. And you're arguing that a little access is a good thing.

### Scientific Advocate (SA)
Claim: It, no, I'm—a little access is a good thing, but I'm arguing something more important. It’s not collaborating with the regime, it is… It is infiltrating the regime, it is spreading information within China, it’s exposing people to the virtues of knowledge. It’s changing their expectations. It’s creating more transparency. Long run, you will see that Google is going to change China by opening those cracks. Every time you open a crack and insert something in it, it starts to crumble.

### Moderator
Claim: We’re going to hear from your teammate Jeff Jarvis in just a moment, because he has something he wants to say. But at this point I’d like to bring the house lights up. And if you have questions, raise your hands, and we have folks with microphones circulating. I know that there are some journalists in the audience, and we’re happy to have your questions, we just would ask that you’d identify yourselves. And if some, in some other way you have some dog in the fight in a way that you would like to disclose, that would be a good thing too.

### Scientific Advocate (SA)
Claim: No, we believe in disclosure regardless.

### Moderator
Claim: Jeff Jarvis?

### Scientific Advocate (SA)
Claim: Even if you wish that Google did differently in China, and I, frankly I do, I wish they’d use their power. The important thing is to realize the basis upon which they made this decision. And they used their “don’t be evil” pledge as a basis to debate and decide this. They made their decision not out of pure greed, but out of the belief, agree with it or disagree with it, but out of the belief that they were trying to do good.

### Moderator
Claim: Let’s go to a question halfway up, and again, passing the microphone down, and reminding you of our disclosure request.

### Moderator
Claim: Right, so my name is Larry Lessig, I'm a professor at Stanford, and Stanford gets lots of money from Google for some reason, I don't know why… But, first a comment to Siva, and then a question for Harry. The comment for Siva is, it’s not actually true to say, Siva, that Google paid a hundred twenty-five million dollars for something that it originally claimed it could do for free. It paid a hundred and twenty-five million dollars to do something far beyond what it originally claimed fair use protected it to do. And it explicitly says in the agreement that it does not believe that its original fair use claims are false, as I believe its fair use claims are true, so what it’s done is just bought a right that before it never claimed. This is not settling.

### Moderator
Claim: For people who are unaware of this settlement, could you take three sentences to explain—

### Moderator
Claim: Long sentences? I'm a lawyer, so…

### Moderator
Claim: Yeah, but I think you can do it. We’re, you're talking about the publishing—

### Moderator
Claim: Right, so Google originally claimed it had the right to scan these eighteen, or thirty-six million books—

### Moderator
Claim: One sentence.

### Moderator
Claim: …and at least make available snippets of the books that were still in copyright—

### Moderator
Claim: Comma—

### Moderator
Claim: …but out of print. Period. The settlement gives Google the right to display twenty percent of a book, plus, if a user chooses, to then give user access to the full book if they pay. That is wildly more than anybody thought fair use—

### Moderator
Claim: Siva—

### Moderator
Claim: …would grant them the right to do—

### Moderator
Claim: We’ll come to your second question, I want Siva to respond to that, because—

### Conspiracy Advocate (CA)
Claim: Yeah, I’ll—

### Moderator
Claim: …basically, what’s wrong with, especially since a lot of these, millions of books were out of print, you couldn't get to unless you traveled halfway across the world to a dusty library, and what you can now get online.

### Conspiracy Advocate (CA)
Claim: I don’t want to argue that, that making this material available is an example of evil, what was evil was the hubris in arguing that they could fly above the basics of copyright when they do it. And Larry and I have had this argument going on for about four years, we don’t want to invite everybody else into it, nonetheless, we—

### Moderator
Claim: No, no, no, we do, we—

### Conspiracy Advocate (CA)
Claim: We’re at, we’re at loggerheads on it. But I do want to point out that of the hundred and twenty-five million dollars that Google willfully paid in the settlement, people don’t give away money for nothing, they basically were paying the authors and the publishers ninety-one million dollars to settle the damages that were claimed by the authors and publishers. Right? Simple math. No something for nothing. The extra services that Google is now providing will take up thirty-four million dollars of that that hundred and twenty-five million. So, in fact, the settlement was a concession that they probably had flown too close to the sun—

### Moderator
Claim: Randy Picker wants to add to that.

### Conspiracy Advocate (CA)
Claim: Yeah, don’t focus on the dollars, focus on a different issue. So the basic structure of copyright law is, subject to fair use, you have to get permission. Google has done something incredibly clever, evil, I don’t know, in the settlement which is, by turning it into an opt-out class action, and now I just said a bunch of legal words that you're not going to like, they’ve effectively changed the default position with regard to how copyright’s consent system works. That’s either brilliant because of the orphan works problem, clever, or evil, I don’t know.

### Moderator
Claim: But bottom line, for those of us who aren't lawyers and don’t know the terms of the debate—

### Conspiracy Advocate (CA)
Claim: Yeah.

### Moderator
Claim: …did, did Google serve its own interests in this deal?

### Conspiracy Advocate (CA)
Claim: Very much so, I think. Maybe the public interest at the same

### Moderator
Claim: Larry, you have, Larry you had a, from the audience, you had a question—

### Scientific Advocate (SA)
Claim: They also served the interests of people who want to read books that were no longer available, and authors to get payments. Thank you.

### Moderator
Claim: Larry, to your question.

### Moderator
Claim: Right, so the question to Harry. So you observed that your reason for calling your daughter’s company evil is that…

### Conspiracy Advocate (CA)
Claim: Thanks a lot, she’ll love you for that.

### Moderator
Claim: …is that it complies with the Chinese rules about censoring a certain class of speech.

During the political campaign that we’ve just ended, John McCain complained to Yahoo, I mean, to YouTube, part of Google, that YouTube was complying with American copyright laws and censoring a whole bunch of speech that he thought should be kept up on the internet. Now, would you say a company is evil when it complies with American law and censors speech, or is it, or is a company—

### Moderator
Claim: OK, we, the question—

### Moderator
Claim: …obliged to keep all speech available regardless of the local law that might control it?

### Conspiracy Advocate (CA)
Claim: In the case of John McCain, I'm actually with John McCain in wishing that YouTube would exercise a little more judgement before it automatically pulled the, the campaign videos down, although I understand the practical reasons why that’s important, and I understand why, under the Safe Haven rules, they would have the knee jerk reaction. But Google actually could afford to review some of those videos in the middle of a political campaign to make a judgement about whether they were fair use or not, and I wish they had.

### Moderator
Claim: But complying with—

### Moderator
Claim: Would the audience agree with that? Those who agree, just a round of applause to that. And those who don’t agree, those who don’t agree? About fifty-fifty. We’re going to go to another question up in the, halfway up.

Who’s there? OK, we have one down front, to the, to your left here. And again, I will applaud a very cogent question.

### Moderator
Claim: I’ve written it down, actually.

### Moderator
Claim: Excellent.

### Moderator
Claim: Just to… I'm John I work for King Features, which is an online company. And I must say, someone brought up the point, if you put “don’t be evil” over financial services companies, somehow they miraculously think that they're not going to be evil. I think that people that are involved with the mortgage industry and the credit default sweeps, I still think to this day they probably are doing probably the benefit and the goodness of the financial services. So here’s my question. If Google is willing to limit search to get market share, what would limit them from disclosing personal search information of citizens to gain or maintain a market share.

### Moderator
Claim: Jeff Jarvis. Great question, when you got to it, by the way.

### Scientific Advocate (SA)
Claim: With all respect, I think you're showing little faith in mankind. It’s not Google you have a problem with, but man. Yes, even in a financial organization there can be someone who would ask the question, force the issue, is this evil? And similarly in Google, there is not only that, but there is also the self interest that Google does have a brand and a reputation. And if Google messes with us, we can use the internet and find ourselves on Google to get Google back. And we will. So Google, in its enlightened self interest, I believe would not mess with us.

### Moderator
Claim: OK, just a time check on where we are. We’re about halfway through the head to head discussion. Just a reminder, I'm John Donvan, your host and moderator of this Intelligence Squared US Debate where the motion is: “Google Violates Its ‘Don’t Be Evil’ Motto.” “Google Violates Its ‘Don’t Be Evil’ Motto.” We have three debaters for and against, and we are, at this point, taking questions from the audience, and we have, yes I see you Madame.

### Moderator
Claim: Hi, Meghan Keane with Wired.com. I'm just wondering about Yahoo and Google’s search partnership, and, did efforts to stop Google from forming a monopoly just end up speeding up the demise of its competitor? And, if you all have any thoughts on who might be able to save Yahoo now that Yang has stepped down?

### Conspiracy Advocate (CA)
Claim: Yeah, so on the question—

### Moderator
Claim: Randy Picker.

### Conspiracy Advocate (CA)
Claim: On the question of demise, I think that the question is, is Microsoft, who wanted to buy Yahoo before, still a natural purchaser. Obviously the scuttlebutt in today’s newspapers and online is that the change in management yesterday may increase that possibility. So if you ask what the natural deal is, that’s the natural deal. It’s not obvious to me that deal will actually matter. Maybe Esther’s in a better position to talk about that, but that seems to me the most natural next move for Yahoo.

### Scientific Advocate (SA)
Claim: Yeah, it’s, there are other acquirers, such as AOL, but I think the most important thing to learn from this is that companies that get into trouble usually are not murdered by Google or anybody else, they commit suicide.

### Moderator
Claim: Question from the gentleman in the center.

### Moderator
Claim: I confess to being a father of a daughter who works at Google also. I would like to ask the panel, either side of the question, where do the shareholders figure into this?

### Moderator
Claim: Are they evil, are you asking?

### Moderator
Claim: Pardon?

### Moderator
Claim: Are the shareholders evil?

### Moderator
Claim: Well, in a certain sense, yes, I'm asking that question. I'm asking what—we’re talking about Google as if it was an abstract drawing, OK, when in fact there are these shareholders out there, and don’t they have a voice in how the company behaves? Or should they?

### Moderator
Claim: Esther?

### Scientific Advocate (SA)
Claim: I think Google feels, and I agree, that shareholders matter, but not a lot. They, if their interests are short term profits, they can buy and sell and go away. What the founders wanted to create was a company where they were not driven by short term shareholder considerations. So, they're driven to some extent by long term shareholder considerations. They don’t want to sell their shares, they want this thing to be worth a lot in the long run, and I would say that's the basic attitude.

### Moderator
Claim: But Harry Lewis, I think you are almost arguing, in your China argument, that you're disappointed that shareholders did not protest.

### Conspiracy Advocate (CA)
Claim: Oh, I think, yes, I think that Google’s international reputation would have soared had they stood firmly against the Chinese censorship. It would have been in their long term interests, as many of the other measures that Google has made had.

### Moderator
Claim: Jim Harper?

### Scientific Advocate (SA)
Claim: As a shareholder question, this is very much like the question of people who complain about Google but don’t do anything about it. Shareholders are free to sell, and they would if Google was evil, if they were violating their motto.

### Scientific Advocate (SA)
Claim: Unfortunately, they wouldn't actually—

### Scientific Advocate (SA)
Claim: Shareholders hold.

### Moderator
Claim: Esther, I don’t think your mic was on, could you make—

### Scientific Advocate (SA)
Claim: Yeah, I know. I don’t, unfortunately, I don’t think the shareholders would have sold if they thought Google was evil.

### Scientific Advocate (SA)
Claim: They're free to.

### Scientific Advocate (SA)
Claim: They're free to. I also don’t think they would have applauded had Google stayed out of China. They probably would not have noticed, to be candid.

### Moderator
Claim: Siva?

### Conspiracy Advocate (CA)
Claim: Someone’s been selling Google’s shares—

### Scientific Advocate (SA)
Claim: They’ve been selling everybody’s—

### Conspiracy Advocate (CA)
Claim: Well, exactly. But people have been selling Google shares for reasons they don't disclose. Right? It’s a simple signal they send to the market. Nonetheless, remember that a publicly traded company that’s doing very well can afford to hold out a motto like “Don’t be evil.” When things get tough, and as Harry’s brought up, they have to make a decision between revenue and egalitarianism, they're going to pick revenue, as they have every time.

### Moderator
Claim: We’re going to another question, halfway up, gentleman in the white shirt.

### Moderator
Claim: Yes, hi. I have no relationship with Google. Other than being a, a Google user at times. So I, I wanted to just raise one point to the against side, that I have kind of a problem with the fact that, you know, you're, basically you seem, Esther, I believe, Esther, I believe, made the point that Google aspires to, to embrace, or to, to live up to this motto. But I kind of feel like you're conflating aspiration with accomplishment. And I also feel like Jeff, you’ve kind of made the point that, well, just because Google has done, eight, or nine, or ten, or twenty good things, that that somehow would eliminate if they had done anything bad. But the question is, did they violate the motto, which means that they commit actions that are, that are evil, or acts of evil.

### Moderator
Claim: All right.

### Moderator
Claim: The point that, you know, the law professor here in the audience raised, of the fact that Google is adhering to, to legal norms in whatever market they belong to, raises the, the profound problem for me that Google itself has said that they aspire to be able to predict what we want to do before we know it ourselves. And, with the accumulation of so much information from people, which is not opted in, what if the, the government in some other place were to decide that Google needed to share that information with people—

### Moderator
Claim: I'm going to stop you there—

### Moderator
Claim: …or with the government itself?

### Moderator
Claim: …and thank you for the question. And there were a few questions there, but Jeff, you had more of a challenge to your view than question, so—

### Scientific Advocate (SA)
Claim: On the aspirational point, I think that your standard, then, is perfection. It is, in fact, God-like. Because what you're saying is that if you fail at anything beyond this pledge of being evil, you’ve somehow failed. And I don’t think anyone here in reasonable mind would hold any of us here, or Google, or anyone short of God, to that. And so, I also think that it’s important that, that your other issue is that, is this God-Google omniscient, does it know everything about us, and can that be tapped by someone else? I think it’s a mistake to say, similarly, the opposite of the aspirational question, if that could happen, it, ergo, is true. If Google could do bad, ergo it is bad. Or Google is big, and big is often bad, ergo Google is bad. None of that follows.

### Moderator
Claim: OK, and just for our radio audience, I just want to say, Jeff Jarvis answering that question. Esther Dyson?

### Scientific Advocate (SA)
Claim: Yeah, just briefly I want to respond to one thing you said, and point out the real danger here is not Google, it’s the government. And governments have power which can easily be abused. Google is constrained. It’s constrained by law, it’s constrained by competition, it’s constrained by its users, and it responds to those constraints, and that’s one reason it’s not able. But I think the other reason is, it doesn't want to be.

### Moderator
Claim: Siva, can you be brief on this, because there is a question—

### Conspiracy Advocate (CA)
Claim: Very brief. I actually want to echo what Esther said, and again, just because there are more evil institutions in the world than Google does not mean that our case, that they violated their motto, is not true. Right? The fact that the federal government is much more evil does not absolve Google of responsibility of maintaining information that can be easily, secretly gathered. Right? If the FBI comes with a national security letter to Google and says, we want to know everything about Randy Picker, Randy Picker will never know that that happens, and no one at Google can talk about the fact that it happens. Right?

That’s the black box we’re dealing with. Google is a black box, the federal government is a black box. The interaction of two black boxes are, is a serious danger. That doesn't mean Google has done anything specifically, actively evil, but it certainly has enabled the potential of real evil.

### Moderator
Claim: Question all the way in the back.

### Moderator
Claim: Hi, Kevin Williamson, National Review, which may explain the slightly Thomistic tenor of this question, but this is really for those who are arguing for the motion, aren't you arguing that Google is in fact violating a different motto, which would say “don’t do evil,” versus a motto that says “don’t be evil.” Every business makes some sort of compromise, every business makes a mistake. Everybody who’s ever paid a dollar in taxes has made a compromise with evil at some point. But…

### Moderator
Claim: It’s staying theological, and it was a great question. Harry Lewis for the motion—

### Moderator
Claim: Aren't you arguing against a different motto—

### Conspiracy Advocate (CA)
Claim: I was waiting for this Clintonian, or Clinton-esque moment where the debate turned to the question of what the meaning of “be” is.

### Moderator
Claim: Are you going to take that question? I'm sorry, I was briefly distracted, I thought you were on a roll.

### Conspiracy Advocate (CA)
Claim: No, I was, I—

### Moderator
Claim: You were done.

### Conspiracy Advocate (CA)
Claim: I was, my answer is really done—

### Moderator
Claim: No, no, I actually think there’s something to the question.

### Conspiracy Advocate (CA)
Claim: I,—

### Scientific Advocate (SA)
Claim: The question, the question calls for an assessment of the totality of the company, not picking out individual instances where you don’t like what Google does, and we’ve made cases that there are many, many of those are, are falsities. The totality of, the company invited this discussion, first of all, by having this motto, and now exposes itself to this kind of discussion. And I think it holds up well, given all that.

### Conspiracy Advocate (CA)
Claim: Well—

### Moderator
Claim: Harry Lewis.

### Scientific Advocate (SA)
Claim: If being evil means being evil in your heart, and they—

### Conspiracy Advocate (CA)
Claim: Ah, well…

### Moderator
Claim: Harry Lewis.

### Conspiracy Advocate (CA)
Claim: Esther, if that’s what they meant, they could have said it. They didn't say it. They didn't say… They set the standard for the—

### Scientific Advocate (SA)
Claim: They're brief, they're brief.

### Conspiracy Advocate (CA)
Claim: They set the standard.

### Scientific Advocate (SA)
Claim: Unlike lawyers, they're brief.

### Conspiracy Advocate (CA)
Claim: Hmmm?

### Scientific Advocate (SA)
Claim: Unlike lawyers, they're brief and succinct.

### Moderator
Claim: Question down front.

### Moderator
Claim: I’m Vinnie Mankovsky I don’t have anything to do with Google, but I have two questions, one for Harry Lewis, the other is for Siva.

### Moderator
Claim: I'm going to ask you to choose one, OK?

### Moderator
Claim: Oh, that’s difficult, let’s go with the China one. Having lived for twenty years under communism in Bulgaria, and having been listening to the Voice of America and Free Europe, which were broadcasted by the US mainly, and were, noised by the Bulgarian authorities as well as the Russian and everyone else in the east bloc, according to what you say, the US should not have actually radio transmitted Voice of America because our authorities were actually, making noise on the same frequency. But I can tell you, if we didn't have access to this little information, we today would not have been members of NATO or the European Union. So how would you—

### Conspiracy Advocate (CA)
Claim: No, no, they, there isn't a parallel between the United States Voice of America and Google. Google is a business, and that, the issue for Google only came up because they wanted to set up shop inside China, have employees there, run their servers there, and do business with, inside China, and there are rules inside China for how businesses have to operate. And if I can just respond to Professor Lessig’s statement, I agree that businesses doing business in a country have to obey the laws of the country they're doing business in. And my contention is that Google made the wrong decision in deciding to do business in a country whose demands were so inconsistent with their fundamental mission in life.

### Scientific Advocate (SA)
Claim: So there’s more evidence to how freedom breaks out in a country that I think people should consider. In Czechoslovakia, Vaclav Havel was a playwright, and he wrote very obscure plays that the authorities didn't understand well. But the fact that people went to the plays, they talked about them, they were talking about revolution, they were talking about freedom. Similar things are happening now with Google’s help in China. They're using cultural references that the authorities don’t understand, and that Google and nobody else can control. They're using language, they're talking to each other, they're communicating with each other, and they're finding each other through Google. I'm not concerned about the—

### Conspiracy Advocate (CA)
Claim: Well, if I can just add—

### Moderator
Claim: We have a—

### Conspiracy Advocate (CA)
Claim: Just to be clear, Google is not actually the major search engine that’s actually used in China, so there are other avenues.

### Moderator
Claim: I want to go to, in the little bit of time we have left, get in two more questions, up in the far right.

### Moderator
Claim: One of my questions about China was just addressed. The other question was about the Google Chrome browser, which allows it to collect personal advertising information. I was wondering how both sides of the motion felt that it could use this as a force for good or for evil.

### Moderator
Claim: The collection of personal information?

### Moderator
Claim: Yes, through the browser.

### Moderator
Claim: Is there, Esther, a good use of the collection of personal information?

### Scientific Advocate (SA)
Claim: Sure, it can, if a user wants this information, it can be extremely valuable for the user. The user may want to share that information with other people. People keep talking as if users’ information was most, ought to be secret. People are now going on line voluntarily sharing it. They love comparing themselves. They like to compare their music tastes, they like to know whether they're hot or not. I like to compare… …my genome with other people’s genomes. And the ability to know more about yourself, to share it with other people, that’s what mirrors are for, and they're best sellers.

### Moderator
Claim: I’ll show you my genome if you show me yours? Siva?

### Conspiracy Advocate (CA)
Claim: The issue behind privacy and the regulation of personal information is not that people should or should not, or do or do not want to share. The issue is a matter of personal autonomy. Having the easy to access controls over who sees what in what context. And it’s a much more fluid complicated and multi- faceted question that simply the idea that we are putting our favorite music up on Facebook in large, in torrents. That's true, but it’s not relevant. The fact is, Chrome and Gmail offer us no way to manage our personal information. Google service—

### Scientific Advocate (SA)
Claim: You don't need—

### Conspiracy Advocate (CA)
Claim: …harvest their, that information, and people use Chrome and Gmail without any real knowledge or recognition or simple acknowledgement of the transaction. Most people who use Google do not understand the transaction in which they are engaging. And that is a problem.

### Moderator
Claim: Our last question, from right down front. Make it a doozy.

### Moderator
Claim: I’d like some clarity on the definition of evil that we’re using. If an entity has a good goal and achieves them imperfectly, in such that some bad is caused by the imperfect achievement of those goals, is that evil? I don't see anything evil in spoiling your employees or in choosing to place some value on an ad-free search result such that it costs more for the advertisers. I potentially see evil in the decision to censor the results in China, if that was a decision made for the goal of, of financial return.

### Moderator
Claim: But at bottom you're asking what?

### Moderator
Claim: Do we have any way of knowing what Google’s goals are in making these decisions, and if we don’t, do we have any way of evaluation whether or not they're evil.

### Moderator
Claim: Siva?

### Conspiracy Advocate (CA)
Claim: Oh, we each have the capacity of judging whether any particular action is evil. I, of course, am appealing to authority, one of the classic fallacies, the authority being Dante and Pope Gregory. But, I didn't mean to do so quite so facetiously. I do mean to say that all of the things that big, successful corporations should do tend to trample on the cannon of good and evil that we have been swimming in. And in fact, it’s hypocritical for a company to say that it will hold itself to a high standard. It’s perfectly reasonable for Google to do almost everything it has done as a profit making venture, uh, and I applaud most of what it’s done. But the real question is, is this standard itself being undermined by its very actions? Is the fact that it set this high standard for itself ultimately foolish?

## Round 3

### Moderator
Claim: Thank you very much, and that includes the head to head portion of the discussion, and thanks for your terrific questions, which, which actually were quite good questions, and kept things moving along. We’re going to move along now to final statements. This is the last chance that each of the panelists will have, really, to lock you in. They’ll each get two minutes to speak. But before we do that, I want to remind you of where we were in terms of the numbers. Before the debate, when we polled you on the motion that Google violates its “don’t be evil” motto, twenty-one percent of you were for the motion, thirty-one percent were against, and a very large forty-eight percent were undecided. So, we’re moving forward now to closing statements. Each panelist will have two minutes. And we are going to begin with Jim Harper, who is the director of information policy studies at the Cato Institute, speaking against the motion. Jim?

### Scientific Advocate (SA)
Claim: Well, first I want to congratulate and thank our opponents in this debate, they have a very, very difficult chore ahead of them. They did the best they could, and I congratulate them on what meager success they had in, in their arguments. Important point, Google invited this conversation. Google deserves your credit for having this conversation. And as Jeff pointed out, inviting this conversation internally as well. There is a culture there that is essentially good. There are decisions they have made that I have openly criticized. I disagree with some of the things Google does. The totality of what Google does, and the totality of what Google is, is not evil. It is good. And I think you should support opposing the motion… You should oppose the motion… Because Google is, at its heart, a good company that provides extraordinary services to the public, and makes extraordinary amounts of information available to the public, and is working around the world to make information available. And the slights that have been heaped upon it by our opponents do not overcome their burden, we think, and we hope you think, that Google is a good company. Please oppose the motion.

### Moderator
Claim: Thank you Jim Harper. And making his summarizing statement for the motion, Randy Picker, professor at the University of Chicago Law School. Randy Picker?

### Conspiracy Advocate (CA)
Claim: Well, I'm both a lawyer and an economist. And as an economist I think the issue before us is what I’ll call marginal evil, incremental evil. I think that’s where we are with regard to Google. That’s the question. When are they creating evil that they don't need to create? When are they making a choice that we should understand to be one that benefits Google and hurts the market, hurts other participants in that market. Where I started was something that went to the heart of their business model. This isn't a side show, this is not an experiment, this is at the heart of the way Google does business. And what they are doing there is doing exactly what we see monopolists doing. Since the Sherman Act was passed in 1890, they exercise market power. That’s what Google is doing. We heard a lot of discussion, I haven't heard, actually, anything about that. I think that’s because it’s not possible to refute that, and I don’t think it’s actually transparent to most people how they're doing it. And when someone asks Google whether they're doing that, Google says, we’re running auctions, we don’t have power, notwithstanding our market share is sixty-five percent in the United States. That is acting in a way that is being evil.

### Moderator
Claim: Thank you, Randal Picker. Summarizing against the motion, Esther Dyson, an investor in information technologies companies. Esther Dyson?

### Scientific Advocate (SA)
Claim: Thank you. The thing doesn't say don’t be incrementally evil. I, you know, when you have to sort of get down to these fine distinctions I think it’s clear you're losing. So, I would encourage you guys… …to join the winning side, and vote against this unsupportable proposition. Google is not violating its don’t be evil motto. They are doing good. They are opening up the world, they are giving people more choices, they're giving people awareness of their choices, they're increasing transparency and people’s personal autonomy. Mostly what they are doing, and the thing for which I give them most credit is, they're eroding the power and limiting the ability of those in power to abuse that power by shining light, and by encouraging people to change their expectations, to start asking for answers. They're giving everybody the ability to watch the watchers in this increasingly transparent world. So, please join us, the winning side, and vote no.

### Moderator
Claim: Thank you, Esther Dyson. Summarizing his position for the motion, Harry Lewis, Professor of Computer Science at Harvard University.

### Conspiracy Advocate (CA)
Claim: Well, not everyone, Esther, they’re not giving that power to everyone. “Evil” was Google’s term, we didn’t set the terms of this debate, the Intelligence Squared people didn’t set the terms of this debate. Google set the terms of this debate, by putting that grand proposition out there. “Don’t be evil.” Some of the things they’re doing, they themselves know aren’t right. They themselves would prefer not to be censoring search results in China, and they have allied themselves with other corporations into a new consortium that is— And they’ve pledged themselves to try to lift this restriction, over the coming years. Now, they’re to be respected for that, as they are to be respected for all of the other enlightening things that the other side keeps pointing out they are doing. But it’s not a proposition about on aggregate, are they 10 percent more good than they are evil. The question is, do they violate—“violate” is an active verb, that’s a—we won’t—okay, let’s not parse. Do they violate their “Don’t be evil” motto and I just repeat that the construction of censorship tools is an act of evil. Thank you.

### Moderator
Claim: Okay, the motion in this Intelligence Squared US debate is, “Google Violates its ‘Don’t Do Evil’ Motto,” and summarizing his position against the motion is Jeff Jarvis, Director of the Interactive Journalism program at the City University of New York’s Graduate School of Journalism. Jeff Jarvis.

### Scientific Advocate (SA)
Claim: This debate, I believe, is not about Google, it is about us. And it is perhaps a bit of an indictment of us. You know, the problem we have in America is that we love and nurture success until you become too successful. And when you become too successful we become suspicious of you, we even wonder whether you couldn’t do this any other way besides being…evil. Perhaps you do it by being smart, by being good, by being generous. By being innovative. I think that’s what Google has done here, those are all virtues, and our risk, as a nation, by looking the gift geek in the mouth… not a pleasant visual I’ll admit— …is that we lose this lesson and we lose this value and we lose this tremendous gift, that Google gives us. Finally, because I am a fan of Google, I am a fan of the wisdom of the crowd. I believe, you are wise. So I am confident, that you will vote against the motion.

### Moderator
Claim: Thank you, Jeff Jarvis, and finally, summarizing his position, for the motion, Siva Vaidhyanathan, Associate Professor of Media Studies and Law at the University of Virginia, Siva.

### Conspiracy Advocate (CA)
Claim: Lucifer did not fall because he wanted to be bad. Like Jessica Rabbit he was drawn that way. in fact he fell… He fell because he was trying to be great. Now, I firmly believe that companies should be companies. That governments should be governments. That saints should be saints, that sinners should be sinners, that gods should be gods, and devils should be devils. The claims of corporate responsibility are basically, cyclical marketing ploys, disguised, disguised as something great and good. The fact is Google grew as big and successful as it has, not only because it is great, and it is…but because it claimed to be good. Google never bought a Super Bowl ad, to my knowledge, Google never bought an ad. Right?

Google got big because in the early days, a whole lot of us who were very active on the web were disgusted by the status quo and we gravitated to Google not only because it seemed to satisfy our needs, but because it satisfied our need to avoid evil and the evil in those days was number one, Microsoft, and number two, Yahoo. And in both cases, Google was able to get—gain our loyalty. It was a cynical marketing ploy, one that in the long run, it will not and in fact has not lived up to. People really believed it was not evil, many people still believe it does not do evil. The fact is companies should make money, and the rest of us should beware. So please vote for the proposition.

### Moderator
Claim: Thank you, Siva Vaidhyanathan, and I’d just like to ask for a round of applause as we conclude the talking portion of the debate. So now we come to the moment where you decide how this all turns out, we are going to ask you to vote on the motion which I will restate once again. “Google Violates its ‘Don’t Do Evil’ Motto.” Turn to the keypads by your side, if you agree with the motion…push number 1, if you disagree number 2, if you remain undecided, push number 3, and we’re gonna have the results actually hurried down in just a moment and as they’re tallied, I would like to point out a few things that are coming up on Intelligence Squared. Our final debate of the— Our final debate of the fall season…as you’ve jumped ahead on— jumped ahead of me on… It’s Tuesday, December 2nd, our final debate, with the motion, “Bush 43 is the worst President of the last 50 years.” Panelists for the motion are Simon Jenkins, a columnist for The Guardian, and former editor at the Times and London Evening Standard, and Jacob Weisberg, who is chairman and editor-in-chief of the Slate Group. Against the motion, Bill Krystal, editor of The Weekly Standard and op-ed columnist for the New York Times, and Karl Rove, former senior advisor and deputy chief of staff for George W. Bush. This is all your way of reminding the radio audience that we are in New York City. This debate will be broadcast on BBC World News Television, and to accommodate this particular taping we will be moving for this debate to the Symphony Space Theater which is at 95th and Broadway, and for more information you can visit our website. I would also like to announce the dates and motions for our spring 2009 season. January 13th, “Major Reductions in Carbon Emissions Are Not Worth the Money,” February 3rd, “The Art Market is Less Ethical Than the Stock Market”— March 17th, “Blame Washington More Than Wall Street for the Financial Crisis,” April 21st, “It is Wrong to Pay for Sex,” May 12th, “Diplomacy with Iran is Going Nowhere.” All of the spring debates will be held here again at the Casprey Auditorium at Rockefeller University, with the exception of the first debate on January 13th, that is the carbon debate, that will also be held at the Symphony Space Theater and tickets are still available through the website. All of our debates can be heard on more than 150 NPR stations around the country, and you just need to check with your local NPR station listings for the dates and times of the broadcast. And copies of books by our panelists are on sale in the lobby as well as DVD’s, and now, the moment of truth.

The motion before us was, “Google Violates its ‘Don’t Do Evil’ Motto.” Coming in, 21 percent of you were for the motion, 31 percent were against, and 48 percent were undecided. After the debate, 47 percent of you agree with the motion. 47 percent of you are against the motion, and 6 percent were undecided. 47 percent to 47 percent looks like a tie, however, the side that changed most minds is the side for the motion, who moved 26 percent of you. Versus... Versus 16 percent for the side against. Thank you to our panelists and thank all of you for joining us.
